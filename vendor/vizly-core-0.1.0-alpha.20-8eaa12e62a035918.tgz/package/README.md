# @vizly/core

Compiled Vizly editor runtime. Core source remains private. The bundled
`LICENSE` has been approved by the rights holder. Distribution of the unmodified
compiled package as a noncommercial Vizly application dependency must retain
the license and notices. Commercial production deployment requires separate
written authorization. npm publication requires an explicit owner-approved
SDK release request.

Import `@vizly/core/react` for the low-level React editor and
`@vizly/core/style.css` once in the host application.

The host supplies React Flow's stylesheet, its `react-i18next` provider and
complete Core UI translations. Bind the same translation instance with
`configureCoreI18n` from `@vizly/core/i18n`. The editor also uses Tailwind 4
utilities. Register the compiled package in the host's Tailwind stylesheet
(paths are relative to that stylesheet):

```css
@import "tailwindcss";
@source "../node_modules/@vizly/core/dist";
```

Import `@xyflow/react/dist/style.css` alongside Core's stylesheet. Tailwind
does not scan dependencies automatically; see its
[external-library source registration documentation](https://tailwindcss.com/docs/detecting-classes-in-source-files#explicitly-registering-sources).

`CoreFlowchartEditor` owns its portable document initialization through
`initialDocument` and `loadDocument`; it does not fetch that document from the
Vizly application's data adapter. Application views using `FlowchartDesigner`
directly retain their configured application loader and preset recovery flow.
Each portable editor supplies its own toolbar targets. Loading a portable
document starts fresh page and undo/redo state so previous pages cannot be
restored into the replacement document.

Hosts can import `DiagramControlBridge` from `@vizly/core/editor-control-bridge`
without loading command search. Load `@vizly/core/editor-ui` on demand when
opening `CommandPalette`; the existing combined entry remains compatible.

Flowchart editors accept `collaborationMode`: `standalone` (the default) owns a
separate session per mounted editor, `host` delegates collaboration to the
application, and `disabled` creates no Core session. Hosts supplying their own
Yjs document should explicitly select `host`; `onSyncPush` alone does not select
a mode because it is also used for ordinary document-change notifications.
Standalone sessions remain local when no `VITE_YJS_WS_URL` is configured in the
Core build. Readonly host views continue to use host-provided presence.

Changing a `FlowchartDesigner` document `id` creates fresh editor state and
releases the previous session. Unmounting or disposing one editor does not
release a sibling's session. Same-document multi-view sharing and the legacy
mind-map collaboration integration are outside this instance-isolation contract.
