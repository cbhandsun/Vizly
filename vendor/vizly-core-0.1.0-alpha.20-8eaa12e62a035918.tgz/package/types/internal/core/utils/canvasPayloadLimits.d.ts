export declare const MAX_CANVAS_NODE_JSON_DEPTH = 32;
export declare const MAX_CANVAS_METADATA_JSON_DEPTH: number;
