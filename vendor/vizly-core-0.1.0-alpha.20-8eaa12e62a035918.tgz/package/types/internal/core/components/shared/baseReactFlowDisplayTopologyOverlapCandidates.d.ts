import type { Edge } from '@xyflow/react';
/** A crossing repair can leave the changed edge on a frozen opposite-flow lane.
 * Separate only that edge's interior segment; terminal policy and every context
 * edge remain untouched. The caller owns exact geometry and clearance gates. */
export declare const buildBaseReactFlowTopologyOverlapCandidates: <T extends Edge[]>({ edges, changedEdgeIds, }: {
    edges: T;
    changedEdgeIds: ReadonlySet<string>;
}) => T[];
