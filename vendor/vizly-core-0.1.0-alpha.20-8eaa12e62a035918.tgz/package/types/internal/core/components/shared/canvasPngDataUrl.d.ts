/** Keep PNG pixels while allowing input/cancellation during native encoding. */
export declare function canvasPngDataUrl(canvas: HTMLCanvasElement, signal?: AbortSignal): Promise<string>;
