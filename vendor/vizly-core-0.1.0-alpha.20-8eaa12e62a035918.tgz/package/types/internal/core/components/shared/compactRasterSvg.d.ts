/** Remove redundant computed custom properties only from self-contained snapshots.
 * html-to-image has already resolved normal declarations. WebKit includes every
 * inherited design token in each computed style, producing enormous data URLs.
 */
export declare function compactRasterSvg(svg: SVGElement): void;
