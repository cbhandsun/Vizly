import type { DisplayEdgesWorkerRequest, DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerProtocol.js';
import type { Edge, Node } from '@xyflow/react';
import { type BaseReactFlowFinalEndpointOrderOptions } from './baseReactFlowDisplayFinalEndpointGate.js';
export declare const polishBaseReactFlowDisplayTangentTerminals: <T extends Edge[]>(edges: T, nodes: Node[], onPhaseTrace?: BaseReactFlowFinalEndpointOrderOptions['onPhaseTrace'], labelClearanceOnly?: boolean, eligibleEdgeIds?: ReadonlySet<string>, preserveCenteredTerminals?: boolean) => T;
/** Negotiate terminals before the final terminal-preserving corridor polish. */
export declare const finalizeDisplayWorkerTangentTerminalResponse: (request: DisplayEdgesWorkerRequest, response: DisplayEdgesWorkerResponse, onPhaseTrace?: BaseReactFlowFinalEndpointOrderOptions['onPhaseTrace'], preserveNegotiatedTerminals?: boolean) => DisplayEdgesWorkerResponse;
