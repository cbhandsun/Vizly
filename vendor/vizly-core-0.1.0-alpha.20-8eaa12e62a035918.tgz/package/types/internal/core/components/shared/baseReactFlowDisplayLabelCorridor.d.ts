import type { Edge } from '@xyflow/react';
/** Detect labelled paths whose sampled private spans are enclosed by nearby
 * parallel tracks. A unique attachment alone is insufficient: a text box must
 * also fit beside it. The caller still validates any proposed route change
 * against the whole graph, including terminals and all existing label anchors.
 */
export declare const displayLabelsInNarrowCorridors: (edges: readonly Edge[]) => string[];
