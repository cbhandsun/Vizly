/** Keep the normal upstream copy loop, deferring only a trailing custom-property run. */
export declare function rasterCloneStyleProperties(properties: string[], source: CSSStyleDeclaration, target: CSSStyleDeclaration, clone: Element, options: unknown): string[];
/** Restore the complete native cascade unless every deferred declaration is removable. */
export declare function settleDeferredRasterCustomProperties(svg: SVGElement, canCompact: boolean): boolean;
