import { type ReactFlowRenderSnapshot } from '../../rendering/reactFlowScene.js';
import { downloadImageUnobserved as downloadImage, type ExportOptions } from '../../utils/imageExporter.js';
export declare class AdvancedExportError extends Error {
    readonly code: 'ADVANCED_EXPORT_VECTOR_PDF_SNAPSHOT_REQUIRED';
    constructor();
}
export interface RunAdvancedExportOptions {
    diagramId?: string;
    diagramTitle?: string;
    nodes: Parameters<typeof downloadImage>[0];
    format: ExportOptions['format'];
    pixelRatio: number;
    includeBackground: boolean;
    embedMetadata: boolean;
    getReactFlowSnapshot?: () => ReactFlowRenderSnapshot | null | undefined;
}
export declare const runAdvancedExport: (options: RunAdvancedExportOptions) => Promise<'scene' | 'fallback'>;
