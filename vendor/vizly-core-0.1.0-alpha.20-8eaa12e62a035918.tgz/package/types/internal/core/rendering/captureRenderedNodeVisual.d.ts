import { type RenderedNodeVisual } from './renderedNodeVector.js';
export declare function captureRenderedNodeVisual(node: HTMLElement, textBudget: {
    remaining: number;
}): RenderedNodeVisual | undefined;
