# @vizly/core

Compiled Vizly editor runtime. Core source remains private. The bundled
`LICENSE` has been approved by the rights holder. Distribution of the unmodified
compiled package as a noncommercial Vizly application dependency must retain
the license and notices. Commercial production deployment requires separate
written authorization. npm publication requires an explicit owner-approved
SDK release request.

Import `@vizly/core/react` for the low-level React editor and
`@vizly/core/style.css` once in the host application.

Hosts can import `DiagramControlBridge` from `@vizly/core/editor-control-bridge`
without loading command search. Load `@vizly/core/editor-ui` on demand when
opening `CommandPalette`; the existing combined entry remains compatible.

Flowchart editors accept `collaborationMode`: `standalone` (the default) owns a
separate session per mounted editor, `host` delegates collaboration to the
application, and `disabled` creates no Core session. Hosts supplying their own
Yjs document should explicitly select `host`; `onSyncPush` alone does not select
a mode because it is also used for ordinary document-change notifications.
Standalone sessions remain local when no `VITE_YJS_WS_URL` is configured in the
Core build. Readonly host views continue to use host-provided presence.

Changing a `FlowchartDesigner` document `id` creates fresh editor state and
releases the previous session. Unmounting or disposing one editor does not
release a sibling's session. Same-document multi-view sharing and the legacy
mind-map collaboration integration are outside this instance-isolation contract.
