import type { Edge, Node } from '@xyflow/react';
import type { Point } from '../types/routing.js';
export interface DistributedAnchorAssignment {
    edgeId: string;
    sourceSide?: 'top' | 'right' | 'bottom' | 'left';
    targetSide?: 'top' | 'right' | 'bottom' | 'left';
    sourceAnchorRatio?: number;
    targetAnchorRatio?: number;
}
/**
 * Unifies `computeHubPortDistribution` and `optimizeHubPortOrder` (barycenter +
 * Cocktail-Shaker adjacent-swap crossing minimization) to assign both cardinal sides
 * and distributed perimeter anchor ratios in [0.18, 0.82] for edges sharing a node side.
 */
export declare function computeDistributedHubAnchors(nodes: readonly Node[], edges: readonly Edge[], hubThreshold?: number): Map<string, DistributedAnchorAssignment>;
/**
 * Applies `LPNudge` to separate overlapping parallel interior orthogonal segments across edges
 * while keeping terminal segments (first and last segment of each polyline) locked to their ports.
 */
export declare function nudgeParallelOrthogonalPaths(edgePaths: ReadonlyMap<string, readonly Point[]>, minSpacing?: number): Map<string, Point[]>;
