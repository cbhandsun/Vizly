import type { Node } from '@xyflow/react';
export type ConnectionPreviewPortSide = 'top' | 'right' | 'bottom' | 'left';
export type ConnectionPreviewSide = ConnectionPreviewPortSide;
export interface ConnectionPreviewTarget {
    nodeId: string;
    handleId: ConnectionPreviewPortSide;
    side: ConnectionPreviewPortSide;
    portFlowX: number;
    portFlowY: number;
    distance: number;
    dist: number;
    snapped: boolean;
}
export interface ConnectionPreviewHysteresisState {
    nodeId: string;
    side: ConnectionPreviewPortSide;
    snapped: boolean;
}
export interface ResolveConnectionPreviewTargetOptions {
    nodes: readonly Node[];
    sourceNodeId: string;
    pointerFlowX: number;
    pointerFlowY: number;
    previousTarget?: ConnectionPreviewHysteresisState | null;
}
/**
 * Resolves the nearest connectable target node and port anchor in flow coordinates.
 * Selects the closest side port rather than fixed 45-degree center quadrants so
 * wide/tall nodes snap accurately to top/bottom/left/right handles, with spatial
 * hysteresis to prevent corner and threshold chatter.
 */
export declare function resolveConnectionPreviewTarget(nodesOrOptions: readonly Node[] | ResolveConnectionPreviewTargetOptions, sourceNodeIdArg?: string | null, pointerFlowArg?: {
    x: number;
    y: number;
}, previousTargetArg?: ConnectionPreviewHysteresisState | null): ConnectionPreviewTarget | null;
