import type { Edge, Node } from '@xyflow/react';
import type { LayoutCalculationContext } from '../../../types/layout-strategy.js';
import type { FlowchartLayoutDirection } from '../flowchartLayoutStrategyMode.js';
type CyclicTreeLayeredLayoutInput = Readonly<{
    pluginId?: string;
    layoutNodes: Node[];
    layoutEdges: Edge[];
    allNodes: Node[];
    nonLayoutTypes: ReadonlySet<string>;
    direction: FlowchartLayoutDirection;
    context?: LayoutCalculationContext;
}>;
type CyclicTreeLayeredLayoutResult = Readonly<{
    nodes: Node[];
    edges: Edge[];
}>;
type CyclicTreeLayeredLayoutCommit = (candidate: CyclicTreeLayeredLayoutResult, usedCompoundFallback: boolean) => Promise<void>;
export declare const commitCyclicTreeLayeredLayout: (input: CyclicTreeLayeredLayoutInput, commit: CyclicTreeLayeredLayoutCommit) => Promise<void>;
export {};
