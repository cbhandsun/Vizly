import React from 'react';
import { Edge } from '@xyflow/react';
import type { EdgeDataUpdate } from '../../types/diagram-updates.js';
interface ContextualEdgeToolbarProps {
    edge: Edge;
    onUpdateEdge: (edgeId: string, updates: EdgeDataUpdate) => void;
    onToggleLock: (edgeId: string, locked: boolean) => void;
    onDeleteEdge?: (edgeId: string) => void;
}
export declare const ContextualEdgeToolbar: React.FC<ContextualEdgeToolbarProps>;
export {};
