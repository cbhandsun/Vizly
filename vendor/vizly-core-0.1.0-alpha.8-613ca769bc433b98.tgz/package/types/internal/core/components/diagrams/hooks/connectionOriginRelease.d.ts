/** React Flow can omit toNode when the pointer returns to the source handle. */
export declare function isConnectionReleaseOnOrigin(event: MouseEvent | TouchEvent, nodeId: string): boolean;
