import type { XYPosition } from '@xyflow/react';
import type { AnchorSide, NodeRect } from './baseReactFlowDisplayEdgeGeometry.js';
/** Resolves only a rounded corner ambiguity, using the existing outward leg.
 * Interior terminals and diagonal or inward approaches remain undecided.
 */
export declare const resolveDisplayCornerApproachSide: (path: readonly XYPosition[], terminalIndex: number, rect: NodeRect) => AnchorSide | null;
