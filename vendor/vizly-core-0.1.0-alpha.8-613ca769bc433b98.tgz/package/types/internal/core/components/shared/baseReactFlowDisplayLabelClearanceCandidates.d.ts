import type { Edge } from '@xyflow/react';
/** Slide an interior orthogonal crossbar while retaining both endpoints, bend
 * count and path length. Whole-graph hard gates remain the caller's job. */
export declare const buildDisplayLabelClearanceCandidates: (edges: readonly Edge[]) => {
    edges: Edge[];
    changedIndex: number;
}[];
