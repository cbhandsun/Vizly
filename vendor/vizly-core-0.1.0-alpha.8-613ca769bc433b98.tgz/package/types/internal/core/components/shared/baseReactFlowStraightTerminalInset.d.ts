import type { XYPosition } from '@xyflow/react';
import type { AnchorSide } from './baseReactFlowDisplayEdgeGeometry.js';
/** Keep both outward endpoint directions when insetting a formerly straight route. */
export declare const restoreStraightTerminalOrthogonality: (path: XYPosition[], sourceSide: AnchorSide, targetSide: AnchorSide) => XYPosition[];
