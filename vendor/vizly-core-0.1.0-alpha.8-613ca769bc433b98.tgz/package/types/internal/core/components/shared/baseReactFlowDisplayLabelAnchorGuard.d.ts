import type { Edge } from '@xyflow/react';
/** A shortcut may not remove the last unambiguous attachment of any label. */
export declare const preservesDisplayLabelAnchorClearance: (before: readonly Edge[], after: readonly Edge[]) => boolean;
export declare const displayLabelsWithoutUniqueAnchors: (edges: readonly Edge[]) => readonly string[] | null;
