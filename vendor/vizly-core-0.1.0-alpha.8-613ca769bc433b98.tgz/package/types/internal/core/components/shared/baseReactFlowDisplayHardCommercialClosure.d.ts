import type { Node } from '@xyflow/react';
import type { BaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
import type { DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
import type { DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerProtocol.js';
/** Keep intermediate repairs private until geometry and clearance close together. */
export declare const closeGeneratedDisplayHardCommercialContract: ({ response, repairNodes, evaluation, eligibleEdgeIds, onPhaseTrace, }: Readonly<{
    response: DisplayEdgesWorkerResponse;
    repairNodes: Node[];
    evaluation: BaseReactFlowFinalEndpointEvaluation;
    eligibleEdgeIds?: ReadonlySet<string>;
    onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void;
}>) => DisplayEdgesWorkerResponse;
