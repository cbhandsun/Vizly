import type { Edge } from '@xyflow/react';
import type { SameSideEndpointTrunkIdentity } from '../../strategies/shared/edgeFinalSameSideEndpointOrderRepair.js';
/** Propose one exterior lane for every member of a retained terminal trunk.
 * The enclosing transaction owns exact geometry, clearance and trunk gates.
 */
export declare const restoreInitialDisplayTrunkLanes: (edges: Edge[], trunks: readonly SameSideEndpointTrunkIdentity[]) => Edge[];
