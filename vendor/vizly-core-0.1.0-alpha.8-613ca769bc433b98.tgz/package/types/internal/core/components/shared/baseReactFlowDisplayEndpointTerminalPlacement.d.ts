import type { Edge, Node, XYPosition } from '@xyflow/react';
import { type AnchorSide, type NodeRect } from './baseReactFlowDisplayEdgeGeometry.js';
export declare const centeredTerminalOnSide: (rect: NodeRect, side: AnchorSide) => XYPosition;
export declare const insetTerminalOnSide: (terminal: XYPosition, rect: NodeRect, side: AnchorSide, node?: unknown) => XYPosition;
export declare const countTerminalsByNodeSide: (edges: Edge[], nodeById: Map<string, Node>) => Map<string, number>;
export declare const centerUniqueAutoTerminals: (edge: Edge, nodeById: Map<string, Node>, terminalCounts: Map<string, number>) => Edge;
