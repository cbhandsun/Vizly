import type { DisplayEdgesWorkerRequest, DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerProtocol.js';
import type { Edge, Node } from '@xyflow/react';
import { type BaseReactFlowFinalEndpointOrderOptions } from './baseReactFlowDisplayFinalEndpointGate.js';
export declare const polishBaseReactFlowDisplayTangentTerminals: <T extends Edge[]>(edges: T, nodes: Node[], onPhaseTrace?: BaseReactFlowFinalEndpointOrderOptions['onPhaseTrace'], labelClearanceOnly?: boolean, eligibleEdgeIds?: ReadonlySet<string>) => T;
/** Terminal negotiation is the last geometry mutation before session hashing. */
export declare const finalizeDisplayWorkerTangentTerminalResponse: (request: DisplayEdgesWorkerRequest, response: DisplayEdgesWorkerResponse, onPhaseTrace?: BaseReactFlowFinalEndpointOrderOptions['onPhaseTrace'], preserveNegotiatedTerminals?: boolean) => DisplayEdgesWorkerResponse;
