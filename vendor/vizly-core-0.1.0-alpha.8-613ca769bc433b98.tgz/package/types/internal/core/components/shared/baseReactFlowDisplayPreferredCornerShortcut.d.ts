import type { Edge, Node } from '@xyflow/react';
import { type BaseReactFlowFinalEndpointOrderOptions } from './baseReactFlowDisplayFinalEndpointGate.js';
import { type BaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
import type { DisplayEdgesWorkerRequest, DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerProtocol.js';
/** Proposes removal of an outward corner hairpin using the original approach.
 * The caller owns exact graph, obstacle, terminal and shared-trunk acceptance.
 */
export declare const buildPreferredCornerSourceShortcut: (edge: Edge, preferred: Edge | undefined, nodeById: Map<string, Node>) => {
    candidate: Edge;
    preferred: Edge;
} | null;
/** Run only after the final render geometry is complete; no later routing pass
 * may reinterpret the accepted original corner approach as a provisional trunk.
 */
export declare const repairFinalPreferredCornerSourceShortcuts: (edges: Edge[], nodes: Node[], options: BaseReactFlowFinalEndpointOrderOptions, evaluation: BaseReactFlowFinalEndpointEvaluation) => Edge[];
/** Complete full Worker routes after stabilization and before session hashing.
 * Incremental and repair responses retain their original declared scope.
 */
export declare const finalizeDisplayWorkerPreferredCornerResponse: (request: DisplayEdgesWorkerRequest, response: DisplayEdgesWorkerResponse) => DisplayEdgesWorkerResponse;
