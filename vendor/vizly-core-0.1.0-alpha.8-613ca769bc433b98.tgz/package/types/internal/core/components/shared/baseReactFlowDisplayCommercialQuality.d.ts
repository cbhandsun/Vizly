import type { Edge } from '@xyflow/react';
export declare const MIN_COMMERCIAL_INTERIOR_SEGMENT = 24;
export declare const MAX_COMMERCIAL_BEND_COUNT = 6;
export type DisplayCommercialQualityIssueKind = 'invalid-path' | 'tiny-interior-segment' | 'excessive-bends';
export type DisplayCommercialQualityIssue = Readonly<{
    edgeId: string;
    kind: DisplayCommercialQualityIssueKind;
    value: number;
    limit: number;
}>;
/**
 * A trusted external candidate also needs a topology-independent structural
 * contract. Route length and endpoint-envelope overshoot are intentionally not
 * hard failures: a crossing-free orthogonal graph can require an outer lane
 * when existing trunks form a separator. Those metrics need a graph-aware
 * alternative candidate, while micro segments and pathological bend chains
 * are unambiguously rejectable from the path alone.
 */
export declare const auditBaseReactFlowDisplayCommercialQuality: (edges: readonly Edge[]) => DisplayCommercialQualityIssue[];
export declare const baseReactFlowDisplayCommercialQualityIsClean: (edges: readonly Edge[]) => boolean;
export declare const baseReactFlowDisplayCommercialQualityDoesNotRegress: (baselineEdges: readonly Edge[], candidateEdges: readonly Edge[]) => boolean;
/**
 * Keep a separately named candidate contract at the Worker trust boundary so
 * future candidate-only rules cannot silently diverge from final promotion.
 */
export declare const baseReactFlowDisplayCandidateCommercialQualityIsClean: (edges: readonly Edge[]) => boolean;
/**
 * An exact hard-clean route that also satisfies the external candidate
 * contract is already a stable Worker commit. Re-entering the complete
 * endpoint/commercial pipeline cannot make it more eligible for reuse: the
 * next request would accept this exact geometry at the candidate boundary.
 */
export declare const canCommitBaseReactFlowDisplayCandidateWithoutStabilization: (hardClean: boolean, edges: readonly Edge[] | undefined) => boolean;
/**
 * Internally generated routes have already established their shared-trunk
 * provenance. Retain that final-route contract when deciding whether another
 * stabilization pass is necessary. External candidates still use the stricter
 * candidate contract, which cannot trust an asserted synthesis flag.
 */
export declare const canCommitBaseReactFlowDisplayFinalRoutesWithoutStabilization: (hardClean: boolean, edges: readonly Edge[] | undefined, generatedInternally: boolean) => boolean;
/**
 * A hard-clean route may need a modest outer detour to replace a pathological
 * bend chain. The allowance scales only with bends actually removed and is
 * available only when the replacement satisfies the complete structural
 * commercial contract.
 */
export declare const commercialBendSimplificationLengthBudget: (baseline: Edge, candidate: Edge) => number;
