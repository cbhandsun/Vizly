import type { Edge, Node } from '@xyflow/react';
export interface DisplayTangentTrunkShortcut {
    readonly key: string;
    readonly changedEdgeIndexes: number[];
    readonly edges: Edge[];
    readonly saving: number;
}
/** A source bundle moves as one transaction so its side, members and shared
 * stem survive. Business clearance is a cheap prefilter; the caller must still
 * run the complete graph-wide hard-quality and trunk gates. */
export declare const buildDisplayTangentTrunkShortcuts: (edges: Edge[], nodes: Node[], requestedKey?: string) => DisplayTangentTrunkShortcut[];
