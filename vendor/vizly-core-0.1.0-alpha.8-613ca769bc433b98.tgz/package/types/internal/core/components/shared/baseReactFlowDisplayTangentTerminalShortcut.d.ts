import type { Edge, Node } from '@xyflow/react';
/** Moves automatic L-route or facing terminals along their current sides. The caller
 * still owns the whole-graph obstacle, endpoint order and true-trunk gates. */
export declare const buildDisplayTangentTerminalShortcuts: (edge: Edge, nodes: Node[]) => Edge[];
