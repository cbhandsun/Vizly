import { type AnchorSide, type NodeRect } from './baseReactFlowDisplayEdgeGeometry.js';
/** Bounded perimeter alternatives when short fixed-port corridors fold back. */
export declare const buildDisplayExteriorCorridors: (source: NodeRect, target: NodeRect, sourceSide: AnchorSide, targetSide: AnchorSide) => Array<Array<{
    x: number;
    y: number;
}>>;
