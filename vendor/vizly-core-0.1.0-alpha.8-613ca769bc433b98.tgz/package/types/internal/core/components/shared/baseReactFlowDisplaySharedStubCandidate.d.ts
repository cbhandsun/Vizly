import type { Edge } from '@xyflow/react';
/** Propose moving an exact shared terminal trunk together, never its endpoints.
 * The caller still owns whole-graph quality, clearance, port and trunk gates.
 */
export declare const buildSharedRenderSafeStubCandidate: <T extends Edge[]>(baseline: T, candidate: T, primaryIndex: number, allowSubpixelOrigins?: boolean) => T;
