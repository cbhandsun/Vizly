/** Keep overview grids legible while retaining alignment to the original grid. */
export declare function resolveCanvasGridGap(gap: number, zoom: number): number;
