import type { Edge, Node } from '@xyflow/react';
import { type BusinessNodeClearanceGeometryContext } from '../../strategies/shared/edgeBusinessNodeClearanceGeometryContext.js';
import { auditFinalSameSideEndpointOrder } from '../../strategies/shared/edgeFinalSameSideEndpointOrderRepair.js';
import { auditFinalSameSidePassageOrder } from '../../strategies/shared/edgeFinalSameSidePassageOrderRepair.js';
import { createBaseDisplayHardGateMemo } from './baseReactFlowDisplayHardGateMemo.js';
import { getDisplayTerminalValidationReport } from './baseReactFlowTerminalValidation.js';
import { type BaseReactFlowChangedHardReportEvidence } from './baseReactFlowDisplayChangedHardReport.js';
export type BaseReactFlowFinalEndpointEvaluation = Readonly<{
    nodes: Node[];
    businessNodeClearanceGeometry: BusinessNodeClearanceGeometryContext;
    endpointOrder: (edges: readonly Edge[]) => ReturnType<typeof auditFinalSameSideEndpointOrder>;
    hardReport: (edges: readonly Edge[]) => ReturnType<ReturnType<typeof createBaseDisplayHardGateMemo>['getReport']>;
    hardReportChanged: (baselineEdges: readonly Edge[], candidateEdges: readonly Edge[], changedEdgeIndexes: readonly number[], knownEvidence?: BaseReactFlowChangedHardReportEvidence) => ReturnType<ReturnType<typeof createBaseDisplayHardGateMemo>['getReport']>;
    passageOrder: (edges: readonly Edge[]) => ReturnType<typeof auditFinalSameSidePassageOrder>;
    repairRenderSafeEndpointStubs: (edges: Edge[], maxEvaluations?: number, allowStrictFallback?: boolean, allowSubpixelSharedOrigins?: boolean) => Edge[];
    rememberHardReport: (edges: readonly Edge[], report: ReturnType<ReturnType<typeof createBaseDisplayHardGateMemo>['getReport']>) => boolean;
    terminalReport: (edges: readonly Edge[]) => ReturnType<typeof getDisplayTerminalValidationReport>;
    unsafeEndpointStubs: (edges: readonly Edge[]) => number;
    readMetrics: () => BaseReactFlowEvaluationMetrics;
}>;
export type BaseReactFlowEvaluationMetrics = Readonly<{
    evaluationCount: number;
    cacheHitCount: number;
    scannedNodeCount: number;
    scannedSegmentCount?: number;
    scannedEdgePairCount: number;
    workItemCount?: number;
}>;
export declare const diffBaseReactFlowEvaluationMetrics: (before: BaseReactFlowEvaluationMetrics, after: BaseReactFlowEvaluationMetrics) => BaseReactFlowEvaluationMetrics;
/**
 * Request-local exact evidence for final endpoint transactions.
 *
 * Routing candidates are immutable arrays. Reusing evidence for the same
 * array avoids rebuilding terminal snapshots and rescanning an unchanged
 * baseline for every sibling candidate; distinct arrays still receive their
 * own complete hard/order evaluation.
 */
export declare const createBaseReactFlowFinalEndpointEvaluation: (nodes: Node[], eligibleEdgeIds?: ReadonlySet<string>) => BaseReactFlowFinalEndpointEvaluation;
