import type { Edge, Node } from '@xyflow/react';
/** A topology port change may need its same-side peers to negotiate lane order.
 * Promote only defective groups touched by the transaction, with the existing
 * eight-edge topology bound. The final exact and immutable-boundary gates still
 * validate every resulting route. */
export declare const resolveIncrementalEndpointOrderScope: (edges: Edge[], nodes: Node[], initial: ReadonlySet<string>) => Set<string>;
