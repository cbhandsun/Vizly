import { type BackgroundVariant } from '@xyflow/react';
export declare function AdaptiveCanvasBackground({ color, variant, gap }: {
    color?: string;
    variant?: BackgroundVariant;
    gap?: number;
}): import("react").JSX.Element;
