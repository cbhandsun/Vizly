import type { Edge, Node } from '@xyflow/react';
/** Distinct semantic networks may cross with bridges; branches of the same
 * network should join instead of crossing one another. */
export declare const countCompatibleSharedEndpointCrossings: (edges: readonly Edge[]) => number;
/** A visual concern, separate from the geometric validity of a persisted route. */
export declare function incompatibleSharedTrunkLength(edges: readonly Edge[]): number;
/** Split incompatible styles at the final route boundary, moving each compatible
 * group atomically and retaining every existing geometric/clearance contract. */
export declare function separateDisplaySemanticTrunks(edges: Edge[], nodes: Node[]): Edge[];
