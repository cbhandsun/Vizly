import type { Edge, Node } from '@xyflow/react';
/** Give a boxed-in automatic straight connector a private label corridor by
 * moving a neighboring interior track outward, without adding bends.
 * Endpoints remain fixed; the complete graph's hard/commercial gate must pass.
 * Manual paths and incremental transactions remain unchanged. */
export declare const repairStraightDisplayLabelCorridors: (edges: Edge[], nodes: readonly Node[], validate: (candidate: Edge[]) => boolean) => Edge[];
