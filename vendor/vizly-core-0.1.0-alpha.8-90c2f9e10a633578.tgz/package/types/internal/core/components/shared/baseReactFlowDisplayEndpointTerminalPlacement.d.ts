import type { Edge, Node, XYPosition } from '@xyflow/react';
import { type AnchorSide, type NodeRect } from './baseReactFlowDisplayEdgeGeometry.js';
export type EndpointRole = 'source' | 'target';
export declare const centeredTerminalOnSide: (rect: NodeRect, side: AnchorSide) => XYPosition;
export declare const insetTerminalOnSide: (terminal: XYPosition, rect: NodeRect, side: AnchorSide, node?: unknown) => XYPosition;
export declare const countTerminalsByNodeSide: (edges: Edge[], nodeById: Map<string, Node>) => Map<string, number>;
export declare const centerUniqueTerminalRole: (edge: Edge, role: EndpointRole, nodeById: Map<string, Node>, terminalCounts: Map<string, number>, options?: {
    finalCommit?: boolean;
}) => Edge;
export declare const centerUniqueAutoTerminals: (edge: Edge, nodeById: Map<string, Node>, terminalCounts: Map<string, number>, options?: {
    finalCommit?: boolean;
}) => Edge;
export declare const centerUniqueSharedTrunkTerminals: (edges: Edge[], nodeById: Map<string, Node>, validateTransaction: (candidateEdges: Edge[], changedIndexes: number[]) => boolean) => Edge[];
export declare const balanceSameSideTerminalBlocks: (edges: Edge[], nodeById: Map<string, Node>, validateTransaction: (candidateEdges: Edge[], changedIndexes: number[]) => boolean) => Edge[];
