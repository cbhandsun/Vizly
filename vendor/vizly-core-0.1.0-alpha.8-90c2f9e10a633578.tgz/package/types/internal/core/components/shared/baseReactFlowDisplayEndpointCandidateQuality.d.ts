import type { Edge, Node, XYPosition } from '@xyflow/react';
export declare const computedEndpointPathOf: (edge: Edge) => XYPosition[];
export declare const displayEndpointCandidateDegradesGraph: ({ candidate, original, edgeIndex, contextEdges, nodes, allowExistingCrossings, }: {
    candidate: Edge;
    original: Edge;
    edgeIndex: number;
    contextEdges: Edge[];
    nodes: Node[];
    allowExistingCrossings?: boolean;
}) => boolean;
