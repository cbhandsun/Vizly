import type { Edge, Node } from '@xyflow/react';
/**
 * Lightweight terminal boundary commit used by intermediate seed/render-mode
 * transitions so early routing trajectories remain deterministic and fast.
 */
export declare const commitIntermediateDisplayEdgeTerminals: (edges: Edge[], nodes: Node[], nodeById?: Map<string, Node>) => Edge[];
/**
 * Commits only terminal boundary geometry after route quality selection.
 *
 * Unlike the interactive endpoint beautifier below, this boundary does not
 * fold dominant-axis elbows. It keeps the accepted route lanes intact while
 * snapping sub-pixel terminal drift, centering single-endpoint or unique
 * shared-trunk sides, balancing multi-block terminal clusters, and turning a
 * boundary tangent into one short outward stub when the adjacent lane already
 * provides enough room.
 */
export declare const commitComputedDisplayEdgeTerminals: (edges: Edge[], nodes: Node[], nodeById?: Map<string, Node>) => Edge[];
export declare const anchorComputedDisplayEdgeEndpoints: (edges: Edge[], nodes: Node[]) => Edge[];
