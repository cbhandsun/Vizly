import type { Edge, Node } from '@xyflow/react';
import type { RoutingPatch } from '../../routing/routingPatch.js';
import { type EdgePathQualityEvaluationContext } from '../../strategies/shared/edgeStrictCrossingGuard.js';
export type StrictCrossingRepairDiagnostics = {
    qualityEvaluationCount: number;
    qualityContextCacheHitCount: number;
    qualityScoreCacheHitCount: number;
    pairCacheHitCount: number;
    segmentQueryCacheHitCount: number;
    nodeContextBuildCount: number;
    scannedEdgePairCount: number;
    scannedSegmentCount: number;
    duplicateVariantReferenceCount: number;
    knownQualityStrictReuseCount: number;
    residualRepairInvocationCount: number;
    strictFallbackInvocationCount: number;
    strictSweepInvocationCount: number;
};
export declare function createStrictCrossingRepairDiagnostics(): StrictCrossingRepairDiagnostics;
export declare function addStrictCrossingRepairDiagnostics(target: StrictCrossingRepairDiagnostics, delta: Readonly<StrictCrossingRepairDiagnostics>): void;
type CachedStrictRepairEntry = {
    baselineEdges: readonly Edge[];
    repairedEdges: readonly Edge[];
    repairedSignature: string;
    unchanged: boolean;
    patches?: RoutingPatch[] | null;
    diagnosticsDelta: StrictCrossingRepairDiagnostics;
};
type StrictRepairNodeCache = {
    byEdges: WeakMap<readonly Edge[], CachedStrictRepairEntry>;
    bySignature: Map<string, CachedStrictRepairEntry>;
};
export type StrictRepairMemoCache = WeakMap<Node[], StrictRepairNodeCache>;
export declare function createStrictRepairMemoCache(): StrictRepairMemoCache;
export declare function computeStrictRepairRouteSignature(edges: readonly Edge[]): string | null;
export declare function runMemoizedStrictCrossingRepair<T extends Edge[]>(cache: StrictRepairMemoCache, edges: T, nodes: Node[], diagnostics: StrictCrossingRepairDiagnostics | undefined, compute: (localDiagnostics: StrictCrossingRepairDiagnostics) => T): T;
export declare const countTrackedStrictCrossings: (edges: Edge[], diagnostics?: StrictCrossingRepairDiagnostics) => number;
export declare const createTrackedStrictQualityContext: (edges: Edge[], diagnostics?: StrictCrossingRepairDiagnostics) => EdgePathQualityEvaluationContext;
export {};
