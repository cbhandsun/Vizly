import type { FC, ReactNode } from 'react';
import type { MessageInstance } from 'antd/es/message/interface';
import type { ModalStaticFunctions } from 'antd/es/modal/confirm';
import type { NotificationInstance } from 'antd/es/notification/interface';

export declare const registerAntdApi: (
  message: MessageInstance,
  modal: Omit<ModalStaticFunctions, 'warn'>,
  notification: NotificationInstance,
) => void;
export declare const appMessage: MessageInstance;
export declare const appModal: Omit<ModalStaticFunctions, 'warn'>;
export declare const appNotification: NotificationInstance;
export declare const AntdApiBridge: FC<{ children: ReactNode }>;
