export {
  DiagramConfigManager,
  defaultConfig,
  diagramConfigManager,
} from './internal/core/config/DiagramConfig.js';
export type {
  CanvasConfig,
  DiagramConfig,
  DomainConfig,
  EdgeConfig,
  NodeConfig,
  SubDomainConfig,
} from './internal/core/config/DiagramConfig.js';

export {
  CONFIG_PRIORITY,
  ConfigLayer,
  LayeredConfigManager,
} from './internal/core/config/LayeredConfigManager.js';
export type {
  CloudStorageAdapter,
  ConfigLayerData,
  ConfigSchema,
  ConfigValidator,
  LayeredConfigChangeEvent,
  LayeredConfigListener,
} from './internal/core/config/LayeredConfigManager.js';
