import type { DisplayPoint, DisplaySegment } from './baseReactFlowDisplayGeometry.js';
export type DisplayStrictCrossingCounterMetrics = {
    candidateVisitCount: number;
};
/**
 * Snapshot a caller-filtered set of blockers for a candidate search. Like the
 * standalone display scorer, this counts unresolved crossings for supplied
 * segments, including related/self segments; edge filtering belongs to callers.
 * No route or user metadata is retained and no mutable input reference is cached.
 */
export declare const createDisplayStrictCrossingCounter: (blockers: readonly DisplaySegment[], metrics?: DisplayStrictCrossingCounterMetrics) => ((path: readonly DisplayPoint[]) => number);
