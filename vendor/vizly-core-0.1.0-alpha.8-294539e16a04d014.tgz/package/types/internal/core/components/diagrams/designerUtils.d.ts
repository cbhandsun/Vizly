import { Node, Edge } from '@xyflow/react';
import { StandardDiagramData } from '../../models/DiagramModels.js';
import type { StandardDataToCanvasOptions } from './designerPersistenceBoundary.js';
export type { StandardDataToCanvasOptions } from './designerPersistenceBoundary.js';
/**
 * Converts React Flow canvas data into the application's StandardDiagramData format.
 * Strictly follows STANDARD_DIAGRAM_DATA_AI_GUIDE.md
 */
export declare const canvasToStandardData: (nodes: Node[], edges: Edge[], diagramName?: string) => StandardDiagramData;
/**
 * Converts React Flow canvas data into a Pure StandardData format (For AI / Smart Layout)
 * Strips out UI constraints, coordinates, groups, sizing, and handles.
 */
export declare const canvasToPureStandardData: (nodes: Node[], edges: Edge[], diagramName?: string) => StandardDiagramData;
/**
 * Converts StandardDiagramData back to React Flow nodes/edges for editing.
 *
 * 对齐新项目 standardToGraphData：
 * - 有 canvasPosition 时：恢复保存的坐标
 * - 没有 canvasPosition 时：
 *   - 有多域（≥2）：调用 DomainDagreLayoutStrategy（含域容器生成+智能边路由）
 *   - 无多域：内部扁平 dagre 布局
 */
export declare const standardDataToCanvas: (inputData: StandardDiagramData, pluginId?: string, options?: StandardDataToCanvasOptions) => Promise<{
    nodes: Node[];
    edges: Edge[];
}>;
/**
 * Downloads a JSON object as a file
 */
export declare const downloadJson: (data: object, filename: string) => void;
