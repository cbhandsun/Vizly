export * from './internal/core/public/demo-performance.js';
