# Third-party components distributed with Vizly Core

Vizly Core's proprietary terms do not replace the following components' own licenses.

`THIRD_PARTY_LICENSES.txt` includes the license texts for the 30 JavaScript
packages identified in the Core build's module graph. Their package names,
versions, and declared licenses are listed alongside the corresponding texts.

The SDK build replaces jsPDF's optional HTML and `addSvgAsImage` dependency
loaders with rejected promises. Raster PDF exports use `addImage`; vector PDF
exports use `svg2pdf`. The remaining jsPDF implementation and its MIT license
are preserved.

The SDK build adds cooperative scheduling and cancellation checks at the entry
of html-to-image's DOM clone function. Its style, media and SVG cloning logic
and MIT license are preserved; the installed upstream source is unchanged.

## ELK layout Worker

- Component: `elkjs@0.12.0` (`elkjs/lib/elk-worker.min.js`)
- License used for distribution: Eclipse Public License 2.0, in `EPL-ELK.md`
- Source code: <https://github.com/kieler/elkjs/tree/0.12.0>
- Source archive: <https://github.com/kieler/elkjs/archive/refs/tags/0.12.0.tar.gz>
- Build transformation: Vizly's build minifies the package's `elk-worker.min.js` again and emits it as a separate `elk-engine-worker-*.js` asset. Vizly does not modify the upstream source files.

The ELK source remains available under EPL-2.0 at the versioned location above. Recipients may exercise the rights granted by EPL-2.0 for that component.

## Noto Sans SC font subset

- Component: the font data from `@reogrid/font-sc@1.0.1`
- License: SIL Open Font License 1.1, in `OFL-NotoSansSC.txt`
- Source package: <https://www.npmjs.com/package/@reogrid/font-sc/v/1.0.1>
- Build transformation: Vizly decodes the dependency's Base64 font data and emits a separate `vizly-noto-sans-sc-*.ttf` asset for PDF export. Vizly does not alter the font outlines.
