import type { Edge, Node } from '@xyflow/react';
/** A layout engine's port is a proposal, not an authored constraint. When the
 * facing sides overlap, test straight lanes before retaining an exterior loop.
 * The complete graph gate owns obstacles, labels, shared trunks and crossings. */
export declare const repairDisplayFacingPorts: (edges: Edge[], nodes: Node[]) => Edge[];
/** A long side return can approach the adjacent face more directly. Reserve
 * a full terminal stub and derive any obstacle skirt from node boundaries;
 * changing the face and skirt is one validated transaction. */
export declare const repairDisplayAdjacentReturnPorts: (edges: Edge[], nodes: Node[]) => Edge[];
