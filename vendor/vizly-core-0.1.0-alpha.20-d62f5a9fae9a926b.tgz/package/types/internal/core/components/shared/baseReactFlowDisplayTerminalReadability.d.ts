import type { Edge, Node } from '@xyflow/react';
/** Accept complete transactions only: moving a crowded side must not improve
 * its outer port by crossing a sibling, losing a trunk or grazing a container. */
export declare const acceptsDisplayTerminalReadability: (before: Edge[], after: Edge[], nodes: Node[], redistributeCrossings?: boolean, extraBends?: number) => boolean;
/** Mixed-axis endpoints can sometimes share a single elbow. Keep their exact
 * positions and departure/arrival directions; obstacles and peer routes decide
 * whether the extra corridor is necessary. No layout or semantic IDs are used. */
export declare const repairDisplayMixedTerminalDetours: (edges: Edge[], nodes: Node[]) => Edge[];
/** Compress automatic terminal blocks into a readable inset, preserving their
 * order and keeping every shared port together. Fixed and straight terminals
 * remain constraints; an infeasible side is left unchanged. */
export declare const repairDisplayCornerTerminalBlocks: (edges: Edge[], nodes: Node[]) => Edge[];
/** Move an automatic straight connection as a whole. Its two ports are coupled:
 * moving just one would introduce an elbow or detach the other endpoint. */
export declare const repairDisplayStraightCornerTerminals: (edges: Edge[], nodes: Node[]) => Edge[];
export declare const repairDisplayTerminalReadability: (edges: Edge[], nodes: Node[]) => Edge[];
