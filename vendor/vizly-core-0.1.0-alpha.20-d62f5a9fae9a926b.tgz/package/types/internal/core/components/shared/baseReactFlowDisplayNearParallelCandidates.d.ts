import type { Edge, Node } from '@xyflow/react';
import { type DisplayPoint, type DisplaySegment } from './baseReactFlowDisplayGeometry.js';
export declare const buildNearParallelLaneNudgePaths: (path: DisplayPoint[], segment: DisplaySegment, other: DisplaySegment, otherPath: DisplayPoint[], nodes: Node[], edge: Edge, allEdges: Edge[], maxCandidates?: number) => DisplayPoint[][];
/** Separate a crowded lane and its adjacent bend together. A lane-only shift
 * can place the new crossing beside a bend, so neither one-axis move is safe
 * in isolation. Preserve terminal coordinates and the original bend count. */
export declare const buildCompoundParallelLaneNudgePaths: (path: DisplayPoint[], segment: DisplaySegment, other: DisplaySegment) => DisplayPoint[][];
