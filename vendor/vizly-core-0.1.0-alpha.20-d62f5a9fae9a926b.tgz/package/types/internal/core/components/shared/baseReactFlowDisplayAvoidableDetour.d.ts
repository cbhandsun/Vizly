import type { Edge, Node } from '@xyflow/react';
/**
 * Returns the IDs of edges whose restored route is an avoidable detour. The
 * caller must pass nodes with absolute positions (the Worker repair nodes).
 */
export declare const findDisplayAvoidableDetourEdgeIds: (edges: readonly Edge[], nodes: Node[]) => string[];
