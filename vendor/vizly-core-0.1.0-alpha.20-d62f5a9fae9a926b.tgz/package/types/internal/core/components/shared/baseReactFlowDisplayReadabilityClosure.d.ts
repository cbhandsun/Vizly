import type { Edge, Node } from '@xyflow/react';
export declare const closeDisplayLayoutReadability: (edges: Edge[], nodes: Node[]) => Edge[];
