import type { Edge, Node } from '@xyflow/react';
/** Keep a newly edited branch on its requested side, but place its terminal
 * beside an existing incoming/outgoing stem before moving any frozen peer. */
export declare const buildBaseReactFlowTopologyTerminalLaneCandidates: ({ edges, changedEdgeIds, nodes, }: {
    edges: Edge[];
    changedEdgeIds: ReadonlySet<string>;
    nodes: Node[];
}) => Edge[][];
/**
 * Aligns only a promoted crossing edge with a trusted same-target/source trunk.
 * The changed edge and every terminal handle remain untouched. Callers retain
 * ownership of boundary, exact hard, commercial-clearance, and final gates.
 */
export declare const buildBaseReactFlowTopologyStrictTransactionCandidates: <T extends Edge[]>({ edges, changedEdgeIds, promotedEdgeIds, }: {
    edges: T;
    changedEdgeIds: ReadonlySet<string>;
    promotedEdgeIds: ReadonlySet<string>;
}) => T[];
