import type { Edge, Node } from '@xyflow/react';
import type { DisplayEdgesWorkerRequest, DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerProtocol.js';
/** Polish the actual locked geometry once, after all existing repairs finish. */
export declare function polishLockedDisplayCorridors(edges: Edge[], nodes: Node[], eligibleEdgeIds?: ReadonlySet<string>, allowReturnCorridors?: boolean): Edge[];
export declare function polishDisplayLayoutReadability(edges: Edge[], nodes: Node[]): Edge[];
export declare function finalizeDisplayWorkerReturnCorridorResponse(request: DisplayEdgesWorkerRequest, response: DisplayEdgesWorkerResponse): DisplayEdgesWorkerResponse;
