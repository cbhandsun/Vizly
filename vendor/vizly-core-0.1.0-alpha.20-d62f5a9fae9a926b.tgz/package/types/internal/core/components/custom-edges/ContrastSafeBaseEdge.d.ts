import React from 'react';
import { type BaseEdgeProps } from '@xyflow/react';
export interface ContrastSafeBaseEdgeProps extends BaseEdgeProps {
    canvasBackground?: unknown;
    ancestorOpacity?: unknown;
}
export declare function ContrastSafeBaseEdge({ ancestorOpacity, canvasBackground, className, style, ...props }: ContrastSafeBaseEdgeProps): React.JSX.Element;
export declare namespace ContrastSafeBaseEdge {
    var displayName: string;
}
