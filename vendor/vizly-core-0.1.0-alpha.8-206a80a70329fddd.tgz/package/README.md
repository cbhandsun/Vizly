# @vizly/core

Compiled Vizly editor runtime. Core source remains private. The bundled
`LICENSE` has been approved by the rights holder. Distribution of the unmodified
compiled package as a noncommercial Vizly application dependency must retain
the license and notices. Commercial production deployment requires separate
written authorization. npm publication requires an explicit owner-approved
SDK release request.

Import `@vizly/core/react` for the low-level React editor and
`@vizly/core/style.css` once in the host application.

Hosts can import `DiagramControlBridge` from `@vizly/core/editor-control-bridge`
without loading command search. Load `@vizly/core/editor-ui` on demand when
opening `CommandPalette`; the existing combined entry remains compatible.
