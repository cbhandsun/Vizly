export * from './internal/core/public/demo-edge-mode.js';
export { default } from './internal/core/public/demo-edge-mode.js';
