export interface AnalysisIssue {
  type: 'orphan_node' | 'duplicate_edge' | 'self_loop' | 'missing_label'
    | 'layout_suggestion' | 'connectivity' | 'layer_violation' | 'cyclic_dependency';
  severity: 'info' | 'warning' | 'error';
  message: string;
  relatedIds: string[];
  suggestedPrompt?: string;
}

export interface AnalysisResult {
  issues: AnalysisIssue[];
  stats: {
    nodeCount: number;
    edgeCount: number;
    orphanCount: number;
    connectedComponents: number;
    maxDepth: number;
  };
  summary: string;
}

export interface AnalysisNode {
  id: string;
  type?: string;
  position?: { x: number; y: number };
  data?: { label?: string; description?: string; domainClass?: string };
  parentId?: string;
}

export interface AnalysisEdge {
  id: string;
  source: string;
  target: string;
  label?: string;
}

export declare const analyzeDiagram: (
  nodes: AnalysisNode[],
  edges: AnalysisEdge[],
) => AnalysisResult;
