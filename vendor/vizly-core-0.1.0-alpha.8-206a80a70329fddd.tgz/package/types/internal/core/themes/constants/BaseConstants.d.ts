/**
 * 基础主题常量
 * 定义所有主题共享的基础常量
 */
import type { ThemeTypography, ThemeSpacing, ThemeBorderRadius, ThemeShadow, ThemeAnimation } from '../types/ThemeTypes.js';
export declare const baseTypography: ThemeTypography;
export declare const baseSpacing: ThemeSpacing;
export declare const baseBorderRadius: ThemeBorderRadius;
export declare const baseShadow: ThemeShadow;
export declare const baseAnimation: ThemeAnimation;
