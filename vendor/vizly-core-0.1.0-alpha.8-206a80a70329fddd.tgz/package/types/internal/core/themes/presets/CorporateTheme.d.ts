/**
 * 商务主题
 * 稳定的企业演示配色，保留原有 corporate id 以兼容已保存图表。
 */
export declare const corporateThemePreset: import("..").ThemePreset;
