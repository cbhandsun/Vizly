import type { ThemeColor, ThemeMode, ThemePalette, ThemePreset } from '../types/ThemeTypes.js';
export interface CommercialThemeColorInput {
    main: string;
    light: string;
    dark: string;
    border: string;
    background: string;
    text: string;
    shadow: string;
    contrast?: string;
}
export interface CommercialThemeDomainSet {
    channel: ThemeColor;
    frontend: ThemeColor;
    corporateBackend: ThemeColor;
    supplyChainBackend: ThemeColor;
    logisticsBackend: ThemeColor;
    middleware: ThemeColor;
    data: ThemeColor;
    infra: ThemeColor;
    external: ThemeColor;
}
export interface CommercialThemeConfig {
    id: string;
    name: string;
    description: string;
    mode: ThemeMode;
    tags: string[];
    palette: ThemePalette;
    domains: CommercialThemeDomainSet;
    edges: {
        default: ThemeColor;
        primary: ThemeColor;
        secondary: ThemeColor;
        dashed: ThemeColor;
    };
    canvas: {
        background: string;
        gridColor: string;
        gridOpacity: number;
    };
    nodes: {
        default: ThemeColor;
        selected: ThemeColor;
        hover: ThemeColor;
    };
}
export declare const commercialColor: ({ main, light, dark, border, background, text, shadow, contrast, }: CommercialThemeColorInput) => ThemeColor;
export declare const createCommercialThemePreset: (config: CommercialThemeConfig) => ThemePreset;
