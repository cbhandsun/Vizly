/**
 * 蓝图主题 — 工程制图风格
 * 深蓝底色 + 白/浅蓝线条 + 冷色系域
 */
import { ThemePreset } from '../types/ThemeTypes.js';
export declare const blueprintThemePreset: ThemePreset;
