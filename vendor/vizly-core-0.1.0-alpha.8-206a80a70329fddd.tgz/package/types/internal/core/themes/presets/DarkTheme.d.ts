/**
 * 深色主题定义
 */
import { ThemePreset } from '../types/ThemeTypes.js';
export declare const darkThemePreset: ThemePreset;
