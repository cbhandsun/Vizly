export declare const catppuccinThemePreset: import("..").ThemePreset;
