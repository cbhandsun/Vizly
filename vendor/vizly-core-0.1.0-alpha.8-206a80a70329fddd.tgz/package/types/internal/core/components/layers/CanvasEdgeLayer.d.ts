import React from 'react';
/**
 * Canvas Edge Layer
 *
 * Renders edges using HTML5 Canvas 2D Context for high performance.
 * This skips the DOM overhead of thousands of SVG elements.
 *
 * Usage:
 * Place this component inside <ReactFlow>.
 * Ensure standard edges are hidden or use a 'null' edge type to prevent double rendering.
 */
declare const CanvasEdgeLayer: React.MemoExoticComponent<() => React.JSX.Element>;
export default CanvasEdgeLayer;
