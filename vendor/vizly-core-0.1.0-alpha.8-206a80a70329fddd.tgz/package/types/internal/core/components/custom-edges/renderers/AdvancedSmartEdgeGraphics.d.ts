import React from 'react';
import { EdgeProps } from '@xyflow/react';
import { UseEdgeLabelInteractionsReturn } from '../hooks/useEdgeLabelInteractions.js';
import type { SmartEdgeRoutingRenderModel } from '../smartEdgeRoutingRenderModel.js';
export interface AdvancedSmartEdgeGraphicsProps {
    props: EdgeProps;
    router: SmartEdgeRoutingRenderModel;
    labelManager: UseEdgeLabelInteractionsReturn;
}
declare const InnerAdvancedSmartEdgeGraphics: ({ props, router, labelManager }: AdvancedSmartEdgeGraphicsProps) => React.JSX.Element;
export declare const AdvancedSmartEdgeGraphics: React.MemoExoticComponent<typeof InnerAdvancedSmartEdgeGraphics>;
export {};
