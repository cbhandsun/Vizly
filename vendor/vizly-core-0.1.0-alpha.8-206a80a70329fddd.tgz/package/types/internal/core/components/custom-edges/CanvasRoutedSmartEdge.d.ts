import type { EdgeProps } from '@xyflow/react';
export declare const CanvasRoutedSmartEdge: (props: EdgeProps) => import("react").JSX.Element;
