import React from 'react';
import type { EdgeProps } from '@xyflow/react';
/**
 * AdvancedSmartEdge (Shell Component)
 * Delegating all logic domains into separate controllers and rendering through a pure graphic function.
 */
declare const InnerAdvancedSmartStepEdge: (props: EdgeProps) => React.JSX.Element;
export declare const AdvancedSmartStepEdge: React.MemoExoticComponent<typeof InnerAdvancedSmartStepEdge>;
export declare const AdvancedSmartBezierEdge: React.MemoExoticComponent<(props: EdgeProps) => React.JSX.Element>;
export declare const AdvancedSmartStraightEdge: React.MemoExoticComponent<(props: EdgeProps) => React.JSX.Element>;
declare const _default: {
    AdvancedSmartStepEdge: React.MemoExoticComponent<typeof InnerAdvancedSmartStepEdge>;
    AdvancedSmartBezierEdge: React.MemoExoticComponent<(props: EdgeProps) => React.JSX.Element>;
    AdvancedSmartStraightEdge: React.MemoExoticComponent<(props: EdgeProps) => React.JSX.Element>;
};
export default _default;
