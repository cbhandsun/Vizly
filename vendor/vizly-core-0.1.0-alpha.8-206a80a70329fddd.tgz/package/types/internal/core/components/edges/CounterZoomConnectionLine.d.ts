/**
 * CounterZoomConnectionLine — 修正 CSS zoom 导致的连线终点偏移
 *
 * 问题：FlowchartDesigner 设置了 disableZoomCompensation=true，
 * 导致 .react-flow 继承了 ant-layout 的 zoom: 0.85。
 * ReactFlow 内部计算连线终点时使用：
 *   toX = (mouseClientX - bcr.left - vp.x) / vp.zoom
 * 但正确公式应为：
 *   toX = ((mouseClientX - bcr.left) / uiScale - vp.x) / vp.zoom
 *
 * 本组件接收 ReactFlow 算出的错误 toX/toY，逆向推导并补偿 uiScale。
 */
import React from 'react';
import { ConnectionLineComponentProps } from '@xyflow/react';
export declare function CounterZoomConnectionLine({ fromX, fromY, toX, toY, fromPosition, toPosition, connectionLineStyle, }: ConnectionLineComponentProps): React.JSX.Element;
declare const _default: React.MemoExoticComponent<typeof CounterZoomConnectionLine>;
export default _default;
