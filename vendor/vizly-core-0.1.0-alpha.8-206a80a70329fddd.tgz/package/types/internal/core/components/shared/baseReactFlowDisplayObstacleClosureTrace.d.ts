import type { Edge } from '@xyflow/react';
import type { BusinessNodeClearanceRepairDiagnostics } from '../../strategies/shared/edgeBusinessNodeClearanceRepair.js';
import { type BaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
type ObstacleClosurePhase = 'final-endpoint-closure-obstacles-post-trunk' | 'final-endpoint-closure-obstacles-sibling' | 'final-endpoint-closure-obstacles-micro';
interface StartObstacleClosureTraceOptions {
    phase: ObstacleClosurePhase;
    candidateCount: number;
    evaluation: BaseReactFlowFinalEndpointEvaluation;
    onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void;
}
export declare const startBaseReactFlowObstacleClosureTrace: ({ phase, candidateCount, evaluation, onPhaseTrace, }: StartObstacleClosureTraceOptions) => (baseline: Edge[], candidate: Edge[], candidateDiagnostics?: BusinessNodeClearanceRepairDiagnostics) => void;
export {};
