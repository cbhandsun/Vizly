import React from 'react';
export declare const BaseReactFlowAlignGuide: React.FC;
export declare const BaseReactFlowRightEdgeGuides: React.FC;
