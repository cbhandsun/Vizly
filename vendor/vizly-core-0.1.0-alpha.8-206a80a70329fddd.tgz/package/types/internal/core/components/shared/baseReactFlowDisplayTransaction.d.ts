import type { Edge } from '@xyflow/react';
/**
 * Finds the smallest accepted subset of an otherwise useful multi-edge repair.
 * This keeps a crossing fix on one edge from committing an unrelated companion
 * move that introduces a long overlap elsewhere in the graph.
 */
export declare const chooseSmallestAcceptedDisplayTransaction: <T extends Edge[]>(baseline: T, candidate: T, isAccepted: (transaction: T, changedIndexes: readonly number[]) => boolean, maxEvaluations?: number) => T | null;
