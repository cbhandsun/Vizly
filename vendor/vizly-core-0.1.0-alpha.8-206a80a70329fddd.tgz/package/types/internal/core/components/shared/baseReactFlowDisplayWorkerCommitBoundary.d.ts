import type { Edge } from '@xyflow/react';
import type { DisplayEdgesWorkerRequest, DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerProtocol.js';
/** Binds a hard-clean Worker receipt to both the submitted identity and replayed geometry. */
export declare const displayWorkerCommitReceiptMatchesRequest: ({ request, response, responseEdges, }: {
    request: DisplayEdgesWorkerRequest;
    response: DisplayEdgesWorkerResponse;
    responseEdges: Edge[];
}) => boolean;
