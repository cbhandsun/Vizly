import type { Edge, Node } from '@xyflow/react';
import { type BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
export type BaseReactFlowDisplayStrictExpansionOutcome = Readonly<{
    edges: Edge[];
    changedEdgeIds: string[];
}> | null;
type StrictExpansionArguments = Readonly<{
    edges: Edge[];
    nodes: Node[];
    initialChangedEdgeIds: readonly string[];
    mutableEdgeIds: readonly string[];
    onRejectedReport?: (report: BaseDisplayBoundedCandidateReport) => void;
}>;
export declare const expandBaseReactFlowStrictCrossingClosure: (args: StrictExpansionArguments) => BaseReactFlowDisplayStrictExpansionOutcome;
export {};
