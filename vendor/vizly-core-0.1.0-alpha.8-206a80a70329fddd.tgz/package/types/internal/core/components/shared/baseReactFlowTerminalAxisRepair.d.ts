import type { Edge, Node } from '@xyflow/react';
export { createDisplayTerminalValidationSnapshot, displayTerminalValidationDoesNotRegress, displayEdgesHaveNodeAnchoredTerminals, displayEdgesHaveNodeAttachedTerminals, getDisplayTerminalValidationReport, keepDisplayTerminalValidationNonRegressing, keepNodeAnchoredTerminalCandidates, type DisplayTerminalValidation, type DisplayTerminalValidationOptions, type DisplayTerminalValidationReport, type DisplayTerminalValidationSnapshot, } from './baseReactFlowTerminalValidation.js';
export type DisplayTerminalAxisRepairDiagnostics = {
    passCount: number;
    processedEdgeCount: number;
    candidateCount: number;
    maximumCandidateCount: number;
    qualityEvaluationCount: number;
};
export declare const createDisplayTerminalAxisRepairDiagnostics: () => DisplayTerminalAxisRepairDiagnostics;
export declare const repairTerminalHandleAxisCrossings: (edges: Edge[], nodes: Node[], diagnostics?: DisplayTerminalAxisRepairDiagnostics) => Edge[];
