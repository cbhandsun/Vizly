import type { Edge } from '@xyflow/react';
export declare const commercialRepairOutputIsEquivalent: (baseline: Edge[], candidate: Edge[]) => boolean;
