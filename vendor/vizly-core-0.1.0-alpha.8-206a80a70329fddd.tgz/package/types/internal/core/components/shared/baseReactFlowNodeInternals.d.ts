type ReactFlowStoreApi = {
    getState: () => unknown;
};
type RefreshFn = () => void;
export type BaseReactFlowNodeInternalsRefreshNode = {
    id: string;
    type?: string;
    position?: unknown;
    measured?: {
        width?: number;
        height?: number;
    };
    width?: number;
    height?: number;
    style?: {
        width?: unknown;
        height?: unknown;
    };
};
export type BaseReactFlowNodeInternalsRefreshSnapshot = {
    key: string;
    nodeIds: string[];
};
/**
 * Node-internal measurements depend on mounted node identity, renderer type,
 * and dimensions. Position is intentionally excluded: React Flow already
 * tracks it, and remeasuring every handle during drag creates a full DOM scan.
 */
export declare const createBaseReactFlowNodeInternalsRefreshSnapshot: (nodes: readonly BaseReactFlowNodeInternalsRefreshNode[]) => BaseReactFlowNodeInternalsRefreshSnapshot;
export declare const readBaseReactFlowNodeInternalsRefreshNodeIds: (refreshKey: string) => string[];
export declare const getBaseReactFlowNodeElement: (container: HTMLElement | null, id: string) => HTMLElement | null;
export declare const collectBaseReactFlowMountedNodeElements: (container: HTMLElement | null, nodeIds: readonly string[]) => Map<string, HTMLElement>;
export declare const refreshBaseReactFlowNodeInternals: ({ container, nodeIds, rfStore, updateNodeInternals, }: {
    container: HTMLElement | null;
    nodeIds: string[];
    rfStore: ReactFlowStoreApi;
    updateNodeInternals: (nodeIds: string[]) => void;
}) => void;
export declare const areBaseReactFlowHandlesMeasured: ({ container, nodeIds, rfStore, }: {
    container: HTMLElement | null;
    nodeIds: string[];
    rfStore: ReactFlowStoreApi;
}) => boolean;
export declare const scheduleBaseReactFlowNodeInternalsRetry: ({ refresh, areHandlesMeasured, requestAnimationFrameImpl, cancelAnimationFrameImpl, setTimeoutImpl, clearTimeoutImpl, }: {
    refresh: RefreshFn;
    areHandlesMeasured: () => boolean;
    requestAnimationFrameImpl?: (callback: FrameRequestCallback) => number;
    cancelAnimationFrameImpl?: (handle: number) => void;
    setTimeoutImpl?: (handler: TimerHandler, timeout?: number) => number;
    clearTimeoutImpl?: (handle?: number) => void;
}) => (() => void);
export {};
