import type { Edge, Node } from '@xyflow/react';
/**
 * Promotes only frozen edges with concrete geometric evidence: their current
 * route intersects or violates the commercial clearance of a changed business
 * node. `contextEdgeIds` is a priority hint, not a complete boundary: a node
 * move can approach a previously unrelated branch. Returning null means the
 * bounded promotion budget was exceeded and the caller must fall back to a
 * full route instead of widening the incremental transaction.
 */
export declare const findBaseReactFlowBlockedContextEdgePromotions: ({ edges, nodes, changedNodeIds, contextEdgeIds, mutableEdgeIds, candidateEdgeIds, }: {
    edges: Edge[];
    nodes: Node[];
    changedNodeIds: readonly string[];
    contextEdgeIds: readonly string[];
    mutableEdgeIds?: readonly string[];
    candidateEdgeIds?: ReadonlySet<string>;
}) => string[] | null;
/**
 * Expands an incremental transaction only across a strict crossing whose
 * opposite edge is already mutable. Unrelated context edges remain frozen.
 */
export declare const findBaseReactFlowStrictContextEdgePromotions: ({ edges, mutableEdgeIds, contextEdgeIds, }: {
    edges: Edge[];
    mutableEdgeIds: ReadonlySet<string>;
    contextEdgeIds: readonly string[];
}) => string[] | null;
