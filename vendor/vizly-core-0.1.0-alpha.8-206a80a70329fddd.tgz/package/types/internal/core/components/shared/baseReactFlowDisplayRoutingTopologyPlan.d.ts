import type { Edge, Node } from '@xyflow/react';
import { type RoutingCorridorReservationPlan } from './baseReactFlowDisplayRoutingCorridorReservations.js';
export type RoutingTerminalSide = 'top' | 'right' | 'bottom' | 'left' | 'unknown';
export type RoutingSector = 'n' | 'ne' | 'e' | 'se' | 's' | 'sw' | 'w' | 'nw' | 'same';
export type RoutingFlowRole = 'main' | 'data' | 'dependency' | 'status' | 'neutral';
export type RoutingTopologyPattern = 'o2m' | 'm2o';
export type RoutingTrunkMode = 'single' | 'dual';
export type RoutingTopologyGroup = Readonly<{
    kind: 'source' | 'target';
    endpointId: string;
    side: RoutingTerminalSide;
    sector: RoutingSector;
    flowRole: RoutingFlowRole;
    topologyPattern: RoutingTopologyPattern;
    trunkMode: RoutingTrunkMode;
    laneDemand: number;
    memberEdgeIndexes: number[];
    dualRoleMemberIndexes: number[];
    endpointCenter: Readonly<{
        x: number;
        y: number;
    }> | null;
}>;
export type RoutingCorridorPlan = Readonly<{
    axis: 'horizontal' | 'vertical';
    start: number;
    end: number;
    center: number;
    capacity: number;
    laneCenters: number[];
}>;
export type RoutingTopologyPlan = Readonly<{
    nodeCount: number;
    edgeCount: number;
    groups: RoutingTopologyGroup[];
    candidateAxes: Readonly<{
        x: number[];
        y: number[];
    }>;
    corridors: RoutingCorridorPlan[];
    corridorReservations: RoutingCorridorReservationPlan;
}>;
export type RoutingTopologyWaypointAxes = Readonly<{
    x: readonly number[];
    y: readonly number[];
}>;
export type RoutingTopologyWaypointAxesByEdgeId = ReadonlyMap<string, RoutingTopologyWaypointAxes>;
/**
 * Projects topology into the narrow waypoint boundary consumed by the routing
 * strategy. Bounded large graphs stay on their frozen baseline until their
 * dedicated candidate/performance budget is proven by the 30-sample gate.
 */
export declare const createDisplayRoutingTopologyWaypointAxes: (plan: RoutingTopologyPlan, useBoundedLargeRepair: boolean) => RoutingTopologyWaypointAxes | undefined;
/**
 * Projects successful lane reservations into edge-owned waypoint axes. Dual
 * source/target reservations merge onto the same edge without exposing group
 * or corridor metadata outside the Worker routing pipeline.
 */
export declare const createDisplayRoutingTopologyWaypointAxesByEdgeId: (plan: RoutingTopologyPlan, edges: readonly Edge[], useBoundedLargeRepair: boolean) => RoutingTopologyWaypointAxesByEdgeId | undefined;
export declare const createDisplayRoutingTopologyPlan: (nodes: readonly Node[], edges: readonly Edge[]) => RoutingTopologyPlan;
