import type { Edge, Node } from '@xyflow/react';
import { type LocalDoglegRepairDiagnostics } from '../../strategies/shared/edgeLocalDoglegRepair.js';
import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
export declare const repairDisplayQualityTopology: ({ edges, nodes, topologySeedRemainsCurrent, reusePreparedGlobalRouting, repairDoglegs, onPhaseTrace, }: Readonly<{
    edges: Edge[];
    nodes: Node[];
    topologySeedRemainsCurrent: boolean;
    reusePreparedGlobalRouting: boolean;
    repairDoglegs: (edges: Edge[], diagnostics?: LocalDoglegRepairDiagnostics) => Edge[];
    onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void;
}>) => Edge[];
