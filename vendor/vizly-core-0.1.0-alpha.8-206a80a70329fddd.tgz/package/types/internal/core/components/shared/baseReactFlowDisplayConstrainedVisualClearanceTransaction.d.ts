import type { Edge, Node } from '@xyflow/react';
import type { DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerProtocol.js';
export declare const closeConstrainedVisualBusinessNodeClearance: ({ response, repairNodes, exactReport, lockComputedPaths, constrainedEdgeIds, endpointTopologyDoesNotRegress, }: Readonly<{
    response: DisplayEdgesWorkerResponse;
    repairNodes: Node[];
    exactReport: (candidate: DisplayEdgesWorkerResponse, repairNodes: Node[]) => DisplayEdgesWorkerResponse;
    lockComputedPaths: (edges: Edge[]) => Edge[];
    constrainedEdgeIds: ReadonlySet<string>;
    endpointTopologyDoesNotRegress: (baseline: Edge[], candidate: Edge[], nodes: Node[]) => boolean;
}>) => DisplayEdgesWorkerResponse;
