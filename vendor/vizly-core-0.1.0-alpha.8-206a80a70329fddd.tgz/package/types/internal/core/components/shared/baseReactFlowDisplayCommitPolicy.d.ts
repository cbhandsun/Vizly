import type { DisplayEdgesWorkerRouteResolution, DisplayQualityMode } from './baseReactFlowDisplayWorkerProtocol.js';
export declare const shouldRepairBaseReactFlowDisplayResult: ({ hardClean, }: {
    qualityMode: DisplayQualityMode;
    hardClean: boolean;
}) => boolean;
export declare const canCommitBaseReactFlowDisplayResult: ({ qualityMode, hardClean, routeResolution, routesMatch, }: {
    qualityMode: DisplayQualityMode;
    hardClean: boolean;
    routeResolution: DisplayEdgesWorkerRouteResolution;
    routesMatch: boolean;
}) => boolean;
