/**
 * Returns the capture preset only when the bounded query and active hash route
 * name the same valid preset. Ordinary user URLs therefore retain the normal
 * large-graph interactive policy.
 */
export declare const resolveBaseReactFlowPrecompiledCapturePresetId: ({ search, hash, }: {
    search: unknown;
    hash: unknown;
}) => string | null;
/**
 * Regeneration is deliberately separate from capture mode. Capture mode keeps
 * the production full-quality policy used by performance verification, while
 * regeneration also bypasses every external route candidate so generated
 * artifacts cannot validate and reproduce themselves.
 */
export declare const resolveBaseReactFlowPrecompiledRegenerationPresetId: ({ search, hash, }: {
    search: unknown;
    hash: unknown;
}) => string | null;
export declare const resolveBaseReactFlowPrecompiledRegenerationPresetIdFromWindow: () => string | null;
export type BaseReactFlowPrecompiledLayoutRegeneration = Readonly<{
    presetId: string;
    variantId: string;
}>;
export declare const resolveBaseReactFlowPrecompiledLayoutRegeneration: ({ search, hash, }: {
    search: unknown;
    hash: unknown;
}) => BaseReactFlowPrecompiledLayoutRegeneration | null;
export declare const resolveBaseReactFlowPrecompiledLayoutRegenerationFromWindow: () => BaseReactFlowPrecompiledLayoutRegeneration | null;
export type BaseReactFlowPrecompiledCommittedRouteCapture = Readonly<{
    presetId: string;
    variantId?: string;
    provenance?: 'fresh-layout-repair-validated' | 'fresh-full-route';
    inputSignature: string;
    inputGeometryDigest: string;
    outputRouteSignature: string;
    sourceEdges: Edge[];
    displayPatches: RoutingPatch[];
}>;
/**
 * Publishes the already signature-verified committed snapshot only for the
 * explicit localhost regeneration path. The bridge is intentionally separate
 * from phase trace/DOM diagnostics so route geometry is never logged or
 * serialized into ordinary diagnostics.
 */
export declare const publishBaseReactFlowPrecompiledCommittedRoute: (capture: BaseReactFlowPrecompiledCommittedRouteCapture) => boolean;
import type { Edge } from '@xyflow/react';
import type { RoutingPatch } from '../../routing/routingPatch.js';
