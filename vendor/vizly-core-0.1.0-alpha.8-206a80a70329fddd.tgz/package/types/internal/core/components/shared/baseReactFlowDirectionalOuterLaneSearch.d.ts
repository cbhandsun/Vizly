export type DirectionalOuterLaneCandidateBatch<T> = {
    candidates: T[];
    tier: number;
};
type ProgressiveDirectionalOuterLaneSearchOptions<T> = {
    laneCount: number;
    sourceStubCount: number;
    targetStubCount: number;
    createCandidates: (laneIndex: number, sourceStubIndex: number, targetStubIndex: number) => Iterable<T>;
    candidateKey: (candidate: T) => string;
    batchSize?: number;
};
/**
 * Streams the directional outer-lane Cartesian search from the most useful
 * lanes/stubs to the full search space. Each coordinate is visited once and
 * globally duplicate candidate paths are emitted once, so a consumer may stop
 * after a clean candidate without first materializing the exhaustive fallback.
 */
export declare function streamDirectionalOuterLaneCandidateBatches<T>({ laneCount, sourceStubCount, targetStubCount, createCandidates, candidateKey, batchSize, }: ProgressiveDirectionalOuterLaneSearchOptions<T>): Generator<DirectionalOuterLaneCandidateBatch<T>>;
export {};
