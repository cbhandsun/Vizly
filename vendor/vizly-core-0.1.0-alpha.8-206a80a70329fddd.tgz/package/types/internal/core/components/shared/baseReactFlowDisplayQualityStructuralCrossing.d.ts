import type { Edge, Node } from '@xyflow/react';
import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
interface RepairQualityStructuralCrossingsOptions {
    edges: Edge[];
    nodes: Node[];
    onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void;
}
export declare const repairBaseReactFlowQualityStructuralCrossings: ({ edges, nodes, onPhaseTrace, }: RepairQualityStructuralCrossingsOptions) => Edge[];
export {};
