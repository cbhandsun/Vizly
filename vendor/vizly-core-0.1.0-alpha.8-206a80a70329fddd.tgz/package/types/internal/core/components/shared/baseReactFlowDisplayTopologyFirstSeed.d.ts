import type { Edge, Node } from '@xyflow/react';
import { type EdgePathQualityScore } from '../../strategies/shared/edgeStrictCrossingGuard.js';
import type { RoutingTopologyPlan } from './baseReactFlowDisplayRoutingTopologyPlan.js';
export type DisplayTopologyFirstSeedResult = Readonly<{
    edges: Edge[];
    applied: boolean;
    quality?: EdgePathQualityScore;
}>;
export declare const displayTopologyFirstSeedDoesNotRegress: (baselineEdges: Edge[], candidateEdges: Edge[]) => boolean;
export declare const repairDisplayEndpointOrthogonalPathsTwice: <T extends Edge[]>(edges: T, nodes: Node[]) => T;
/**
 * Builds endpoint topology before global waypoint search. The seed is only
 * materialized when the immutable topology plan proves an O2M/M2O group is
 * present; graphs without shared endpoint topology retain their exact input.
 *
 * Every operation is routing-owned and deterministic. Callers still retain
 * the normalized input as the obstacle/quality fallback, so this seed never
 * gains commit authority by itself.
 */
export declare const createDisplayTopologyFirstSeed: (edges: Edge[], nodes: Node[], topologyPlan: RoutingTopologyPlan) => DisplayTopologyFirstSeedResult;
