import type { Edge } from '@xyflow/react';
export declare const changedDisplayPathIndexes: (baseline: Edge[], candidate: Edge[]) => number[];
export declare const collectDisplayRoutingAffectedEdgeIndexes: (baseline: Edge[], derivative: Edge[]) => number[];
