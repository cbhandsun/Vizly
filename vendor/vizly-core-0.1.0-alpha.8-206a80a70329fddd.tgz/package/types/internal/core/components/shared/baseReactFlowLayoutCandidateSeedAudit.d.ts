import type { Edge, Node } from '@xyflow/react';
export type BaseReactFlowLayoutCandidateSeedAudit = Readonly<{
    terminalsAttached: boolean;
    terminalsAnchored: boolean;
    obstacleHits: number;
    strictCrossings: number;
}>;
export declare const shouldSkipBaseReactFlowLayoutCandidateRepair: (edgeCount: number, audit: BaseReactFlowLayoutCandidateSeedAudit, allowExactCleanSeed?: boolean) => boolean;
/**
 * Flat full-graph ELK can produce an orthogonal, obstacle-clean seed whose
 * terminal segments are attached but point away from their resolved handles.
 * That is a recoverable routing defect: terminal repair and the full-route
 * pass can realign the endpoints without changing the requested layout
 * geometry, so it must not force the layout owner into a compound fallback.
 */
export declare const shouldBypassBaseReactFlowUnanchoredFlatElkCandidate: (edgeCount: number, audit: BaseReactFlowLayoutCandidateSeedAudit) => boolean;
/**
 * A fully attached lane seed with dense obstacle penetration and at least one
 * strict crossing is not a near-clean repair candidate. Keep lighter defects
 * on the bounded repair path; only this high-confidence class is sent to the
 * existing domain-compound fallback by the layout transaction owner.
 */
export declare const shouldBypassBaseReactFlowObstacleDirtyLaneCandidate: (edgeCount: number, audit: BaseReactFlowLayoutCandidateSeedAudit) => boolean;
/**
 * Produces bounded aggregate evidence for deciding whether a staged layout
 * seed is close enough for measured repair. It intentionally omits edge ids,
 * paths, node geometry, and the more expensive complete hard-quality report.
 */
export declare const auditBaseReactFlowLayoutCandidateSeed: (edges: Edge[], nodes: Node[]) => BaseReactFlowLayoutCandidateSeedAudit;
