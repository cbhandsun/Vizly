import type { TerminalPoint as Point, TerminalRect as Rect } from './baseReactFlowTerminalGeometry.js';
export interface TerminalAxisCandidateSeed {
    path: Point[];
    minimumPointCount: number;
}
type CompactTerminalPath = (path: Point[]) => Point[];
type TerminalAxisOuterCoordinateSelection = Readonly<{
    targetLanes: number[];
    trunks: number[];
}>;
export declare const createTerminalAxisCoordinatePools: (paths: readonly Point[][], obstacles: ReadonlyMap<string, Rect>, laneGap: number, terminalStub: number) => {
    x: number[];
    y: number[];
};
export declare const selectNearestTerminalAxisCoordinates: (values: readonly number[], preferred: number, limit: number) => number[];
export declare const selectTerminalAxisOuterCoordinates: ({ targetValues, trunkValues, targetPreferred, trunkPreferred, boundProduct, maximumCandidateCount, targetNearestLimit, trunkNearestLimit, }: Readonly<{
    targetValues: readonly number[];
    trunkValues: readonly number[];
    targetPreferred: number;
    trunkPreferred: number;
    boundProduct: boolean;
    maximumCandidateCount: number;
    targetNearestLimit: number;
    trunkNearestLimit: number;
}>) => TerminalAxisOuterCoordinateSelection;
export declare const selectBoundedTerminalAxisCandidates: (candidateSeeds: TerminalAxisCandidateSeed[], compactPath: CompactTerminalPath, maximumCandidateCount: number) => Point[][];
export {};
