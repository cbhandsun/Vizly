import type { Edge, Node } from '@xyflow/react';
import { getDisplayHardQualityGateReport } from './baseReactFlowDisplayQualityGates.js';
import { type BaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
/** Request-local allowance shared by early closure and the strict fallback. */
export type OuterPortEvaluationBudget = {
    remaining: number;
};
export type BaseReactFlowOuterPortTransactionOptions = Readonly<{
    evaluation?: BaseReactFlowFinalEndpointEvaluation;
    evaluationBudget?: OuterPortEvaluationBudget;
    initialReport?: Readonly<{
        edges: readonly Edge[];
        report: ReturnType<typeof getDisplayHardQualityGateReport>;
    }>;
    onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void;
}>;
/**
 * Resolves the final detached overlap/strict interlock by changing both port
 * roles and one bounded double-axis outer path as a single hard-gated
 * transaction. No partial candidate is returned.
 */
export declare const repairResidualOuterPortTransactionWithHardGate: <T extends Edge[]>(edges: T, nodes: Node[], maxExactEvaluations?: number, options?: BaseReactFlowOuterPortTransactionOptions) => T;
