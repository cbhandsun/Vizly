import type { Edge, Node } from '@xyflow/react';
import { type DisplaySegment } from './baseReactFlowDisplayGeometry.js';
import { type DisplayTerminalRole } from './baseReactFlowDisplayTerminalPolicy.js';
export type SkirtCandidate = Readonly<{
    edgeIndex: number;
    edge: Edge;
    pathLength: number;
    obstacleHits: number;
    strictCrossings: number;
    topologyPriority: number;
}>;
export type AtomicSkirtPair<T extends Edge[]> = Readonly<{
    edges: T;
    changedIndexes: readonly [number, number];
    rank: number;
}>;
export declare const buildBoundedIndependentSkirtPairs: <T extends Edge[]>(edges: T, candidates: SkirtCandidate[]) => AtomicSkirtPair<T>[];
/**
 * Moves only the crossed internal lane outside the aggregate blocker bundle.
 * Keeping both terminal stubs untouched preserves true source/target trunks;
 * this is the preferred transaction for reverse-flow lanes that cross a
 * fan-in/fan-out wall between their endpoints.
 */
export declare const buildCrossedSpineInternalLaneCandidates: (edge: Edge, edgeIndex: number, spine: DisplaySegment, nodes: Node[], otherSegments: DisplaySegment[]) => SkirtCandidate[];
export declare const buildCrossedSpineLocalWallCandidates: (edge: Edge, edgeIndex: number, spine: DisplaySegment, nodes: Node[], otherSegments: DisplaySegment[]) => SkirtCandidate[];
export declare const buildChangedTerminalCandidates: (edge: Edge, edgeIndex: number, spine: DisplaySegment, nodes: Node[], otherSegments: DisplaySegment[], role: DisplayTerminalRole) => SkirtCandidate[];
/**
 * Keeps the opposite endpoint trunk byte-for-byte while moving one free
 * terminal onto a graph-exterior ring. This closes the case where a local
 * lane shift merely transfers a crossing from one side of a connected wall
 * to the other. Explicitly declared terminal sides remain immutable through
 * displayTerminalSideCanSwitch.
 */
export declare const buildSingleTerminalOuterRingCandidates: (edge: Edge, edgeIndex: number, nodes: Node[], otherSegments: DisplaySegment[], role: DisplayTerminalRole) => SkirtCandidate[];
export declare const buildDualTerminalOuterLaneCandidates: (edge: Edge, edgeIndex: number, spine: DisplaySegment, nodes: Node[], otherSegments: DisplaySegment[]) => SkirtCandidate[];
