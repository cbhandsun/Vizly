import type { BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
export declare const isDisplayWorkerBoundedCandidateReport: (value: unknown) => value is BaseDisplayBoundedCandidateReport;
