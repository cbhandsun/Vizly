import type { Edge } from '@xyflow/react';
export declare const BASE_REACT_FLOW_EDGE_STROKE = "#64748B";
export declare const BASE_REACT_FLOW_MARKER_SIZE = 20;
export type BaseReactFlowEdgeSemanticRole = 'main' | 'data' | 'dependency' | 'support' | 'status';
export declare const readBaseReactFlowEdgeSemanticRole: (value: unknown) => BaseReactFlowEdgeSemanticRole | undefined;
export declare const appendBaseReactFlowEdgeSemanticClassName: (className: unknown, roleValue: unknown) => string | undefined;
/**
 * Completes the visual contract that React Flow cannot infer from an edge style.
 * In particular, its default marker otherwise keeps the library gray instead of
 * following the semantic stroke. Authored marker URLs, explicit marker removal,
 * safe colors, and bounded custom sizes remain untouched.
 */
export declare const applyBaseReactFlowEdgePresentation: (edges: readonly Edge[], sourceEdges?: readonly Edge[]) => Edge[];
