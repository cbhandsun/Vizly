import type { Edge } from '@xyflow/react';
export declare const MIN_RENDER_SAFE_ENDPOINT_STUB = 56;
export declare const countRenderUnsafeEndpointStubs: (edges: Edge[]) => number;
