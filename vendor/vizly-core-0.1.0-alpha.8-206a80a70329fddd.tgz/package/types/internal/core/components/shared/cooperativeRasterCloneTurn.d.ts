/** A macrotask boundary lets input/abort events run between complete DOM nodes. */
export declare const cooperativeRasterCloneTurn: (options: unknown) => Promise<void>;
