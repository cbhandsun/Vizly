import type { Edge, Node } from '@xyflow/react';
import { type BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
import { type DisplayTerminalValidationSnapshot } from './baseReactFlowTerminalAxisRepair.js';
export declare const evaluateDisplayTerminalHardGates: (edges: Edge[], nodes: Node[], snapshot?: DisplayTerminalValidationSnapshot) => {
    terminalsAttached: boolean;
    terminalsAnchored: boolean;
};
export declare const getDisplayHardQualityGateReport: (edges: Edge[], nodes: Node[], candidate: BaseDisplayBoundedCandidateReport['candidate'], terminalSnapshot?: DisplayTerminalValidationSnapshot) => BaseDisplayBoundedCandidateReport;
export declare const getDisplayHardQualityGateReportWithMetrics: (edges: Edge[], nodes: Node[], candidate: BaseDisplayBoundedCandidateReport['candidate'], terminalSnapshot?: DisplayTerminalValidationSnapshot) => Readonly<{
    report: BaseDisplayBoundedCandidateReport;
    scanMetrics: import("./baseReactFlowDisplayHardGateMetrics.js").DisplayHardGateScanMetrics;
}>;
export declare const displayHardQualityGatesAreClean: (edges: Edge[], nodes: Node[]) => boolean;
/** Exact hard contract for geometry after renderer handles have been materialized. */
export declare const displayRenderedHardQualityGatesAreClean: (edges: Edge[], nodes: Node[]) => boolean;
export declare const baseReactFlowDisplayHardQualityIsClean: (edges: Edge[], nodes: Node[]) => boolean;
export declare const computeBaseReactFlowDisplayEdgeEpoch: ({ nodes, edges, }: {
    nodes: Node[];
    edges: Edge[];
}) => number;
