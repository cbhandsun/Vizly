import type { Edge, Node } from '@xyflow/react';
export declare const fastDisplayHardSafetyIsClean: (edges: Edge[], nodes: Node[]) => boolean;
export declare const repairFastDisplayHardSafety: (edges: Edge[], nodes: Node[]) => Edge[];
