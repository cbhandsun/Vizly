import type { Edge, Node } from '@xyflow/react';
export { repairTerminalHandleHemisphereHairpins } from './baseReactFlowDisplayHemisphereHairpinRepair.js';
export { buildCrossingCompanionOuterPortVariants, buildOppositeRoleSharedNodeCandidates, buildStrictCrossingCompanionShiftVariants, displayTerminalRoleNeedsDeclaredAxisRepair, displayTerminalSideCanSwitch, withDisplayPortBridge, } from './baseReactFlowDisplayTerminalPortCandidates.js';
export declare const repairDetachedTerminalsWithBoundedPortRoles: <T extends Edge[]>(edges: T, nodes: Node[], maxQualityEvaluations?: number) => T;
export declare const repairAxisMismatchedTerminalsWithBoundedPortRoles: <T extends Edge[]>(edges: T, nodes: Node[], maxQualityEvaluations?: number) => T;
