import type { Edge, Node } from '@xyflow/react';
import { type BaseReactFlowFinalEndpointOrderOptions } from './baseReactFlowDisplayFinalEndpointGate.js';
export declare const traceSkippedFinalCommercialDetours: (candidateCount: number, onPhaseTrace: BaseReactFlowFinalEndpointOrderOptions['onPhaseTrace']) => void;
export declare const repairBaseReactFlowFinalCommercialDetours: <T extends Edge[]>(edges: T, nodes: Node[], options?: BaseReactFlowFinalEndpointOrderOptions & Readonly<{
    skipLoopShortcut?: boolean;
    onFinalEvaluation?: (evaluation: Readonly<{
        edges: readonly Edge[];
        closureReady: boolean;
    }>) => void;
}>) => T;
