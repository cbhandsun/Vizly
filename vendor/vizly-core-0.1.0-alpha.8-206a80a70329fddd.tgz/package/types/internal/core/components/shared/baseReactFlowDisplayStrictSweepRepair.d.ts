import type { Edge, Node } from '@xyflow/react';
import { type StrictCrossingRepairDiagnostics } from './baseReactFlowDisplayStrictDiagnostics.js';
export declare const chooseDirectionalOuterLaneCandidate: <T extends Edge[]>(nodes: Node[], baseline: T, candidate: T, diagnostics?: StrictCrossingRepairDiagnostics) => T;
export declare const repairTerminalStrictCrossingsWithEndpointLanes: <T extends Edge[]>(edges: T, nodes: Node[], diagnostics?: StrictCrossingRepairDiagnostics) => T;
export declare const finalStrictDisplaySweep: <T extends Edge[]>(edges: T, nodes: Node[], diagnostics?: StrictCrossingRepairDiagnostics) => T;
export declare const repairStrictCrossingsWithDirectionalOuterLanes: <T extends Edge[]>(edges: T, nodes: Node[], diagnostics?: StrictCrossingRepairDiagnostics) => T;
