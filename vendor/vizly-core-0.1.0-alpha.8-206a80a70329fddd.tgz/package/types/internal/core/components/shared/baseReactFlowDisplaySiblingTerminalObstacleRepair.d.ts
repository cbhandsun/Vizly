import type { Edge, Node } from '@xyflow/react';
/**
 * Generates atomic O2M/M2O branch skirts without shortening either terminal
 * trunk. A sibling endpoint node remains an absolute obstacle after trunk
 * synthesis; extending the adjacent trunk is safer than cutting that trunk.
 */
export declare const buildSiblingTerminalObstacleSkirtCandidates: <T extends Edge[]>(edges: T, nodes: Node[], maxCandidates?: number) => T[];
