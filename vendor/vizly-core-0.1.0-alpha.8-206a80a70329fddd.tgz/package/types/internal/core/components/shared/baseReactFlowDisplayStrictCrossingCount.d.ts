import type { Edge } from '@xyflow/react';
export declare const countDisplayStrictCrossings: (edges: Edge[]) => number;
/**
 * Reuses the exact strict-crossing count already produced by a quality evaluation.
 * The display-specific fallback remains necessary when a computed path is
 * incomplete or render compaction changes its segment topology.
 */
export declare const countDisplayStrictCrossingsFromKnownQuality: (edges: Edge[], quality: {
    strictCrossings: number;
}, metrics?: {
    knownQualityStrictReuseCount: number;
}) => number;
export declare const displayStrictCrossingsFromKnownQuality: typeof countDisplayStrictCrossingsFromKnownQuality;
export declare const createDisplayStrictCrossingCounter: (metrics?: {
    knownQualityStrictReuseCount: number;
}) => (edges: Edge[], quality: {
    strictCrossings: number;
}) => number;
