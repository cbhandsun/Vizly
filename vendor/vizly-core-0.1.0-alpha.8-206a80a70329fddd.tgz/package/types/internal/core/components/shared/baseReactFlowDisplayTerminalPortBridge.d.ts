import type { Edge } from '@xyflow/react';
import { type DisplayPoint } from './baseReactFlowDisplayGeometry.js';
export declare const withDisplayPortBridge: (edge: Edge, path: DisplayPoint[], sourceHandle: 'top' | 'bottom' | 'left' | 'right', targetHandle: 'top' | 'bottom' | 'left' | 'right') => Edge;
