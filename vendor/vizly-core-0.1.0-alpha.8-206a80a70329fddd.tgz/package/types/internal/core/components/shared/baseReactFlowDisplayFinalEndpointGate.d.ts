import type { Edge } from '@xyflow/react';
import type { BaseReactFlowChangedHardReportEvidence } from './baseReactFlowDisplayChangedHardReport.js';
import type { SameSideEndpointTrunkIdentity } from '../../strategies/shared/edgeFinalSameSideEndpointOrderRepair.js';
import type { BaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
import type { DisplayRoutingPhaseName, DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
export type BaseReactFlowFinalEndpointOrderOptions = Readonly<{
    /** Restricts incremental transactions to their declared mutable closure. */
    eligibleEdgeIds?: ReadonlySet<string>;
    /** Source graph before automatic terminal-side routing; used as a soft preference only. */
    preferredEdges?: readonly Edge[];
    /** Aggregate-only stage diagnostics; never includes graph identifiers or geometry. */
    onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void;
    /** Explicit owner when endpoint repair runs inside another measured transaction. */
    traceParentPhase?: Extract<DisplayRoutingPhaseName, 'finalizer' | 'final-safety-repair-order'>;
    /** Request-local exact evidence shared by consecutive final routing stages. */
    evaluation?: BaseReactFlowFinalEndpointEvaluation;
}>;
export declare const isExactSingleImmutableEdgeReplacement: (baselineEdges: readonly Edge[], candidateEdges: readonly Edge[], changedEdgeIndexes: readonly number[]) => boolean;
export declare const passesBaseReactFlowFinalDisplayGate: (baselineEdges: readonly Edge[], candidateEdges: readonly Edge[], changedEdgeIndexes: readonly number[], options: BaseReactFlowFinalEndpointOrderOptions, evaluation: BaseReactFlowFinalEndpointEvaluation, allowBoundedClearanceStemReduction?: boolean, restoredPreferredSourceTrunk?: SameSideEndpointTrunkIdentity, knownEvidence?: BaseReactFlowChangedHardReportEvidence) => boolean;
/**
 * Commercial shortening may reclaim an arbitrarily overextended shared stem,
 * provided every original trunk membership remains represented by a legal
 * business-clearance stem. All non-trunk hard-quality gates remain identical.
 */
export declare const passesBaseReactFlowCommercialFinalDisplayGate: (baselineEdges: readonly Edge[], candidateEdges: readonly Edge[], changedEdgeIndexes: readonly number[], options: BaseReactFlowFinalEndpointOrderOptions, evaluation: BaseReactFlowFinalEndpointEvaluation) => boolean;
