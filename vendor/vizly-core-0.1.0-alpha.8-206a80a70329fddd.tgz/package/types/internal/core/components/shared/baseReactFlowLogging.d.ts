export declare const logBaseReactFlowFitWidthTopFailure: (error: unknown) => void;
export declare const logBaseReactFlowConfigReadFailure: (key: string, error: unknown) => void;
export declare const logBaseReactFlowEventBindingFailure: (action: string, error: unknown) => void;
export declare const logBaseReactFlowQualityFallback: (reason: string) => void;
export declare const logBaseReactFlowOverlayFlagReadFailure: (key: string, error: unknown) => void;
