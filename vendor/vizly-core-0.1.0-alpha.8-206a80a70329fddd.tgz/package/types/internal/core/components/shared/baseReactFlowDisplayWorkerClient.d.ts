import type { Edge, Node } from '@xyflow/react';
import type { MutableRefObject } from 'react';
import type { RoutingPatch } from '../../routing/routingPatch.js';
import { type DisplayEdgesWorkerResponse, type DisplayEdgesWorkerRequest, type DisplayEdgesWorkerCandidateSource, type DisplayEdgesWorkerRouteResolution, type DisplayRoutingFallbackLevel, type DisplayQualityMode } from './baseReactFlowDisplayWorkerProtocol.js';
import type { DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
import { type RoutingIdentity, type RoutingWorkerSessionRef } from './baseReactFlowDisplayRoutingSession.js';
import { type BaseReactFlowLayoutRepairWorkerOptions } from './baseReactFlowDisplayWorkerLayoutClient.js';
export { doesBaseReactFlowDisplayWorkerResolutionMatchOperation } from './baseReactFlowDisplayWorkerLayoutClient.js';
export type { DisplayQualityMode } from './baseReactFlowDisplayWorkerProtocol.js';
export { projectBaseReactFlowDisplayWorkerInput } from './baseReactFlowDisplayWorkerProjection.js';
export { resolveBaseReactFlowDisplayWorkerTimeoutMs } from './baseReactFlowDisplayWorkerTimeout.js';
export { createBaseReactFlowDisplayEdgePatches, doBaseReactFlowDisplayRoutesMatchExactly, mergeBaseReactFlowDisplayEdgePatches, mergeBaseReactFlowDisplayRoutingTransactions, mergeTrustedBaseReactFlowDisplayCacheEntry, resolveBaseReactFlowDisplayCacheReplaySignature, sanitizeBaseReactFlowTrustedDisplayPatches, } from './baseReactFlowDisplayRoutingTransaction.js';
export type DeferredDisplayEdges = {
    signature: string;
    geometryDigest: string;
    displayPatches: RoutingPatch[];
    hardClean: boolean;
};
export type BaseReactFlowDisplayWorkerResult = {
    edges: Edge[];
    /** Sanitized routing-only transaction produced at the Worker trust boundary. */
    routingPatches: RoutingPatch[];
    hardClean: boolean;
    hardReport?: DisplayEdgesWorkerResponse['hardReport'];
    routeResolution: DisplayEdgesWorkerRouteResolution;
    /** Exact DTO edge baseline that produced the worker response. */
    projectedEdges: Edge[];
    phaseTrace: DisplayRoutingPhaseTrace[];
    affectedEdgeCount?: number;
    fallbackLevel?: DisplayRoutingFallbackLevel;
    nextIdentity?: RoutingIdentity;
    outputRouteSignature?: string;
    sessionRef?: RoutingWorkerSessionRef;
    commitReceipt?: DisplayEdgesWorkerResponse['commitReceipt'];
    /** Aggregate timestamp after protocol validation and routing-only sanitization. */
    workerResponseParsedAt?: number;
};
export type BaseReactFlowDisplayWorkerResponseResult = Omit<BaseReactFlowDisplayWorkerResult, 'projectedEdges'>;
export type DisplayRoutingInput = {
    cacheSignature: string;
    inputGeometryDigest: string;
    edges: Edge[];
    nodes: Node[];
    enableSmartEdges: boolean;
    smartEdgePadding: number;
    isLargeGraph: boolean;
    displayEdgeEpoch: number;
};
export type DisplayQualityPolicy = {
    mode: DisplayQualityMode | 'skip';
    timeoutMs: number;
};
export declare const resolveBaseReactFlowDisplayWorkerFailureStage: (error: unknown) => 'worker-timeout' | 'worker-rejected';
type DisplayQualityCancel = () => void;
export declare const resolveBaseReactFlowDisplayQualityPolicy: ({ nodeCount, edgeCount, isLargeGraph, forceFullQuality, }: {
    nodeCount: number;
    edgeCount: number;
    isLargeGraph: boolean;
    forceFullQuality?: boolean;
}) => DisplayQualityPolicy;
export declare const scheduleBaseReactFlowDisplayQuality: (run: () => void, delayMs?: number) => DisplayQualityCancel;
export declare const scheduleBaseReactFlowDisplayCacheWrite: (run: () => void, timeoutMs?: number) => DisplayQualityCancel;
export declare const resolveBaseReactFlowDisplayedEdges: ({ signature, geometryDigest, policyMode, deferred, cached, immediate, source, }: {
    signature: string;
    geometryDigest: string;
    policyMode: DisplayQualityPolicy['mode'];
    deferred: DeferredDisplayEdges | null;
    cached: Edge[] | null;
    source?: Edge[];
    immediate: Edge[];
}) => Edge[];
/**
 * Lets explicit warm-up callers fetch and compile the display worker before a
 * request. The production canvas creates it on demand after geometry settles so
 * the 1 MB worker asset does not contend with the first visible render.
 */
export declare const prewarmBaseReactFlowDisplayWorker: (workerRef: MutableRefObject<Worker | null>) => boolean;
/** Releases both request-idle guards and the worker owned by a canvas hook. */
export declare const disposeBaseReactFlowDisplayWorker: (workerRef: MutableRefObject<Worker | null>) => void;
export declare const requestBaseReactFlowDisplayEdgesWorker: ({ workerRef, request, qualityMode, timeoutMs, signal, }: {
    workerRef: MutableRefObject<Worker | null>;
    request: DisplayEdgesWorkerRequest;
    qualityMode?: DisplayQualityMode;
    timeoutMs?: number;
    signal?: AbortSignal;
}) => Promise<BaseReactFlowDisplayWorkerResponseResult>;
export declare const computeBaseReactFlowDisplayEdgesInWorker: ({ workerRef, requestId, edges, nodes, enableSmartEdges, smartEdgePadding, isLargeGraph, displayEdgeEpoch, inputSignature, inputGeometryDigest, cachedCandidateEdges, candidateSource, qualityMode, timeoutMs, signal, }: {
    workerRef: MutableRefObject<Worker | null>;
    requestId: string;
    edges: Edge[];
    nodes: Node[];
    enableSmartEdges: boolean;
    smartEdgePadding: number;
    isLargeGraph: boolean;
    displayEdgeEpoch: number;
    inputSignature?: string;
    inputGeometryDigest?: string;
    cachedCandidateEdges?: Edge[] | null;
    candidateSource?: DisplayEdgesWorkerCandidateSource;
    qualityMode?: DisplayQualityMode;
    timeoutMs?: number;
    signal?: AbortSignal;
}) => Promise<BaseReactFlowDisplayWorkerResult>;
export declare const computeBaseReactFlowLayoutRepairAndRouteInWorker: (options: BaseReactFlowLayoutRepairWorkerOptions) => Promise<BaseReactFlowDisplayWorkerResult>;
export declare const repairBaseReactFlowDisplayEdgesInWorker: ({ workerRef, requestId, edges, nodes, timeoutMs, signal, requireHardClean, repairMode, stopAfterObstacleFailure, inputSignature, inputGeometryDigest, }: {
    workerRef: MutableRefObject<Worker | null>;
    requestId: string;
    edges: Edge[];
    nodes: Node[];
    timeoutMs?: number;
    signal?: AbortSignal;
    requireHardClean?: boolean;
    repairMode?: 'bounded' | 'finalized';
    stopAfterObstacleFailure?: boolean;
    inputSignature: string;
    inputGeometryDigest: string;
}) => Promise<BaseReactFlowDisplayWorkerResult>;
export declare const doDisplayEdgesMatchSourceGraph: (sourceEdges: Edge[], displayEdges: Edge[]) => boolean;
