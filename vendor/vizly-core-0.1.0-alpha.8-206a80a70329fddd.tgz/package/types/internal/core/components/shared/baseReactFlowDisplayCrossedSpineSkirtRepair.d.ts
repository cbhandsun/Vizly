import type { Edge, Node } from '@xyflow/react';
type CrossedSpineHardMetrics = Readonly<{
    nonOrthogonalSegments: number;
    reverseOverlap: number;
    unrelatedOverlap: number;
    unexplainedRelatedOverlap: number;
    shortEndpointStubs: number;
    tinyInteriorDoglegs: number;
    hairpins: number;
}>;
export type CrossedSpineSkirtRepairReport = Readonly<{
    crossedSpines: number;
    evaluatedCandidates: number;
    rejectedDetached: number;
    rejectedStrict: number;
    rejectedHardQuality: number;
    rejectedObstacles: number;
    rejectedTrunks: number;
    acceptedStrictCrossings: number;
    pairedGenerated: number;
    pairedStrictReduced: number;
    pairedEligible: number;
    pairedRejectedHardQuality: number;
    pairedRejectedObstacles: number;
    pairedRejectedTrunks: number;
    tripleGenerated: number;
    tripleEligible: number;
    tripleAccepted: number;
    closestRejectedHardQuality: CrossedSpineHardMetrics | null;
}>;
/**
 * Escapes a spine crossed by multiple opposite-flow terminal approaches.
 * The transaction may switch one unconstrained terminal to an outer side, but
 * commits only when the full graph stays anchored, obstacle-safe, and retains
 * every pre-existing legal source/target trunk.
 */
export declare const repairCrossedSpineWithOuterSkirt: <T extends Edge[]>(edges: T, nodes: Node[], options?: Readonly<{
    onReport?: (report: CrossedSpineSkirtRepairReport) => void;
}>) => T;
export {};
