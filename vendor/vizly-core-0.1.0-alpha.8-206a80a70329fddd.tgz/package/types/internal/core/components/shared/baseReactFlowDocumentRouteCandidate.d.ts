import type { Edge } from '@xyflow/react';
export declare const loadBaseReactFlowDocumentRouteCandidate: ({ inputSignature, inputGeometryDigest, sourceEdges, }: {
    inputSignature: string;
    inputGeometryDigest: string;
    sourceEdges: Edge[];
}) => Edge[] | null;
