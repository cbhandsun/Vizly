import type { Edge, Node } from '@xyflow/react';
/**
 * Builds a bounded last-resort outer-lane candidate for a rendered route that
 * still intersects a business node. The caller must pass the result through
 * the final hard closure and must never commit this intermediate candidate.
 */
export declare const buildBaseReactFlowEmergencyObstacleCandidate: <T extends Edge[]>(edges: T, nodes: Node[]) => T;
