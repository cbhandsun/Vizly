import type { Edge } from '@xyflow/react';
export declare const resolveBaseReactFlowNodeDragFallbackIds: (primaryNodeId: string, draggedNodes: readonly {
    id: string;
    selected?: boolean;
}[] | undefined) => string[];
/**
 * Keeps every diagram visible and responsive while the worker searches for a
 * final route. Built-in smooth-step edges avoid running obstacle routing
 * synchronously in every custom edge component during the pending window.
 */
export declare const createBaseReactFlowInteractiveFallbackEdges: (edges: Edge[]) => Edge[];
/**
 * Uses endpoint-driven built-in paths while a node is moving or its final
 * canvas route is being recomputed. Stable paths contain absolute points from
 * the previous geometry and would otherwise appear detached from the node.
 */
export declare const createBaseReactFlowNodeDragFallbackEdges: (edges: Edge[], draggingNodeIds?: readonly string[]) => Edge[];
/**
 * Reuses the last accepted render geometry only while it still describes the
 * same edge topology. This keeps unrelated paths and labels stable during a
 * node drag without carrying removed or rewired edges into the fallback view.
 */
export declare const resolveBaseReactFlowNodeDragFallbackBase: (sourceEdges: readonly Edge[], resolvedEdges: readonly Edge[]) => readonly Edge[];
export declare const shouldUseBaseReactFlowNodeDragFallback: ({ isNodeDragging, dragFallbackPending, hasResolvedEdges: _hasResolvedEdges, sourceEdgeCount, }: {
    isNodeDragging: boolean;
    dragFallbackPending: boolean;
    hasResolvedEdges: boolean;
    sourceEdgeCount: number;
}) => boolean;
