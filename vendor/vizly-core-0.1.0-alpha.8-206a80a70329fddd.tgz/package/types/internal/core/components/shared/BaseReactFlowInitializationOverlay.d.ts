import React from 'react';
export declare const BaseReactFlowInitializationOverlay: React.MemoExoticComponent<() => React.JSX.Element>;
