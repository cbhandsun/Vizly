import type { Edge } from '@xyflow/react';
/**
 * Widens a tiny branch elbow by moving the complete shared target trunk as a
 * transaction. Every member that owns the same suffix is changed together,
 * so a real target trunk cannot be split by per-edge micro cleanup.
 */
export declare const buildSharedTargetTrunkNormalizationCandidates: <T extends Edge[]>(edges: T) => T[];
