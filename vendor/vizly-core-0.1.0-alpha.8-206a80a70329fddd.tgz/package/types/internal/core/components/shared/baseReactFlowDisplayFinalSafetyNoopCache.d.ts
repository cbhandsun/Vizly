import type { Edge, Node } from '@xyflow/react';
export declare const createBaseReactFlowFinalSafetyNoopCacheKey: (edges: Edge[], nodes: Node[], eligibleEdgeIds?: ReadonlySet<string>) => string | null;
export declare const createBaseReactFlowFinalSafetyNoopCache: () => {
    has(edges: Edge[], nodes: Node[], eligibleEdgeIds?: ReadonlySet<string>): boolean;
    remember(edges: Edge[], nodes: Node[], eligibleEdgeIds?: ReadonlySet<string>): boolean;
};
