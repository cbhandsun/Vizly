import type { Edge } from '@xyflow/react';
export type RankedDisplayTerminalPortCandidate = Readonly<{
    candidateEdge: Edge;
    declaredAxisMismatches: number;
    obstacleHits: number;
    order: number;
}>;
export declare const createDisplayTerminalPortCandidateBuckets: (isValid: (edge: Edge) => boolean) => {
    candidateEdges: Edge[];
    handleOnlyCandidateEdges: Edge[];
    insetNudgeCandidateEdges: Edge[];
    appendCandidate: (edge: Edge) => void;
    appendPriorityCandidate: (edge: Edge) => void;
    appendInsetNudgeCandidate: (edge: Edge) => void;
};
export declare const rankDisplayTerminalPortCandidates: (candidateEdges: Edge[], countDeclaredAxisMismatches: (edge: Edge) => number, countObstacleHits: (edge: Edge) => number, prioritizeDeclaredAxisCompletion: boolean) => RankedDisplayTerminalPortCandidate[];
export declare const displayTerminalPortCandidateIsBetter: (candidate: Pick<RankedDisplayTerminalPortCandidate, 'declaredAxisMismatches' | 'obstacleHits'>, acceptedDeclaredAxisMismatches: number, acceptedObstacleHits: number, prioritizeDeclaredAxisCompletion: boolean) => boolean;
export declare const displayTerminalPortCandidateIsComplete: (candidate: Pick<RankedDisplayTerminalPortCandidate, 'declaredAxisMismatches' | 'obstacleHits'>, _prioritizeDeclaredAxisCompletion: boolean) => boolean;
