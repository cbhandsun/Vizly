import type { Edge, Node } from '@xyflow/react';
/** Restore a moved endpoint's committed trunk as one transaction after the
 * individual reconnect search. Never infer membership from business IDs or
 * newly adjacent paths. The unchanged corridors and exact final gates decide
 * whether the original bundle can still be represented at the new position.
 */
export declare const restoreBaseReactFlowReconnectTrunks: ({ baselineEdges, baselineNodes, edges, nodes, changedNodeIds, mutableEdgeIds, }: {
    baselineEdges: Edge[];
    baselineNodes: Node[];
    edges: Edge[];
    nodes: Node[];
    changedNodeIds: readonly string[];
    mutableEdgeIds: readonly string[];
}) => Edge[];
