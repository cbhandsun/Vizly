import type { Edge, Node } from '@xyflow/react';
import type { BaseReactFlowDisplayEdgesArgs } from './baseReactFlowDisplayFullRoutePipeline.js';
import type { BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
import { type BaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
export declare const displayAlternateHardClosureCandidateIsReady: (edges: Edge[], nodes: Node[], evidence?: Readonly<{
    evaluation?: BaseReactFlowFinalEndpointEvaluation | undefined;
    hardReport?: Readonly<{
        edges: readonly Edge[];
        report: BaseDisplayBoundedCandidateReport;
    }> | undefined;
}>) => boolean;
/**
 * Re-seeds only a bounded failed transaction, then closes every hard and
 * commercial gate before the alternate geometry can be committed.
 */
export declare const buildBaseReactFlowAlternateHardClosureCandidate: ({ args, repairNodes, primaryCandidate, evaluationSession, }: {
    args: BaseReactFlowDisplayEdgesArgs;
    repairNodes: Node[];
    primaryCandidate: Edge[];
    evaluationSession?: BaseReactFlowFinalEndpointEvaluation;
}) => Edge[] | null;
