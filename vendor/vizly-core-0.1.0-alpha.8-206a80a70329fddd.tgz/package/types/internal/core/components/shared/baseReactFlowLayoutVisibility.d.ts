import type { Node } from '@xyflow/react';
/** The same authored and semantic hierarchy used by container collapse. */
export declare const buildChildrenMap: (nodes: Node[]) => Map<string, string[]>;
export declare const getDescendantIds: (nodes: Node[], parentId: string, prebuiltMap?: Map<string, string[]>) => string[];
/** Normalize the actual candidate before both geometry validation and state
 * publication. Hidden structural parents do not imply hidden children; only
 * explicit collapse propagates. The validator itself never invents visibility. */
export declare const normalizeBaseReactFlowLayoutVisibility: (nodes: Node[]) => Node[];
