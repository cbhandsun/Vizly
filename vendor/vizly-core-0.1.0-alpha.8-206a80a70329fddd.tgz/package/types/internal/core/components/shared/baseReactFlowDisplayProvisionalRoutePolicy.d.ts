import type { Edge, Node } from '@xyflow/react';
/** Counts affected routes, including pair defects, against the existing repair allowance. */
export declare const provisionalDisplayRouteDefectsExceedCapacity: (edges: Edge[], nodes: Node[], capacity: number) => boolean;
