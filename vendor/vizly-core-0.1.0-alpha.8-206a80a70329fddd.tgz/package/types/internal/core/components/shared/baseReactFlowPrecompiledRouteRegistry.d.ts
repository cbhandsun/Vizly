import type { Edge } from '@xyflow/react';
import { type RoutingPatch } from '../../routing/routingPatch.js';
import { type BaseReactFlowDisplayEdgesCacheEntry } from './baseReactFlowDisplayCache.js';
import { type BaseReactFlowDisplayInputIdentity } from './baseReactFlowDisplayInputIdentity.js';
import { type GeneratedBaseReactFlowPrecompiledRouteDescriptor } from './generated/baseReactFlowPrecompiledRouteLoaders.js';
export type BaseReactFlowPrecompiledRouteLookupInput = BaseReactFlowDisplayInputIdentity & {
    inputSignature: string;
    /** Trusted runtime memo; callers outside the routing hook should omit it. */
    inputGeometryDigest?: string;
    /** Debug-only aggregate status; never include graph content or artifact payloads. */
    onDiagnostic?: (diagnostic: BaseReactFlowPrecompiledRouteDiagnostic) => void;
};
export type BaseReactFlowPrecompiledRouteDiagnosticReason = 'hit' | 'miss:invalid-geometry-digest' | 'miss:no-descriptor' | 'miss:geometry-digest' | 'reject:load-error' | 'reject:artifact-schema' | 'reject:routing-version' | 'reject:routing-source-hash' | 'reject:source-hash' | 'reject:input-identity' | 'reject:contract-dirty' | 'reject:commercial-quality' | 'reject:patch-merge';
export type BaseReactFlowPrecompiledRouteDiagnostic = Readonly<{
    reason: BaseReactFlowPrecompiledRouteDiagnosticReason;
    inputSignature: string;
    inputGeometryDigest?: string;
    presetId?: string;
    variantId?: string;
}>;
type BaseReactFlowPrecompiledRouteLoaderBucket = GeneratedBaseReactFlowPrecompiledRouteDescriptor | readonly GeneratedBaseReactFlowPrecompiledRouteDescriptor[];
export type BaseReactFlowPrecompiledRouteLoaderRegistry = Record<string, BaseReactFlowPrecompiledRouteLoaderBucket>;
export declare const hasBaseReactFlowPrecompiledRouteCandidateInRegistry: (inputSignature: string, inputGeometryDigest: string, registry: BaseReactFlowPrecompiledRouteLoaderRegistry) => boolean;
export declare const hasBaseReactFlowPrecompiledRouteCandidate: (inputSignature: string, inputGeometryDigest: string) => boolean;
/**
 * Precompiled artifacts have a stricter build-time schema than mutable browser
 * storage and may carry the three router-owned trunk booleans. They therefore
 * use a dedicated merge path; persistent-cache sanitization remains unchanged.
 */
export declare const mergeTrustedBaseReactFlowPrecompiledRouteArtifact: (sourceEdges: Edge[], entry: BaseReactFlowDisplayEdgesCacheEntry) => Edge[] | null;
/**
 * Generated route artifacts carry a complete routing-data contract. The
 * ordinary Worker/cache patch merger is intentionally recursive because those
 * patches are incremental. Reusing it without this replacement step can retain
 * stale source paths, jump hints or trunk flags absent from the generated
 * route and invalidate the artifact's output signature.
 */
export declare const mergeBaseReactFlowPrecompiledRoutePatches: (sourceEdges: Edge[], patches: RoutingPatch[]) => Edge[] | null;
export declare const loadBaseReactFlowPrecompiledRouteCandidateFromRegistry: (input: BaseReactFlowPrecompiledRouteLookupInput, registry: BaseReactFlowPrecompiledRouteLoaderRegistry) => Promise<Edge[] | null>;
export declare const loadBaseReactFlowPrecompiledRouteCandidate: (input: BaseReactFlowPrecompiledRouteLookupInput) => Promise<Edge[] | null>;
export {};
