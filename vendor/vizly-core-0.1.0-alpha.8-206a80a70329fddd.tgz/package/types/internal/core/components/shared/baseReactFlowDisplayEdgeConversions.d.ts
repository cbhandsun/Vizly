import type { Edge, Node } from '@xyflow/react';
/**
 * Commits worker-validated geometry to the renderer that consumes computedPath.
 * Callers must only pass an internally finalized transaction; arbitrary imported
 * paths intentionally remain subject to the normal trust checks above.
 */
export declare const lockFinalDisplayComputedPaths: <T extends Edge[]>(edges: T, nodes?: Node[], nodeById?: Map<string, Node>) => T;
export declare const toCanvasRefEdge: (edge: Edge) => Edge;
export declare const toSmartDisplayEdge: ({ edge, rawEdge, smartEdgePadding, }: {
    edge: Edge;
    rawEdge: Edge;
    smartEdgePadding: number;
}) => Edge;
export declare const toBasicDisplayEdge: ({ edge, rawEdge, }: {
    edge: Edge;
    rawEdge: Edge;
}) => Edge;
