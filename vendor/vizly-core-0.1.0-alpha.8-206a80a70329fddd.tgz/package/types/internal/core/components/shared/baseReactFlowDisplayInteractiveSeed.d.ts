import type { Edge, Node } from '@xyflow/react';
import type { BaseDisplayHardGateMemo } from './baseReactFlowDisplayHardGateMemo.js';
import type { BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
import type { BaseReactFlowPreDisplayFinalEdgesArgs } from './baseReactFlowDisplayFullRouteTypes.js';
export type BaseReactFlowInteractiveSeedResult = Readonly<{
    edges: Edge[];
    report: BaseDisplayBoundedCandidateReport;
}>;
export declare const createBaseReactFlowInteractiveSeedResult: ({ args, repairNodes, getRouteHardQualityGateReport, }: {
    args: BaseReactFlowPreDisplayFinalEdgesArgs;
    repairNodes: Node[];
    getRouteHardQualityGateReport: BaseDisplayHardGateMemo['getReport'];
}) => BaseReactFlowInteractiveSeedResult;
