export declare const DISPLAY_DETACHED_OVERLAP_REPAIR_OPTIONS: {
    maxIterations: number;
    maxHitBudget: number;
    maxQualityEvaluations: number;
    maxResidualPasses: number;
};
export declare const DISPLAY_BOUNDED_DETACHED_OVERLAP_REPAIR_OPTIONS: {
    maxIterations: number;
    maxHitBudget: number;
    maxQualityEvaluations: number;
    maxResidualPasses: number;
};
export declare const DISPLAY_EXTENDED_RESIDUAL_OVERLAP_REPAIR_OPTIONS: {
    maxIterations: number;
    maxHitBudget: number;
    maxQualityEvaluations: number;
    maxResidualPasses: number;
    qualityOnly: boolean;
};
export declare const DISPLAY_BOUNDED_RESIDUAL_OVERLAP_REPAIR_OPTIONS: {
    maxIterations: number;
    maxHitBudget: number;
    maxQualityEvaluations: number;
    maxResidualPasses: number;
    qualityOnly: boolean;
};
