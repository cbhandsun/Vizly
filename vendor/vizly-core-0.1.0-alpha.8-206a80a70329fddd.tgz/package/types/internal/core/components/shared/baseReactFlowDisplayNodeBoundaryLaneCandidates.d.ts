import type { Node } from '@xyflow/react';
import { type DisplayPoint } from './baseReactFlowDisplayGeometry.js';
type LaneAxis = 'h' | 'v';
export declare const buildNodeBoundaryAdjacentLaneCandidates: (path: readonly DisplayPoint[], crossingSegmentIndex: number, crossingAxis: LaneAxis, nodes: Node[], competingCoordinate: number, fallbackLaneValues: readonly number[], maxLanesPerAdjacentSegment?: number) => DisplayPoint[][];
export {};
