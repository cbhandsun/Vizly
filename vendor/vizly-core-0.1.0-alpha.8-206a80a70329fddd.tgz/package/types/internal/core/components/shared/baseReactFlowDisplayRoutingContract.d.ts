import type { Edge, Node } from '@xyflow/react';
import { auditFinalSameSideEndpointOrder } from '../../strategies/shared/edgeFinalSameSideEndpointOrderRepair.js';
import { auditFinalSameSidePassageOrder } from '../../strategies/shared/edgeFinalSameSidePassageOrderRepair.js';
import { type BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
export type DisplayRoutingContractViolationCode = 'terminal-detached' | 'terminal-unanchored' | 'non-orthogonal-segment' | 'obstacle-hit' | 'strict-crossing' | 'reverse-overlap' | 'unrelated-overlap' | 'unexplained-related-overlap' | 'short-endpoint-stub' | 'tiny-interior-dogleg' | 'hairpin' | 'minimum-clearance' | 'commercial-clearance' | 'container-boundary-skim' | 'render-unsafe-endpoint-stub' | 'endpoint-order' | 'passage-order';
export type DisplayRoutingContractViolation = Readonly<{
    code: DisplayRoutingContractViolationCode;
    phase: 'terminal' | 'geometry' | 'clearance' | 'endpoint-order' | 'passage-order' | 'presentation';
    severity: 'hard' | 'commercial' | 'presentation';
    count: number;
    edgeIds?: readonly string[];
    details?: Readonly<Record<string, number>>;
}>;
export type DisplayRoutingContractOptions = Readonly<{
    /**
     * Reuse a report that was already computed for the same immutable edge/node
     * snapshot. The verifier never trusts caller-provided clean status alone; it
     * still derives the public violation list from report fields.
     */
    hardReport?: BaseDisplayBoundedCandidateReport;
    /**
     * Commercial clearance is a final display contract, but some internal repair
     * stages intentionally validate only the 16px safety floor. Keep the switch
     * explicit so callers can separate internal candidate gates from final output.
     */
    requireCommercialClearance?: boolean;
}>;
export type DisplayRoutingContractReport = Readonly<{
    clean: boolean;
    hardClean: boolean;
    hardReport: BaseDisplayBoundedCandidateReport;
    commercialClearanceViolations: number;
    renderUnsafeEndpointStubs: number;
    endpointOrder: ReturnType<typeof auditFinalSameSideEndpointOrder>;
    passageOrder: ReturnType<typeof auditFinalSameSidePassageOrder>;
    violations: readonly DisplayRoutingContractViolation[];
}>;
export type DisplayRoutingContractSummaryViolation = Readonly<{
    code: DisplayRoutingContractViolationCode;
    phase: DisplayRoutingContractViolation['phase'];
    severity: DisplayRoutingContractViolation['severity'];
    count: number;
}>;
export type DisplayRoutingContractSummary = Readonly<{
    clean: boolean;
    hardClean: boolean;
    violationCount: number;
    violations: readonly DisplayRoutingContractSummaryViolation[];
}>;
export declare const DISPLAY_ROUTING_CONTRACT_VIOLATION_CODES: readonly DisplayRoutingContractViolationCode[];
export declare const createDisplayRoutingContractReport: (edges: Edge[], nodes: Node[], options?: DisplayRoutingContractOptions) => DisplayRoutingContractReport;
export declare const summarizeDisplayRoutingContractReport: (report: DisplayRoutingContractReport) => DisplayRoutingContractSummary;
export declare const isDisplayRoutingContractSummary: (value: unknown) => value is DisplayRoutingContractSummary;
