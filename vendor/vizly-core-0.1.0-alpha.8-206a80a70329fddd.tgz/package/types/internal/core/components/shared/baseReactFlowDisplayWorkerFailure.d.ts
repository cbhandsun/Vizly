import type { Edge, Node } from '@xyflow/react';
export declare const createDisplayWorkerFinalQualityError: (edges: Edge[], nodes: Node[]) => Error;
