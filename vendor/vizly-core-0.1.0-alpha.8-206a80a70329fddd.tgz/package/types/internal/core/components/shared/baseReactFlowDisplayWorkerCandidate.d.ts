import type { Edge } from '@xyflow/react';
import type { DisplayEdgesWorkerCandidateSource, DisplayEdgesWorkerRequest } from './baseReactFlowDisplayWorkerProtocol.js';
export type DisplayWorkerCandidate = Readonly<{
    edges: Edge[] | null;
    source: DisplayEdgesWorkerCandidateSource | null;
}>;
export declare const resolveDisplayWorkerCandidate: (request: DisplayEdgesWorkerRequest) => DisplayWorkerCandidate;
