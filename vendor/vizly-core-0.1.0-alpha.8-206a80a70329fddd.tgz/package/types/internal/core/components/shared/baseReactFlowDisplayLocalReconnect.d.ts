import type { Edge, Node } from '@xyflow/react';
import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
export declare const resolveReconnectCandidateBudgetPerEdge: (mutableEdgeCount: number) => number;
type ReconnectRank = Readonly<{
    score: number;
    hardDefects: number;
    clearanceRisk: number;
}>;
export declare const pushBoundedReconnectRankedCandidate: <T extends ReconnectRank>(ranked: T[], candidate: T, limit: number) => void;
export type BaseReactFlowReconnectDiagnostics = Readonly<{
    generatedPathCount: number;
    evaluatedPathCount: number;
}>;
/**
 * Reconnects only terminals attached to moved nodes. Every untouched edge
 * keeps its object reference and full path; mutable edges preserve their
 * existing corridor beyond the bounded terminal splice.
 */
export declare const createBaseReactFlowMovedNodeReconnectCandidates: ({ baselineEdges, baselineNodes, nodes, changedNodeIds, mutableEdgeIds, beamWidth, onDiagnostics, onPhaseTrace, }: {
    baselineEdges: Edge[];
    baselineNodes?: Node[];
    nodes: Node[];
    changedNodeIds: readonly string[];
    mutableEdgeIds: readonly string[];
    beamWidth?: number;
    onDiagnostics?: (diagnostics: BaseReactFlowReconnectDiagnostics) => void;
    onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void;
}) => Edge[][];
export {};
