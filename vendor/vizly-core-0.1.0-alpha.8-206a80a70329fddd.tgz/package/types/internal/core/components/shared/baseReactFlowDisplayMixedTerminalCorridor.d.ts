import type { Edge, Node } from '@xyflow/react';
/** Mixed-axis terminals need two corridor axes: a single exterior lane can
 * clear the middle obstacle yet graze a node near the target. Join the two
 * lanes at existing obstacle clearance boundaries, retaining both stubs.
 * The terminal-shortcut entry validates the path and supplies its search policy. */
export declare const buildMixedTerminalCorridorShortcutPaths: (path: Array<{
    x: number;
    y: number;
}>, nodes: Node[], edge: Edge, policy: {
    maxCandidates: number;
    containerNodeTypes: ReadonlySet<string>;
}) => Array<Array<{
    x: number;
    y: number;
}>>;
