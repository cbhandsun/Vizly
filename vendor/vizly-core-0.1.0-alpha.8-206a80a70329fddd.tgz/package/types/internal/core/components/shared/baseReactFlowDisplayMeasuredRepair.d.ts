import type { Edge, Node } from '@xyflow/react';
import { type BaseDisplayBoundedCandidateReport, type DisplaySoftQualityOptions } from './baseReactFlowDisplayEvaluation.js';
import type { BaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
export declare const resolveMeasuredObstacleRepairOptions: (stopAfterObstacleFailure: boolean, layoutDirection: string) => DisplaySoftQualityOptions;
export type BaseReactFlowMeasuredDisplayInitialEvaluation = Readonly<{
    edges: Edge[];
    inputNodes: Node[];
    repairNodes: Node[];
    report: BaseDisplayBoundedCandidateReport;
    evaluation?: BaseReactFlowFinalEndpointEvaluation;
}>;
export type BaseReactFlowMeasuredDisplayRepairOutcome = Readonly<{
    edges: Edge[];
    report: BaseDisplayBoundedCandidateReport;
}>;
export declare const repairBaseReactFlowMeasuredDisplayEdgesWithReport: (edges: Edge[], nodes: Node[], initialEvaluation?: BaseReactFlowMeasuredDisplayInitialEvaluation, deferStrictDominatedResult?: boolean, onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void, allowCompoundResidualClosure?: boolean, stopAfterObstacleFailure?: boolean) => BaseReactFlowMeasuredDisplayRepairOutcome;
export declare const repairBaseReactFlowMeasuredDisplayEdges: (edges: Edge[], nodes: Node[], initialEvaluation?: BaseReactFlowMeasuredDisplayInitialEvaluation) => Edge[];
