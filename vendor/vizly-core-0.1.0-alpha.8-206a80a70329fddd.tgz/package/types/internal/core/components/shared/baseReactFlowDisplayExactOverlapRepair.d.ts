import type { Edge, Node } from '@xyflow/react';
export declare const repairExactThresholdResidualOverlaps: <T extends Edge[]>(edges: T, nodes: Node[], maxQualityEvaluations?: number) => T;
