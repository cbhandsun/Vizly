import type { Edge } from '@xyflow/react';
import type { RoutingTopologyPlan } from './baseReactFlowDisplayRoutingTopologyPlan.js';
export type RoutingGroupLaneConstraint = Readonly<{
    groupIndex: number;
    edgeIndex: number;
    role: 'source' | 'target';
    handle: Edge['sourceHandle'];
    axis: 'horizontal' | 'vertical';
    coordinate: number;
}>;
export type RoutingGroupContract = Readonly<{
    memberIndexes: readonly number[];
    groupIndexes: readonly number[];
    lanes: readonly RoutingGroupLaneConstraint[];
}>;
/** Authored side, exact position and forbidden policies survive every group proposal. */
export declare const routingGroupPreservesAuthoredTerminals: (baseline: readonly Edge[], candidate: readonly Edge[]) => boolean;
/** Resolve the complete dual-role connected unit; never truncate its members. */
export declare const createRoutingGroupContract: (plan: RoutingTopologyPlan, edges: readonly Edge[], primaryIndexes: readonly number[]) => RoutingGroupContract | null;
/** Occupancy is a candidate invariant, not a preferred-axis score. */
export declare const routingGroupOccupiesReservedLanes: (contract: RoutingGroupContract, edges: readonly Edge[]) => boolean;
/** Reverse ownership within the same leased blocks as one complete proposal.
 * Edge-index order is not a geometric branch order; both orientations must be
 * judged together, without acquiring additional lanes or splitting dual roles. */
export declare const routingGroupContractVariants: (contract: RoutingGroupContract) => RoutingGroupContract[];
/** A bounded, simultaneous lane proposal for every member, including both roles. */
export declare const buildReservedRoutingGroupCandidates: <T extends Edge[]>(edges: T, contract: RoutingGroupContract) => T[];
