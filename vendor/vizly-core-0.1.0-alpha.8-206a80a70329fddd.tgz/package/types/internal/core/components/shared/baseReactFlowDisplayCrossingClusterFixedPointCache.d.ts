import type { Edge, Node } from '@xyflow/react';
export declare const DISPLAY_CROSSING_CLUSTER_FIXED_POINT_CAPACITY = 16;
/**
 * Builds the collision-independent identity used by the cross-reference negative cache.
 * Every component is length-framed; no hash is trusted for equality.
 */
export declare const createDisplayCrossingClusterFixedPointCanonicalKey: ({ edges, nodes, routingVersion, }: {
    edges: Edge[];
    nodes: Node[];
    routingVersion: string;
}) => string | null;
/** Returns true for an unchanged reference or an exactly identical canonical input. */
export declare const hasDisplayCrossingClusterFixedPoint: (edges: Edge[], nodes: Node[]) => boolean;
/** Remembers only that a complete bounded search returned this exact input unchanged. */
export declare const rememberDisplayCrossingClusterFixedPoint: (edges: Edge[], nodes: Node[]) => boolean;
/** Test isolation only; production routing never clears realm-local exact fixed points. */
export declare const clearDisplayCrossingClusterFixedPointsForTests: () => void;
