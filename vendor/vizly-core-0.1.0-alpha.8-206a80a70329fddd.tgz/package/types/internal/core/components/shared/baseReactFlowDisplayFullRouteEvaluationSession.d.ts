import type { Edge, Node } from '@xyflow/react';
import { createBaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
import { type BaseReactFlowDisplayExactReport } from './baseReactFlowDisplayFinalizer.js';
export type BaseReactFlowFullRouteEvaluationSession = Readonly<{
    evaluation: ReturnType<typeof createBaseReactFlowFinalEndpointEvaluation>;
    exactReport: (edges: Edge[]) => BaseReactFlowDisplayExactReport | undefined;
    repairNodes: Node[];
}>;
/**
 * Owns the request-local geometry projection and its exact hard-report proof.
 * The proof remains bound to both the original node array and output route
 * signature, so crossing a Worker pipeline module never grants extra trust.
 */
export declare const createBaseReactFlowFullRouteEvaluationSession: (nodes: Node[]) => BaseReactFlowFullRouteEvaluationSession;
