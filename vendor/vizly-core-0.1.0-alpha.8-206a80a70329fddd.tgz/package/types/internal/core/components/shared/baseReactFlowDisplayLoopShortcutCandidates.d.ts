import type { Edge, Node } from '@xyflow/react';
import { type DisplayPoint } from './baseReactFlowDisplayGeometry.js';
export declare const buildLoopLaneNudgeVariants: (path: DisplayPoint[], edgeIndex: number, edges: Edge[], maxCandidates?: number) => DisplayPoint[][];
type BlockingLaneVariant = Readonly<{
    edgeIndex: number;
    path: DisplayPoint[];
    sourceSide?: 'top' | 'right' | 'bottom' | 'left';
    targetSide?: 'top' | 'right' | 'bottom' | 'left';
}>;
export declare const buildBlockingEdgeLaneNudgeVariants: (path: DisplayPoint[], edgeIndex: number, edges: Edge[], nodes: Node[], maxCandidates?: number) => BlockingLaneVariant[];
export declare const buildStrictBlockingTerminalLaneShiftVariants: (mainPath: DisplayPoint[], mainEdgeIndex: number, edges: Edge[], nodes: Node[], maxCandidates?: number) => BlockingLaneVariant[];
export {};
