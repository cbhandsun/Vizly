import { EDGE_ROUTING_WORKER_PROTOCOL_VERSION } from '../../routing/routingVersion.js';
import { type RoutingIdentity, type RoutingWorkerSessionRef } from '../../routing/routingSessionIdentity.js';
import type { BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
import { type DisplayRoutingHardReportDigest, type RoutingHardReport } from './baseReactFlowDisplayHardReportDigest.js';
export type DisplayRoutingWorkerCommitReceipt = Readonly<{
    schema: 'vizly-routing-session-commit-v1';
    protocolVersion: typeof EDGE_ROUTING_WORKER_PROTOCOL_VERSION;
    identity: RoutingIdentity;
    outputRouteSignature: string;
    hardReport: RoutingHardReport;
    hardReportDigest: DisplayRoutingHardReportDigest;
    sessionRef: RoutingWorkerSessionRef;
}>;
export declare const createDisplayRoutingWorkerCommitReceipt: ({ identity, outputRouteSignature, hardReport, sessionRef, }: {
    identity: RoutingIdentity;
    outputRouteSignature: string;
    hardReport: BaseDisplayBoundedCandidateReport;
    sessionRef: RoutingWorkerSessionRef;
}) => DisplayRoutingWorkerCommitReceipt | null;
export declare const parseDisplayRoutingWorkerCommitReceipt: (value: unknown) => DisplayRoutingWorkerCommitReceipt | null;
