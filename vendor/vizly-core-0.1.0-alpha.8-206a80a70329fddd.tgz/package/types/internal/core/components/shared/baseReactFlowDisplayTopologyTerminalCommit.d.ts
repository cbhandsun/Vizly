import type { Edge, Node } from '@xyflow/react';
export declare const recommitBaseReactFlowTopologyEligibleTerminals: ({ edges, baselineEdges, nodes, eligibleEdgeIds, }: {
    edges: Edge[];
    baselineEdges: Edge[];
    nodes: Node[];
    eligibleEdgeIds: ReadonlySet<string>;
}) => Edge[] | null;
