import type { Edge, Node } from '@xyflow/react';
import { type SameSideEndpointTrunkIdentity } from '../../strategies/shared/edgeFinalSameSideEndpointOrderRepair.js';
export declare const preservesInitialTrueTrunks: (baseline: readonly SameSideEndpointTrunkIdentity[], candidate: readonly SameSideEndpointTrunkIdentity[]) => boolean;
/**
 * A trusted authored source bundle may supersede a smaller provisional source
 * trunk on another side of the same endpoint. All target trunks and unrelated
 * source trunks remain strict: this exception cannot erase either role of a
 * dual-trunk edge unless that source role moves into the larger restored bundle.
 */
export declare const preservesInitialTrueTrunksWithPreferredSourceSupersession: (baseline: readonly SameSideEndpointTrunkIdentity[], candidate: readonly SameSideEndpointTrunkIdentity[], restoredTrunk: SameSideEndpointTrunkIdentity | undefined, preferredEdges?: readonly Edge[], separatedSourceBranchIds?: ReadonlySet<string>) => boolean;
export declare const preservesCommercialTrueTrunkMembership: (baseline: readonly SameSideEndpointTrunkIdentity[], candidate: readonly SameSideEndpointTrunkIdentity[]) => boolean;
export declare const preservesInitialTrueTrunksWithinClearanceMargin: (baseline: readonly SameSideEndpointTrunkIdentity[], candidate: readonly SameSideEndpointTrunkIdentity[]) => boolean;
export declare const finalSameSideTrueTrunksDoNotRegress: (baselineEdges: readonly Edge[], candidateEdges: readonly Edge[], nodes: Node[]) => boolean;
