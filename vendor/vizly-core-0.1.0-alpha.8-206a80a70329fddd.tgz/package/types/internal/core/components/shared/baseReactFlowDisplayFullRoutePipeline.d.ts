import type { Edge } from '@xyflow/react';
import type { BaseReactFlowDisplayEdgesArgs, BaseReactFlowPreDisplayFinalEdgesFactory } from './baseReactFlowDisplayFullRouteTypes.js';
import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
export type { BaseReactFlowDisplayEdgesArgs, BaseReactFlowPreDisplayFinalEdgesFactory, } from './baseReactFlowDisplayFullRouteTypes.js';
export { selectBaseReactFlowFullRouteSeedEdges } from './baseReactFlowDisplayFullRouteSeedPhase.js';
export declare const createBaseReactFlowFullRouteEdges: (args: BaseReactFlowDisplayEdgesArgs & {
    createPreDisplayFinalEdges?: BaseReactFlowPreDisplayFinalEdgesFactory;
    onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void;
}) => Edge[];
