import type { Edge, Node } from '@xyflow/react';
import { type DisplayPoint } from './baseReactFlowDisplayGeometry.js';
import { type DisplayTerminalSide } from './baseReactFlowDisplayTerminalPolicy.js';
export declare const preserveCommercialPathSearchTerminalCorridor: (path: DisplayPoint[], anchor: DisplayPoint, baselineAdjacent: DisplayPoint | undefined, side: DisplayTerminalSide, role: 'source' | 'target') => DisplayPoint[];
/**
 * Bounded grid search used only as a hard-defect fallback after cheaper
 * terminal shortcuts fail. Node rectangles carry the commercial clearance,
 * while existing routes become soft line obstacles whose remaining conflicts
 * are rejected by the caller's exact graph-wide hard gate.
 */
export declare const buildCommercialPathSearchTerminalCandidates: (edge: Edge, nodes: Node[], allEdges: readonly Edge[]) => Edge[];
