import type { BaseReactFlowDisplayIncrementalRouteOutcome } from './baseReactFlowDisplayIncrementalRoute.js';
import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
import type { DisplayEdgesWorkerIncrementalRouteRequest, DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerProtocol.js';
export declare const displayIncrementalCandidateRequiresTopologyCommitGate: (classification: DisplayEdgesWorkerIncrementalRouteRequest['changeSet']['classification']) => boolean;
export declare const finalizeDisplayWorkerIncrementalCandidate: ({ request, incremental, onPhaseTrace, finalizeResponse, }: {
    request: DisplayEdgesWorkerIncrementalRouteRequest;
    incremental: BaseReactFlowDisplayIncrementalRouteOutcome;
    onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void;
    finalizeResponse: (response: DisplayEdgesWorkerResponse, eligibleEdgeIds: ReadonlySet<string>) => DisplayEdgesWorkerResponse;
}) => DisplayEdgesWorkerResponse | null;
