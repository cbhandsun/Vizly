import type { Edge, Node } from '@xyflow/react';
export declare const repairRenderSafeTerminalAxes: <T extends Edge[]>(edges: T, nodes: Node[], maxEvaluations?: number) => T;
