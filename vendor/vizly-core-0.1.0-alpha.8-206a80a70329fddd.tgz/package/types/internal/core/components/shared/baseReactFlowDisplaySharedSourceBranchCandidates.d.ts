import type { Edge, Node } from '@xyflow/react';
/**
 * Reuses a same-source peer corridor before branching to this edge's target.
 * This closes the common fan-out failure where a short branch cuts across a
 * longer sibling spine. Every returned route still goes through the caller's
 * graph-wide terminal, obstacle, crossing, and true-trunk gates.
 */
export declare const buildSharedSourcePeerBranchCandidates: (edges: Edge[], nodes: Node[], edgeIndex: number) => Edge[];
