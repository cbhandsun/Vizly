import type { BaseReactFlowRoutingChangeSet } from './baseReactFlowDisplayRoutingChangeSet.js';
declare const parseIdentifierList: (value: unknown) => string[] | null;
export declare const parseDisplayRoutingChangeSet: (value: unknown) => BaseReactFlowRoutingChangeSet | null;
export declare const parseDisplayRoutingIdentifierList: typeof parseIdentifierList;
export {};
