import type { DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
import type { DisplayEdgesWorkerRequest, DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerProtocol.js';
export declare const shouldPublishDisplayRoutingPhaseProgress: (trace: DisplayRoutingPhaseTrace) => boolean;
export declare const appendDisplayRoutingPhaseTrace: (phaseTrace: DisplayRoutingPhaseTrace[], trace: DisplayRoutingPhaseTrace) => boolean;
export declare const createDisplayRoutingPhaseRecorder: ({ requestId, phaseTrace, publish, publishProgress, }: {
    requestId: string;
    phaseTrace: DisplayRoutingPhaseTrace[];
    publish: (response: DisplayEdgesWorkerResponse) => void;
    publishProgress?: boolean;
}) => ((trace: DisplayRoutingPhaseTrace) => void);
export declare const createDisplayRoutingFallbackMetadata: (request: DisplayEdgesWorkerRequest, affectedEdgeCount: number | undefined) => Readonly<{
    affectedEdgeCount?: number;
    fallbackLevel?: 'full';
}>;
