export type OuterPortTerminalSide = 'top' | 'right' | 'bottom' | 'left';
export type OuterPortTerminalStubProfile = {
    sourceStub: number;
    targetStub: number;
};
export type OuterPortTerminalStubPlan = {
    preferred: OuterPortTerminalStubProfile[];
    fallback: OuterPortTerminalStubProfile[];
};
/**
 * Produces an ordered, bounded terminal-stub search plan. A terminal that
 * stays on its declared side gets the render-safe 56px stub first; a switched
 * terminal retains the regular 48px minimum. The fourth Cartesian profile is
 * held back as a fallback, so normal searches never pay a 2x2 expansion.
 */
export declare const buildOuterPortTerminalStubPlan: (minimumStub: number, sourceSide: OuterPortTerminalSide, targetSide: OuterPortTerminalSide, declaredSourceSide: OuterPortTerminalSide | null, declaredTargetSide: OuterPortTerminalSide | null) => OuterPortTerminalStubPlan;
