type GuideNode = {
    id?: string;
    type?: string;
    position?: {
        x?: unknown;
        y?: unknown;
    };
    measured?: {
        width?: unknown;
        height?: unknown;
    };
    style?: {
        width?: unknown;
        height?: unknown;
    };
    data?: Record<string, unknown>;
};
type GuideEnv = {
    getSearch: () => string;
    getStorageItem: (key: string) => string | null;
    onReadFailure?: (scope: string, error: unknown) => void;
};
export type BaseReactFlowRightEdgeGuideFlags = {
    rightLine: boolean;
    contentLine: boolean;
};
export type BaseReactFlowGuideLine = {
    x: number;
    y: number;
    height: number;
};
export type BaseReactFlowRightEdgeGuideLine = BaseReactFlowGuideLine & {
    key: string;
    kind: 'right' | 'content';
};
export declare const readBaseReactFlowAlignGuideEnabled: (env: GuideEnv) => boolean;
export declare const readBaseReactFlowRightEdgeGuideFlags: (env: GuideEnv) => BaseReactFlowRightEdgeGuideFlags;
export declare const computeBaseReactFlowAlignGuideLine: (nodes: GuideNode[]) => BaseReactFlowGuideLine | null;
export declare const computeBaseReactFlowRightEdgeGuideLines: ({ nodes, flags, }: {
    nodes: GuideNode[];
    flags: BaseReactFlowRightEdgeGuideFlags;
}) => BaseReactFlowRightEdgeGuideLine[];
export {};
