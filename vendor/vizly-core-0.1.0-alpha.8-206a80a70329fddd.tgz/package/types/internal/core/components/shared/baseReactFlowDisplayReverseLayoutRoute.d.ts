import type { Edge } from '@xyflow/react';
import type { DisplayEdgesWorkerRepairValidateOrRouteRequest, DisplayEdgesWorkerRequest, DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerProtocol.js';
type Compute = (request: Exclude<DisplayEdgesWorkerRequest, DisplayEdgesWorkerRepairValidateOrRouteRequest>) => DisplayEdgesWorkerResponse;
/** Normalize only uniform reversed layout transactions, not display or incremental jobs. */
export declare const routeDisplayReverseLayout: (request: DisplayEdgesWorkerRepairValidateOrRouteRequest, stagedCandidate: Edge[], compute: Compute) => DisplayEdgesWorkerResponse | null;
export {};
