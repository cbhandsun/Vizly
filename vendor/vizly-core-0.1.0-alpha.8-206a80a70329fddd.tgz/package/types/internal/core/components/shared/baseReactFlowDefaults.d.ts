import type { CSSProperties } from 'react';
export declare const BASE_REACT_FLOW_DEFAULT_VIEWPORT: {
    x: number;
    y: number;
    zoom: number;
};
export declare const BASE_REACT_FLOW_DEFAULT_SNAP_GRID: [number, number];
export declare const BASE_REACT_FLOW_DEFAULT_STYLE: CSSProperties;
