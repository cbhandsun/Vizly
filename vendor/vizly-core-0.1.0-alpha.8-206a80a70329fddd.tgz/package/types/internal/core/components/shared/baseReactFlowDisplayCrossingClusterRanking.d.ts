import type { Edge } from '@xyflow/react';
import type { DisplayPoint } from './baseReactFlowDisplayGeometry.js';
export type DisplayCrossingClusterPortSide = 'top' | 'bottom' | 'left' | 'right';
export type DisplayCrossingClusterCandidateMetrics = {
    group: string;
    laneExcursion: number;
    length: number;
    obstacleHits: number;
    pairRank: number;
    path: DisplayPoint[];
    pathSignature: string;
    sourceHandle: Edge['sourceHandle'];
    sourceClearance: number;
    strictCrossings: number;
    targetHandle: Edge['targetHandle'];
    targetClearance: number;
    unrelatedOverlap: number;
};
export type DisplayCrossingClusterLocalCandidate = DisplayCrossingClusterCandidateMetrics & ({
    kind: 'port-bridge';
    sourceSide: DisplayCrossingClusterPortSide;
    targetSide: DisplayCrossingClusterPortSide;
} | {
    kind: 'materialized';
    edge: Edge;
});
export type DisplayCrossingClusterRankedCandidate = DisplayCrossingClusterCandidateMetrics & {
    edge: Edge;
};
export declare const DISPLAY_CROSSING_CLUSTER_MAX_LOCAL_CANDIDATES = 8;
export declare const DISPLAY_CROSSING_CLUSTER_ENDPOINT_STUB = 48;
/**
 * Preserves the legacy quota and preference order while avoiding repeated
 * filter/sort passes after the single global stable sort.
 */
export declare const rankDisplayCrossingClusterCandidates: (candidates: DisplayCrossingClusterLocalCandidate[], primaryCorridorAxis: 'x' | 'y') => DisplayCrossingClusterLocalCandidate[];
