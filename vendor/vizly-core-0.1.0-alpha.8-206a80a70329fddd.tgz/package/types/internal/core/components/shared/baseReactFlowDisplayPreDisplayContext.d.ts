import type { Edge, Node } from '@xyflow/react';
import { type BaseDisplayHardGateMemo } from './baseReactFlowDisplayHardGateMemo.js';
import type { BaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
export type BaseReactFlowPreDisplayContext = Readonly<{
    repairNodes: Node[];
    getRouteHardQualityGateReport: BaseDisplayHardGateMemo['getReport'];
    routeTerminalsAreAttached: (edges: Edge[]) => boolean;
}>;
export declare const createBaseReactFlowPreDisplayContext: (nodes: Node[], evaluationSession?: BaseReactFlowFinalEndpointEvaluation) => BaseReactFlowPreDisplayContext;
