import type { BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
import type { DisplayEdgesWorkerResolvedIncrementalRouteRequest } from './baseReactFlowDisplayWorkerProtocol.js';
import type { DisplayRoutingWorkerSessionState } from './baseReactFlowDisplayWorkerSession.js';
import { type DisplayRoutingWorkerSpatialSnapshot } from './baseReactFlowDisplayWorkerSpatialSnapshot.js';
import { type BaseReactFlowDisplayIncrementalRouteOutcome } from './baseReactFlowDisplayIncrementalCandidateCommit.js';
export type { BaseReactFlowDisplayIncrementalRouteOutcome } from './baseReactFlowDisplayIncrementalCandidateCommit.js';
/**
 * Attempts an incident-only route against a frozen hard-clean baseline.
 * Returning null is an explicit request for the caller to execute the existing
 * full route in the same Worker job; no partial candidate may escape.
 */
export declare const createBaseReactFlowIncrementalDisplayEdges: ({ request, baselineSpatialSnapshot, exactNextSession, onPhaseTrace, onBoundedCandidate, }: {
    request: DisplayEdgesWorkerResolvedIncrementalRouteRequest;
    baselineSpatialSnapshot?: DisplayRoutingWorkerSpatialSnapshot | null;
    exactNextSession?: DisplayRoutingWorkerSessionState | null;
    onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void;
    onBoundedCandidate?: (report: BaseDisplayBoundedCandidateReport) => void;
}) => BaseReactFlowDisplayIncrementalRouteOutcome;
