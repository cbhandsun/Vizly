export declare const diagnoseDisplayEdgesWorkerResponseProtocolFailure: (value: unknown, expectedRequestId: string) => string | null;
