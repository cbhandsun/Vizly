import type { Edge, Node } from '@xyflow/react';
import { type EdgePathQualityScore } from '../../strategies/shared/edgeStrictCrossingGuard.js';
import { type DisplayPoint, type DisplaySegment } from './baseReactFlowDisplayGeometry.js';
export declare const residualOverlapScore: (quality: EdgePathQualityScore) => number;
type DisplayExactResidualEvaluationContext = {
    evaluate: (candidate: Edge[]) => number;
};
export declare const createDisplayExactResidualEvaluationContext: (baseline: Edge[]) => DisplayExactResidualEvaluationContext;
export declare const buildOppositeOverlapOuterBridgeCandidates: (path: DisplayPoint[], segment: DisplaySegment, other: DisplaySegment, otherPath: DisplayPoint[], nodes?: Node[], edge?: Edge) => DisplayPoint[][];
export declare const chooseExactThresholdResidualCandidate: <T extends Edge[]>(nodes: Node[], baseline: T, ...candidates: T[]) => T;
export {};
