import type { Edge } from '@xyflow/react';
import type { BaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
export declare const evaluateBaseReactFlowChangedCandidateReport: (baseline: readonly Edge[], candidate: Edge[], evaluation: BaseReactFlowFinalEndpointEvaluation) => Readonly<{
    changedEdgeIndexes: number[];
    report: ReturnType<BaseReactFlowFinalEndpointEvaluation['hardReportChanged']>;
}> | null;
