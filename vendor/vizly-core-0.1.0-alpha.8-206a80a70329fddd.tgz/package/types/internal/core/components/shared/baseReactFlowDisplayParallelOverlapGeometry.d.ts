import type { Edge } from '@xyflow/react';
import { type DisplaySegment } from './baseReactFlowDisplayGeometry.js';
export interface DisplayExactThresholdResidualPair {
    first: DisplaySegment;
    second: DisplaySegment;
    overlap: number;
}
/**
 * Collects visible collinear overlap pairs independently from any repair
 * strategy. Keeping this geometry-only prevents candidate builders and
 * transaction evaluators from depending on one another.
 */
export declare const collectExactThresholdResidualPairs: (edges: Edge[]) => DisplayExactThresholdResidualPair[];
