export type ReverseOverlapPoint = Readonly<{
    x: number;
    y: number;
}>;
export type ReverseOverlapAxis = 'h' | 'v';
export type ReverseOverlapSegmentRef = Readonly<{
    segmentIndex: number;
    axis: ReverseOverlapAxis;
    a: ReverseOverlapPoint;
    b: ReverseOverlapPoint;
}>;
/**
 * Builds deterministic, geometry-only candidates for an opposite-direction
 * parallel overlap. Obstacle and whole-graph quality acceptance remain the
 * caller's responsibility.
 */
export declare const buildReverseOverlapRepairCandidates: (path: readonly ReverseOverlapPoint[], segment: ReverseOverlapSegmentRef, other: ReverseOverlapSegmentRef, otherPath?: readonly ReverseOverlapPoint[], preferredSourceAxis?: ReverseOverlapAxis) => ReverseOverlapPoint[][];
