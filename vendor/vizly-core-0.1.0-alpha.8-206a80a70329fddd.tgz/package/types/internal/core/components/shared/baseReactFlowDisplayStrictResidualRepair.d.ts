import type { Edge, Node } from '@xyflow/react';
import { type StrictCrossingRepairDiagnostics } from './baseReactFlowDisplayStrictDiagnostics.js';
export { createStrictCrossingRepairDiagnostics, type StrictCrossingRepairDiagnostics, } from './baseReactFlowDisplayStrictDiagnostics.js';
export declare const repairInternalStrictCrossingLanes: <T extends Edge[]>(edges: T, nodes: Node[], diagnostics?: StrictCrossingRepairDiagnostics, maxQualityEvaluations?: number) => T;
export declare const repairFinalResidualStrictCrossings: <T extends Edge[]>(edges: T, nodes: Node[], diagnostics?: StrictCrossingRepairDiagnostics) => T;
