import type { Edge } from '@xyflow/react';
import type { BaseReactFlowFullRouteContext } from './baseReactFlowDisplayFullRouteTypes.js';
/** Try the existing residual closure after a crossed spine is resolved. */
export declare const tryDisplayQualityEarlyClosure: (context: BaseReactFlowFullRouteContext, edges: Edge[]) => Edge[] | null;
