import type { Edge } from '@xyflow/react';
/** Remove display-only route state before a fresh layout transaction. */
export declare const clearBaseReactFlowLayoutEdgeRoutingData: (data: Edge['data']) => Edge['data'];
