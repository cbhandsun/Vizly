import type { Edge, Node } from '@xyflow/react';
type Bounds = {
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
};
export declare const computeBaseReactFlowMinorResizeThreshold: ({ containerWidth, nodeCount, }: {
    containerWidth: number;
    nodeCount: number;
}) => number;
export declare const shouldSkipBaseReactFlowMinorResize: ({ currentSize, previousSize, nodeCount, }: {
    currentSize: {
        width: number;
        height: number;
    };
    previousSize: {
        width: number;
        height: number;
    } | null;
    nodeCount: number;
}) => boolean;
export declare const computeBaseReactFlowNodeBounds: (nodes: Node[]) => Bounds | null;
export declare const expandBaseReactFlowBoundsForEdges: ({ bounds, edges, }: {
    bounds: Bounds;
    edges: Edge[];
}) => Bounds & {
    contentWidth: number;
    contentHeight: number;
};
export declare const computeBaseReactFlowFitViewport: ({ bounds, containerSize, fitPadding, fitRatio, maxFitZoom, minZoom, maxZoom, hasInitialized, lastZoom, force, previousContainer, }: {
    bounds: Bounds & {
        contentWidth: number;
        contentHeight: number;
    };
    containerSize: {
        width: number;
        height: number;
    };
    fitPadding: number;
    fitRatio: number;
    maxFitZoom: number;
    minZoom: number;
    maxZoom: number;
    hasInitialized: boolean;
    lastZoom: number | null;
    force?: boolean;
    previousContainer: {
        width: number;
        height: number;
    } | null;
}) => {
    x: number;
    y: number;
    zoom: number;
};
export {};
