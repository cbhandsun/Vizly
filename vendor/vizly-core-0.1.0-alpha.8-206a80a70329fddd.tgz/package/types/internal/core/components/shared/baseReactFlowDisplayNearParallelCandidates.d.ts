import type { Edge, Node } from '@xyflow/react';
import { type DisplayPoint, type DisplaySegment } from './baseReactFlowDisplayGeometry.js';
export declare const buildNearParallelLaneNudgePaths: (path: DisplayPoint[], segment: DisplaySegment, other: DisplaySegment, otherPath: DisplayPoint[], nodes: Node[], edge: Edge, allEdges: Edge[], maxCandidates?: number) => DisplayPoint[][];
