import type { Edge, Node } from '@xyflow/react';
import { type BaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
export type BaseReactFlowFinalSafetyAudit = Readonly<{
    canSkip: boolean;
    defect: 'none' | 'hard' | 'stubs' | 'endpoint-order' | 'passage-order';
    endpointDefectOnly: boolean;
}>;
export declare const auditBaseReactFlowFinalSafetyClosure: (edges: readonly Edge[], nodes: Node[], evaluation?: BaseReactFlowFinalEndpointEvaluation, onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void) => BaseReactFlowFinalSafetyAudit;
