import type { Edge } from '@xyflow/react';
/**
 * A graph-level polish transaction must not make one edge absorb the entire
 * cost of improving another. Small bounded increases remain legal because
 * endpoint separation and obstacle skirts require routing slack.
 */
export declare const commercialEdgeDetoursDoNotRegress: (baselineEdges: readonly Edge[], candidateEdges: readonly Edge[], changedEdgeIndexes: readonly number[]) => boolean;
