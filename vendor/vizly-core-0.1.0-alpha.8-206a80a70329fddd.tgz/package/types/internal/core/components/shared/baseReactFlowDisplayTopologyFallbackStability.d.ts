import type { DisplayEdgesWorkerResolvedIncrementalRouteRequest, DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerProtocol.js';
import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
type DisplayTopologyFallbackQuality = Readonly<{
    totalLength: number;
    bends: number;
    backtrackPenalty: number;
    detourPenalty: number;
    crossingCost?: number;
}>;
/**
 * Endpoint coordinates can differ by one diagram unit after measured geometry
 * is rounded on each side of an otherwise valid route. Preserve the committed
 * route through a topology fallback when that is the only bounded soft-quality
 * difference; hard geometry and every structural quality metric still gate it.
 */
export declare const baseReactFlowDisplayTopologyFallbackQualityIsStable: ({ initial, candidate, restoredCount, }: {
    initial: DisplayTopologyFallbackQuality;
    candidate: DisplayTopologyFallbackQuality;
    restoredCount: number;
}) => boolean;
/** One collective stability candidate; no per-edge search or weaker fallback gate. */
export declare const preserveDisplayTopologyFallbackRoutes: (request: DisplayEdgesWorkerResolvedIncrementalRouteRequest, response: DisplayEdgesWorkerResponse, onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void) => DisplayEdgesWorkerResponse;
export {};
