import type { Edge } from '@xyflow/react';
export declare const doesDisplayCandidateMatchSourceGraph: (sourceEdges: Edge[], candidateEdges: Edge[]) => boolean;
export declare const finalDisplayRenderContractIsLocked: (sourceEdges: Edge[], lockedEdges: Edge[]) => boolean;
export declare const analyzeFinalDisplayRenderContract: (sourceEdges: Edge[], lockedEdges: Edge[]) => Readonly<{
    renderContractIsLocked: boolean;
    lockedRouteMatches: boolean;
    lockedHardGateInputsMatch: boolean;
}>;
/** Retains request-local audit caches when a repair materializes no geometry. */
export declare const selectHardCleanDisplayCandidate: <T extends Edge[]>(auditedBaseline: T, candidate: T, isHardClean: (edges: T) => boolean) => T;
