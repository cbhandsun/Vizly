import type { Edge, Node } from '@xyflow/react';
import type { DisplayMicroCleanupSafetyContext } from '../../strategies/shared/edgeDisplayMicroCleanup.js';
/**
 * Compiles node obstacles and terminal rectangles once for a micro-cleanup
 * transaction. Candidate evaluation is exact for cumulative changed indexes
 * and falls back to a full scan when a caller supplies an invalid delta.
 */
export declare const createBaseReactFlowDisplayMicroSafetyContext: (baseline: Edge[], nodes: Node[]) => DisplayMicroCleanupSafetyContext;
