import type { Edge, Node } from '@xyflow/react';
import { type BaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
import { type BaseReactFlowFinalEndpointOrderOptions } from './baseReactFlowDisplayFinalEndpointGate.js';
type FinalEndpointCommercialClosureCallbacks = Readonly<{
    restorePreferredSourceTrunks: (baseline: Edge[]) => Edge[];
    repairEndpointOrder: (baseline: Edge[]) => Edge[];
    separatePreferredSourceBranches: (baseline: Edge[]) => Edge[];
}>;
/**
 * Final, commercial-style endpoint cleanup after geometric hard closure.
 *
 * This stays separate from the main endpoint transaction so every expensive
 * substep gets its own bounded, content-free trace entry.  The trace exposes
 * which contract consumed time without leaking edge ids, labels, or route
 * coordinates through diagnostics.
 */
export declare const repairBaseReactFlowFinalEndpointCommercialClosure: (baseline: Edge[], repairNodes: Node[], options: BaseReactFlowFinalEndpointOrderOptions, evaluation: BaseReactFlowFinalEndpointEvaluation, callbacks: FinalEndpointCommercialClosureCallbacks) => Edge[];
export {};
