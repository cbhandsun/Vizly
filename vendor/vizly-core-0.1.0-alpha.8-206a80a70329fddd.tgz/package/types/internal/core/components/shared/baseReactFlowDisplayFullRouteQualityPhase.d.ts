import type { Edge } from '@xyflow/react';
import type { BaseReactFlowFullRouteContext } from './baseReactFlowDisplayFullRouteTypes.js';
export { boundedQualityPolishNeedsMicroRepair, canSkipLargeDetachedOverlapRepair, separateLargeDetachedParallelOverlapsIfNeeded, shouldMaterializeDetachedMicroAlternative, shouldMaterializePostEndpointLocalAlternative, shouldMaterializeQualityMicroAlternative, shouldUseBoundedQualityResidualRepair, } from './baseReactFlowDisplayQualityPolishSupport.js';
export { hasSharedTargetEntryStrictCrossing, repairSharedTargetEntryStrictCrossingsIfNeeded, } from './baseReactFlowDisplaySharedTargetEntry.js';
export declare const createBaseReactFlowFullRouteQualityEdges: (context: BaseReactFlowFullRouteContext) => Edge[];
