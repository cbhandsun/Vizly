/**
 * Memoizes evidence derived from an immutable request-local object reference.
 * Values are wrapped so `null` and `undefined` remain valid computed results.
 */
export declare const createBaseReactFlowRequestMemo: <Input extends object, Result>(compute: (input: Input) => Result) => ((input: Input) => Result);
