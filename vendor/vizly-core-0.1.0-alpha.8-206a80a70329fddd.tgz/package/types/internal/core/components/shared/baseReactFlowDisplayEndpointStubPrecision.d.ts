import type { Edge } from '@xyflow/react';
/**
 * Removes only floating-point deficits below one pixel. Larger endpoint
 * changes remain the responsibility of the bounded obstacle-aware repair.
 * The caller still owns the whole-graph hard gate before committing results.
 */
export declare const repairSubpixelEndpointStubPrecision: <T extends Edge[]>(edges: T, requestedMinimumStub?: number) => T;
