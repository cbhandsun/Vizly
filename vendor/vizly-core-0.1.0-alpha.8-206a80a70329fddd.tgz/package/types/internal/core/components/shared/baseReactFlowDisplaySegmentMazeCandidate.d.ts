import type { Edge, Node } from '@xyflow/react';
import { type DisplaySegment } from './baseReactFlowDisplayGeometry.js';
/** Builds one local maze alternative; callers remain responsible for graph-wide acceptance. */
export declare const buildDisplaySegmentMazeCandidate: (edges: Edge[], nodes: Node[], moving: DisplaySegment, opposing: DisplaySegment) => Edge | null;
