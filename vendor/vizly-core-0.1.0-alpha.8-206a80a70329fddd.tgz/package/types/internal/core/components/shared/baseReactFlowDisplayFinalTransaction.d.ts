import type { Edge, Node } from '@xyflow/react';
import type { BaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
export declare const finalizeFailClosedDisplayTransaction: <T extends Edge[]>(fallbackCandidate: T, repairNodes: Node[], inputSignature: string, options?: Readonly<{
    deferCompoundRepair?: boolean;
    evaluation?: BaseReactFlowFinalEndpointEvaluation;
    onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void;
}>) => T;
