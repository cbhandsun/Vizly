export interface LayoutConfig {
    CANVAS_WIDTH: number;
    CANVAS_HEIGHT: number;
    NODE_WIDTH?: number;
    GROUP_PADDING: {
        H: number;
        V: number;
    };
    SUB_GROUP_PADDING: {
        H: number;
        V_TOP: number;
        V_BOTTOM: number;
    };
    SPACING?: {
        H: number;
        V: number;
    };
    LANE_PADDING?: {
        X: number;
        Y: number;
    };
    TITLE_BAR_HEIGHT: number;
    NODE_HEIGHT: number;
    MAIN_COL_WIDTH: number;
    MAIN_TO_SIDE_GAP: number;
    LAYER_V_GAP: number;
    ROW_V_GAP: number;
    FOUNDATION_GAP: number;
    SCM_NODE_HEIGHT: number;
    LOGISTICS_NODE_HEIGHT: number;
    CORP_NODE_HEIGHT: number;
    LOGISTICS_BMS_NODE_HEIGHT: number;
    CORP_V_SPACING: number;
    BE_COLUMN_GAP: number;
    DATA_COLLECT_GAP: number;
    DATA_V_GAP: number;
    START_Y_POSITION: number;
    NODE_MARGIN: number;
    calculateDomainMinWidth: () => number;
    DOMAIN_MIN_WIDTH: number;
}
export declare const DEFAULT_CONFIG: LayoutConfig;
export declare const LOGISTICS_CONFIG: LayoutConfig;
export declare const WMS_CONFIG: LayoutConfig;
export declare const TMS_CONFIG: LayoutConfig;
