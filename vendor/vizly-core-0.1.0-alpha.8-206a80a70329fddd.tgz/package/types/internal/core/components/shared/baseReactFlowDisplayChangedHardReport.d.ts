import type { Edge, Node } from '@xyflow/react';
import { type EdgePathQualityScore } from '../../strategies/shared/edgeStrictCrossingGuard.js';
import { type BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
import type { DisplayTerminalValidationSnapshot } from './baseReactFlowTerminalAxisRepair.js';
export type BaseReactFlowChangedHardReportEvaluation = Readonly<{
    evaluate: (candidate: Edge[], changedEdgeIndexes: readonly number[], candidateKind: BaseDisplayBoundedCandidateReport['candidate'], knownEvidence?: BaseReactFlowChangedHardReportEvidence) => BaseDisplayBoundedCandidateReport | null;
    readMetrics: () => Readonly<{
        evaluationCount: number;
        scannedNodeCount: number;
        scannedEdgePairCount: number;
    }>;
}>;
export type BaseReactFlowChangedHardReportEvidence = Readonly<{
    minimumClearanceViolation?: boolean;
    obstacleHits?: number;
    quality?: EdgePathQualityScore;
}>;
/**
 * Exact baseline-relative hard report for immutable, bounded edge changes.
 * Every component uses the same full-graph semantics as the normal hard gate;
 * only unchanged edge contributions are reused.
 */
export declare const createBaseReactFlowChangedHardReportEvaluation: (baseline: Edge[], nodes: Node[], terminalSnapshot?: DisplayTerminalValidationSnapshot) => BaseReactFlowChangedHardReportEvaluation;
