import type { Edge } from '@xyflow/react';
/** Marks a bounded isolated shortcut crossing for request-local quality identity. */
export declare const withDisplayLocalShortcutSoftCrossingBridge: (candidateEdge: Edge, candidateEdges: Edge[], savedLength: number) => Edge;
