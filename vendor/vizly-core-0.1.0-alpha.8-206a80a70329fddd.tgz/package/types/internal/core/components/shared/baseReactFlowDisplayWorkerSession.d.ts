import type { Edge, Node } from '@xyflow/react';
import type { RoutingPatch } from '../../routing/routingPatch.js';
import type { RoutingIdentity, RoutingWorkerSessionRef } from './baseReactFlowDisplayRoutingSession.js';
import { type RoutingTopologyPlan } from './baseReactFlowDisplayRoutingTopologyPlan.js';
import type { BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
import { type DisplayRoutingWorkerSpatialSnapshot } from './baseReactFlowDisplayWorkerSpatialSnapshot.js';
export type DisplayRoutingWorkerSessionState = Readonly<{
    ref: RoutingWorkerSessionRef;
    nodes: Node[];
    sourceEdges: Edge[];
    displayPatches: RoutingPatch[];
    topologyPlan: RoutingTopologyPlan;
    spatialSnapshot: DisplayRoutingWorkerSpatialSnapshot | null;
    hardReport?: BaseDisplayBoundedCandidateReport;
}>;
export declare const writeDisplayRoutingWorkerSession: ({ identity, outputRouteSignature, nodes, sourceEdges, displayPatches, finalEdges, hardReport, }: {
    identity: RoutingIdentity;
    outputRouteSignature: string;
    nodes: Node[];
    sourceEdges: Edge[];
    displayPatches: RoutingPatch[];
    finalEdges: Edge[];
    hardReport?: BaseDisplayBoundedCandidateReport;
}) => RoutingWorkerSessionRef;
export declare const readDisplayRoutingWorkerSession: ({ ref, expectedIdentity, expectedOutputRouteSignature, }: {
    ref: RoutingWorkerSessionRef | null | undefined;
    expectedIdentity: RoutingIdentity;
    expectedOutputRouteSignature: string;
}) => DisplayRoutingWorkerSessionState | null;
/**
 * Resolves only a Worker-private state whose full routing identity matches.
 * This intentionally accepts no caller-provided session id: it is used for
 * reversible topology edits that return to geometry already committed by the
 * same Worker realm.
 */
export declare const readDisplayRoutingWorkerSessionByIdentity: ({ expectedIdentity, }: {
    expectedIdentity: RoutingIdentity;
}) => DisplayRoutingWorkerSessionState | null;
export declare const clearDisplayRoutingWorkerSessions: () => void;
