import type { Edge, Node } from '@xyflow/react';
import type { RoutingPatch } from '../../routing/routingPatch.js';
import type { BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
import { type BaseReactFlowRoutingChangeSet } from './baseReactFlowDisplayRoutingChangeSet.js';
export declare const MAX_BASE_REACT_FLOW_TOPOLOGY_INCREMENTAL_CHANGES = 8;
export type BaseReactFlowTopologyIncrementalKind = 'edge-add' | 'edge-remove' | 'node-add' | 'node-remove' | 'port-policy' | 'container-change';
export type BaseReactFlowTopologyIncrementalProjection = Readonly<{
    kind: BaseReactFlowTopologyIncrementalKind;
    edges: Edge[];
    changedPresentEdgeIds: string[];
    removedEdgeIds: string[];
    incidentContextEdgeIds: string[];
}>;
export type BaseReactFlowTopologyIncrementalCandidate = Readonly<{
    edges: Edge[];
    eligibleEdgeIds: string[];
}>;
export type BaseReactFlowTopologyIncrementalRouteOutcome = Readonly<{
    edges: Edge[] | null;
    eligibleEdgeIds: string[];
    hardReport?: BaseDisplayBoundedCandidateReport;
}>;
/**
 * Projects a trusted routing-only baseline onto the next topology by edge id.
 * Unsupported or ambiguous topology transactions fail closed before routing.
 */
export declare const createBaseReactFlowTopologyIncrementalProjection: ({ baselineNodes, baselineSourceEdges, baselineEdges, baselinePatches, nextNodes, nextEdges, changeSet, }: {
    baselineNodes: readonly Node[];
    baselineSourceEdges: Edge[];
    baselineEdges: Edge[];
    baselinePatches: RoutingPatch[];
    nextNodes: readonly Node[];
    nextEdges: Edge[];
    changeSet: BaseReactFlowRoutingChangeSet;
}) => BaseReactFlowTopologyIncrementalProjection | null;
/** Routes only edges introduced by, or explicitly changed in, the transaction. */
export declare const createBaseReactFlowTopologyIncrementalCandidate: ({ projection, nodes, enableSmartEdges, smartEdgePadding, displayEdgeEpoch, }: {
    projection: BaseReactFlowTopologyIncrementalProjection;
    nodes: Node[];
    enableSmartEdges: boolean;
    smartEdgePadding: number;
    displayEdgeEpoch: number;
}) => BaseReactFlowTopologyIncrementalCandidate | null;
/**
 * Runs one bounded topology-local transaction. Any unresolved hard defect is
 * returned as a safe miss so the Worker can execute its full route in-job.
 */
export declare const createBaseReactFlowTopologyIncrementalDisplayEdges: ({ projection, nodes, enableSmartEdges, smartEdgePadding, displayEdgeEpoch, onRejectedReport, }: {
    projection: BaseReactFlowTopologyIncrementalProjection;
    nodes: Node[];
    enableSmartEdges: boolean;
    smartEdgePadding: number;
    displayEdgeEpoch: number;
    onRejectedReport?: (report: BaseDisplayBoundedCandidateReport) => void;
}) => BaseReactFlowTopologyIncrementalRouteOutcome;
