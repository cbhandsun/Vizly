export type SharedNodePortPoint = Readonly<{
    x: number;
    y: number;
}>;
export type SharedNodePortRect = Readonly<{
    x: number;
    y: number;
    width: number;
    height: number;
}>;
export type SharedNodePortSide = 'top' | 'bottom' | 'left' | 'right';
export type SharedNodePortRole = 'source' | 'target';
/**
 * Builds bounded geometry-only candidates that move one terminal to another
 * side of the same node. The caller remains responsible for port-policy,
 * obstacle, and whole-graph quality gates.
 */
export declare const buildSharedNodeTerminalSideCandidates: (path: readonly SharedNodePortPoint[], role: SharedNodePortRole, rect: SharedNodePortRect, side: SharedNodePortSide, minStub?: number, maxCandidates?: number, connectorLanes?: readonly number[]) => SharedNodePortPoint[][];
/**
 * Preserves the nearest stable exterior lane while replacing only the final
 * terminal neighborhood. The wider shared-node candidates above deliberately
 * splice farther back; this bounded companion covers paths whose outer detour
 * is already clean but whose last segments slide tangentially on a node.
 */
export declare const buildNearTerminalSideCandidates: (path: readonly SharedNodePortPoint[], role: SharedNodePortRole, rect: SharedNodePortRect, side: SharedNodePortSide, minStub?: number, maxCandidates?: number) => SharedNodePortPoint[][];
export declare const buildFacingPortPathCandidates: (sourceRect: SharedNodePortRect, targetRect: SharedNodePortRect, sourceSide: SharedNodePortSide, targetSide: SharedNodePortSide, minStub?: number) => SharedNodePortPoint[][];
/**
 * Reuses a clean peer's outward source trunk, then splices into a later
 * perpendicular segment of the current route. This avoids adding a competing
 * terminal stub beside an already valid shared trunk.
 */
export declare const buildSharedSourceTrunkAdoptionCandidates: (path: readonly SharedNodePortPoint[], peerPath: readonly SharedNodePortPoint[], minStub?: number, maxCandidates?: number) => SharedNodePortPoint[][];
