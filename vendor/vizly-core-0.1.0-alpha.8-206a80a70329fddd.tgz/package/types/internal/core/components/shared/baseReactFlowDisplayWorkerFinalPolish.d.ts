import type { Edge, Node } from '@xyflow/react';
import type { DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerProtocol.js';
type FinalPolishEvaluation = Readonly<{
    hardReport: (candidate: Edge[]) => Readonly<{
        hardClean: boolean;
    }>;
}>;
export declare const polishDisplayWorkerFinalRoutes: ({ eligibleEdgeIds, evaluation, repairNodes, response, }: {
    eligibleEdgeIds?: ReadonlySet<string>;
    evaluation: FinalPolishEvaluation;
    repairNodes: Node[];
    response: DisplayEdgesWorkerResponse;
}) => Readonly<{
    response: DisplayEdgesWorkerResponse;
    routesChanged: boolean;
}>;
export {};
