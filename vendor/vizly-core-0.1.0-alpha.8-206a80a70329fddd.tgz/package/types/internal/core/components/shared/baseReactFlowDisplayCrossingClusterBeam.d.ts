import type { Edge } from '@xyflow/react';
import type { EdgePathQualityScore } from '../../strategies/shared/edgeStrictCrossingGuard.js';
import type { DisplaySegment } from './baseReactFlowDisplayGeometry.js';
export type BeamState<T extends Edge[]> = {
    edges: T;
    segments: DisplaySegment[];
    quality: EdgePathQualityScore;
    obstacleHits: number;
    changedIndexes: number[];
    signature: string;
};
export declare const MAX_BEAM_WIDTH = 8;
export declare const compareBeamStates: <T extends Edge[]>(first: BeamState<T>, second: BeamState<T>) => number;
/**
 * A residual crossing can migrate from one edge pair to another while a valid
 * multi-edge repair is being assembled. Keeping only the globally shortest
 * partial paths tends to discard that progress because all intermediate
 * states can still have the same strict-crossing count. Preserve a small,
 * deterministic sample across both crossing topology and changed-edge sets,
 * then fill the remaining beam slots by the normal quality ordering.
 */
export declare const selectDiverseBeamStates: <T extends Edge[]>(states: BeamState<T>[]) => BeamState<T>[];
