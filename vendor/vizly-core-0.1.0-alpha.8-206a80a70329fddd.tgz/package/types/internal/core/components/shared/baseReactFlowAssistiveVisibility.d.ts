/**
 * Keeps plugin-owned canvas content available while removing the replaced
 * React Flow renderer from the accessibility tree.
 */
export declare const syncBaseReactFlowRendererAssistiveVisibility: (container: HTMLElement | null, hidden: boolean) => HTMLElement | null;
export declare const bindBaseReactFlowRendererAssistiveVisibility: (container: HTMLElement | null, hidden: boolean) => (() => void);
