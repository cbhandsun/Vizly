import type { Node } from '@xyflow/react';
import { type GeometryHemisphere, type PeerHemisphereFlowAxis, type PeerHemisphereOptions } from '../../strategies/shared/edgeSharedTrunkSynthesisUtils.js';
import { type DisplayRect } from './baseReactFlowDisplayGeometry.js';
export declare const classifyDisplayPeerHemisphere: (hub: DisplayRect, peer: DisplayRect, options?: PeerHemisphereOptions) => GeometryHemisphere;
export declare const displayPeerHemispheresAreOpposite: (first: GeometryHemisphere, second: GeometryHemisphere) => boolean;
export declare const displayPortSideFlowAxis: (side: GeometryHemisphere) => PeerHemisphereFlowAxis;
export declare const shouldSkipSharedSourceTrunkAcrossOppositeHemisphere: (nodesById: ReadonlyMap<string, Node>, sourceId: string, targetId: string, peerTargetId: string, options?: PeerHemisphereOptions) => boolean;
export declare const shouldSkipSharedSourceTrunkForPortSide: (nodesById: ReadonlyMap<string, Node>, sourceId: string, targetId: string, peerTargetId: string, portSide: GeometryHemisphere) => boolean;
