import type { DisplayQualityMode } from './baseReactFlowDisplayWorkerProtocol.js';
export declare const DISPLAY_WORKER_TIMEOUT_MS = 60000;
export declare const PRECOMPILED_CAPTURE_WORKER_TIMEOUT_MS = 120000;
export declare const INTERACTIVE_DISPLAY_WORKER_TIMEOUT_MS = 12000;
export declare const LAYOUT_DISPLAY_WORKER_TIMEOUT_MS = 12000;
export declare const LAYOUT_PRIMARY_FULL_DISPLAY_WORKER_TIMEOUT_MS = 60000;
export declare const LAYOUT_FULL_DISPLAY_WORKER_TIMEOUT_MS = 30000;
export declare const resolveBaseReactFlowDisplayWorkerTimeoutMs: (timeoutMs: number, qualityMode: DisplayQualityMode) => number;
