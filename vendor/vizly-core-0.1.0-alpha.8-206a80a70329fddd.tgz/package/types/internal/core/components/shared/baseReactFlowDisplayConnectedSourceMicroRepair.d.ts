import type { Edge, Node } from '@xyflow/react';
/**
 * Repairs a micro stair that is topologically blocked by sibling source lanes.
 * Connected business targets are synthesized as one commercial trunk while
 * leaf branches stay on their authored corridor and are marked as separated.
 */
export declare const repairBaseReactFlowConnectedSourceMicroArtifacts: (edges: Edge[], nodes: Node[]) => Edge[];
