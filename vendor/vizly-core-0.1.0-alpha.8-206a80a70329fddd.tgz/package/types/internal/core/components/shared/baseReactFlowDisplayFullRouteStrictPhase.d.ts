import type { Edge } from '@xyflow/react';
import { type EdgePathQualityScore } from '../../strategies/shared/edgeStrictCrossingGuard.js';
import type { BaseReactFlowFullRouteContext } from './baseReactFlowDisplayFullRouteTypes.js';
import { type RoutingDefectPlan } from './baseReactFlowDisplayRoutingDefectPlan.js';
export type BaseReactFlowFullRouteStrictResult = {
    kind: 'finalized';
    edges: Edge[];
} | {
    kind: 'continue';
    edges: Edge[];
};
export declare const runBaseReactFlowFullRouteStrictPhase: (context: BaseReactFlowFullRouteContext, postSoftEdges: Edge[], postSoftQuality: EdgePathQualityScore, defectPlan: RoutingDefectPlan, skipInitialOverlapRepair?: boolean) => BaseReactFlowFullRouteStrictResult;
