import type { Edge, Node } from '@xyflow/react';
import { type BaseReactFlowDisplayFinalizerOutcome } from './baseReactFlowDisplayFinalizer.js';
import type { DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
import type { BaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
/**
 * Closes the exact route that is about to be rendered. Strict-crossing repair
 * runs before the terminal transaction because a graph-wide hard gate must not
 * reject a safe paired-port change merely due to an independent crossing.
 */
export declare const closeBaseReactFlowDisplayFinalHardContract: <T extends Edge[]>(edges: T, nodes: Node[], onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void, evaluation?: BaseReactFlowFinalEndpointEvaluation) => BaseReactFlowDisplayFinalizerOutcome<T>;
