import type { Edge, Node } from '@xyflow/react';
export declare const recordBaseReactFlowRejectedDisplayDiagnostics: ({ edges, nodes, sourceEdges, initialEdges, }: {
    edges: Edge[];
    nodes: Node[];
    sourceEdges?: Edge[];
    initialEdges?: Edge[];
}) => void;
