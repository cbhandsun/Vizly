import type { Edge, Node } from '@xyflow/react';
import { type DisplayPoint, type DisplayRect } from './baseReactFlowDisplayGeometry.js';
type TerminalRole = 'source' | 'target';
type TerminalSide = 'top' | 'bottom' | 'left' | 'right';
export type DeclaredTerminalRoleRepairOutcome<T extends Edge[] = Edge[]> = Readonly<{
    edges: T;
    exactEvaluations: number;
}>;
/**
 * Rebuilds only the terminal approach. Every candidate starts on the declared
 * node side, travels outward for a render-safe stub, and reconnects to an
 * existing local waypoint. No graph coordinates or edge identities are baked
 * into the search.
 */
export declare const buildDeclaredTerminalRoleRepairPaths: (path: DisplayPoint[], role: TerminalRole, rect: DisplayRect, side: TerminalSide, priorityTangents?: readonly number[]) => DisplayPoint[][];
/**
 * Repairs the narrow residual where ordinary terminal anchoring passes but a
 * declared handle axis does not. A graph is returned only when the complete
 * hard gate passes, so no partial terminal edit can leak into display output.
 */
export declare const repairDeclaredTerminalRolesWithHardGateWithOutcome: <T extends Edge[]>(edges: T, nodes: Node[], maxEvaluations?: number) => DeclaredTerminalRoleRepairOutcome<T>;
export declare const repairDeclaredTerminalRolesWithHardGate: <T extends Edge[]>(edges: T, nodes: Node[], maxEvaluations?: number) => T;
export {};
