import type { Node } from '@xyflow/react';
import { type DisplayPoint, type DisplaySegment } from './baseReactFlowDisplayGeometry.js';
export declare const STRICT_OBSTACLE_SIDE_CLEARANCES: number[];
export declare const buildStrictObstacleSideBridgeXs: (nodes: Node[], fromY: number, toY: number) => number[];
export declare const buildStrictObstacleSideBridgeYs: (nodes: Node[], fromX: number, toX: number) => number[];
export declare const buildStrictInterSegmentLaneXs: (path: DisplayPoint[], segments: Array<Pick<DisplaySegment, 'axis' | 'a' | 'b'>>) => number[];
export declare const buildStrictInterSegmentLaneYs: (path: DisplayPoint[], segments: Array<Pick<DisplaySegment, 'axis' | 'a' | 'b'>>) => number[];
