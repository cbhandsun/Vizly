import type { RoutingWorkerSessionRef } from './baseReactFlowDisplayRoutingSession.js';
export declare const rememberDisplayWorkerSession: (worker: Worker | null, sessionRef: RoutingWorkerSessionRef | undefined) => void;
export declare const displayWorkerKnowsSession: (worker: Worker | null, sessionRef: RoutingWorkerSessionRef | undefined) => boolean;
