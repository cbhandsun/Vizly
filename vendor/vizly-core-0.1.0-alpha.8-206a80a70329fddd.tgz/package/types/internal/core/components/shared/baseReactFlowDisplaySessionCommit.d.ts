import type { Edge, Node } from '@xyflow/react';
import type { RoutingPatch } from '../../routing/routingPatch.js';
import type { BaseReactFlowDisplayCommittedSnapshotBaseline } from './baseReactFlowDisplayCommittedSnapshot.js';
import type { DisplayRoutingWorkerCommitReceipt } from './baseReactFlowDisplayWorkerCommitReceipt.js';
import type { BaseReactFlowRoutingSessionJob, BaseReactFlowRoutingSessionRuntime } from './baseReactFlowRoutingSessionRuntime.js';
export type BaseReactFlowDisplaySessionCommitResult = Readonly<{
    committed: boolean;
    cancelCacheWrite?: () => void;
}>;
/** Atomically publishes one hard-gated display result under its Canvas epoch. */
export declare const commitBaseReactFlowDisplaySessionResult: ({ runtime, job, inputSignature, inputGeometryDigest, sourceEdges, sourceNodes, finalEdges, displayPatches, cachePatches, cacheReplaySignature, outputRouteSignature, commitReceipt, precompiledCapturePresetId, rememberCommittedBaseline, applyFinalGeometry, onRejected, }: {
    runtime: BaseReactFlowRoutingSessionRuntime;
    job: BaseReactFlowRoutingSessionJob;
    inputSignature: string;
    inputGeometryDigest: string;
    sourceEdges: Edge[];
    sourceNodes: Node[];
    finalEdges: Edge[];
    displayPatches: RoutingPatch[];
    cachePatches: RoutingPatch[] | null;
    cacheReplaySignature: string | null;
    outputRouteSignature: string | null;
    commitReceipt: DisplayRoutingWorkerCommitReceipt;
    precompiledCapturePresetId?: string | null;
    rememberCommittedBaseline: (baseline: BaseReactFlowDisplayCommittedSnapshotBaseline, edges: Edge[]) => void;
    applyFinalGeometry: () => void;
    onRejected?: () => void;
}) => BaseReactFlowDisplaySessionCommitResult;
