import type { Edge, Node } from '@xyflow/react';
import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
import { type DisplayQualityBudget } from './baseReactFlowDisplayEvaluation.js';
export declare const DISPLAY_FINAL_OVERLAP_OBSTACLE_REPAIR_OPTIONS: {
    maxEdges: number;
    maxCandidatesPerEdge: number;
    maxQualityEvaluations: number;
};
/**
 * Commits an already quality-validated route to the renderer selected by the
 * current display mode without running another geometry-polish transaction.
 *
 * Full-route safety phases can finish early after closing their last hard
 * defect. Those candidates are geometrically final, but they still need the
 * same smart/basic/canvas conversion as the normal post-render path. Keeping
 * this conversion separate prevents an early safety exit from leaking raw
 * edge types while also preserving an accepted shared-trunk transaction.
 */
export declare const commitDisplayEdgesForRenderMode: ({ finalQualityEdges, rawEdges, enableSmartEdges, smartEdgePadding, isLargeGraph, inputSignature, nodes, }: {
    finalQualityEdges: Edge[];
    rawEdges: Edge[];
    enableSmartEdges: boolean;
    smartEdgePadding: number;
    isLargeGraph: boolean;
    inputSignature: string;
    nodes: Node[];
}) => Edge[];
export declare const finishInteractiveDisplayEdgesForRenderMode: ({ finalQualityEdges, rawEdges, repairNodes, layoutDirection, enableSmartEdges, smartEdgePadding, inputSignature, deferOuterObstacleRepair, onPhaseTrace, }: {
    finalQualityEdges: Edge[];
    rawEdges: Edge[];
    repairNodes: Node[];
    layoutDirection: string;
    enableSmartEdges: boolean;
    smartEdgePadding: number;
    inputSignature: string;
    deferOuterObstacleRepair?: boolean;
    onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void;
}) => Edge[];
export declare const finalizeDisplayEdgesForRenderMode: ({ finalQualityEdges, rawEdges, repairNodes, renderNodes, enableSmartEdges, smartEdgePadding, isLargeGraph, layoutDirection, inputSignature, qualityBudget, }: {
    finalQualityEdges: Edge[];
    rawEdges: Edge[];
    repairNodes: Node[];
    renderNodes: Node[];
    enableSmartEdges: boolean;
    smartEdgePadding: number;
    isLargeGraph: boolean;
    layoutDirection: string;
    inputSignature: string;
    qualityBudget: DisplayQualityBudget;
}) => Edge[];
