export type OrthogonalPathPoint = Readonly<{
    x: number;
    y: number;
}>;
export type OrthogonalSegmentAxis = 'h' | 'v';
export type OrthogonalSegmentRef = Readonly<{
    edgeIndex: number;
    segIdx: number;
    axis: OrthogonalSegmentAxis;
    a: OrthogonalPathPoint;
    b: OrthogonalPathPoint;
}>;
export type PairedTerminalApproachRepairResult = [
    OrthogonalPathPoint[],
    OrthogonalPathPoint[]
];
/**
 * Separates a target-terminal approach from a strictly crossing interior segment.
 *
 * Paths and refs are supplied in the same two-edge index space. The function is
 * deliberately geometry-only so callers can apply their own obstacle and global
 * quality gates before accepting the candidate.
 */
export declare const repairPairedTerminalApproachStrictCrossing: (paths: readonly [readonly OrthogonalPathPoint[], readonly OrthogonalPathPoint[]], refs: readonly [OrthogonalSegmentRef, OrthogonalSegmentRef]) => PairedTerminalApproachRepairResult | null;
