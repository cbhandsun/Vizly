import type { Edge, Node } from '@xyflow/react';
type DisplayWorkerSourceNode = Node & {
    positionAbsolute?: unknown;
};
type DisplayWorkerProjectedNode = Node & {
    positionAbsolute: {
        x: number;
        y: number;
    };
};
export declare const projectBaseReactFlowDisplayWorkerInput: ({ edges, nodes, }: {
    edges: Edge[];
    nodes: DisplayWorkerSourceNode[];
}) => {
    edges: Edge[];
    nodes: DisplayWorkerProjectedNode[];
};
export {};
