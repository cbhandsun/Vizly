import type { Edge, Node } from '@xyflow/react';
import { type StrictCrossingRepairDiagnostics } from './baseReactFlowDisplayStrictResidualRepair.js';
import { type AtomicEndpointOrderEvaluation } from './baseReactFlowDisplayAtomicTransactionEvaluation.js';
import type { DisplayTerminalValidationSnapshot } from './baseReactFlowTerminalValidation.js';
export { MIN_RENDER_SAFE_ENDPOINT_STUB, countRenderUnsafeEndpointStubs } from './baseReactFlowDisplayEndpointStubMetrics.js';
export declare const commercialClearanceRiskIsGloballyMinimal: (risk: number) => boolean;
export declare const renderSafeEndpointStubRepairUsesGlobalStrictFallback: (edgeCount: number) => boolean;
export declare const repairFinalShortEndpointStubs: <T extends Edge[]>(edges: T, nodes: Node[]) => T;
export declare const repairRenderSafeEndpointStubs: <T extends Edge[]>(edges: T, nodes: Node[], maxEvaluations?: number, endpointOrder?: AtomicEndpointOrderEvaluation, reusableTerminalValidation?: DisplayTerminalValidationSnapshot, strictDiagnostics?: StrictCrossingRepairDiagnostics, allowStrictFallback?: boolean, trunkPolicy?: 'preserve-length' | 'clearance-margin', eligibleEdgeIds?: ReadonlySet<string>) => T;
