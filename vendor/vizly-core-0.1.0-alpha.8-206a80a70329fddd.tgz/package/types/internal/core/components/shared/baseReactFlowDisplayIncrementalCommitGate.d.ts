import type { Edge, Node } from '@xyflow/react';
import type { DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerProtocol.js';
/** Final atomic gate for a topology or geometry-local Worker transaction. */
export declare const baseReactFlowIncrementalDisplayCommitIsSafe: ({ sourceEdges, initialEdges, response, nodes, eligibleEdgeIds, }: {
    sourceEdges: Edge[];
    initialEdges: Edge[];
    response: DisplayEdgesWorkerResponse;
    nodes: Node[];
    eligibleEdgeIds: ReadonlySet<string>;
}) => boolean;
