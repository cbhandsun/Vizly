import type { Node } from '@xyflow/react';
import { type DisplayPoint, type DisplaySegment } from './baseReactFlowDisplayGeometry.js';
export { STRICT_OUTER_LANE_MAX_CANDIDATES, STRICT_OUTER_LANE_MAX_REPAIRED_EDGES, STRICT_OUTER_LANE_MIN_SPAN, STRICT_OUTER_LANE_STUB_LENGTHS, buildDirectionalStrictOuterLaneCandidates, } from './baseReactFlowDisplayOuterLaneCandidates.js';
export { buildStrictObstacleSideBridgeXs, buildStrictObstacleSideBridgeYs, STRICT_OBSTACLE_SIDE_CLEARANCES, } from './baseReactFlowDisplayLanePositions.js';
export type StrictCrossingSegmentLike = {
    a: DisplayPoint;
    b: DisplayPoint;
    axis: 'h' | 'v';
    edgeIndex: number;
    segIdx: number;
};
export declare const STRICT_TERMINAL_ESCAPE_CLEARANCES: number[];
export declare const STRICT_TERMINAL_MAX_CROSSINGS = 6;
export declare const STRICT_TERMINAL_MAX_CANDIDATES = 160;
export declare const buildStrictTerminalEscapeCandidates: (path: DisplayPoint[], segment: StrictCrossingSegmentLike, other: StrictCrossingSegmentLike, otherSegments: DisplaySegment[]) => DisplayPoint[][];
export declare const buildInternalStrictLaneShiftCandidates: (path: DisplayPoint[], segment: {
    axis: 'h' | 'v';
    segIdx: number;
    a: DisplayPoint;
    b: DisplayPoint;
}, other: {
    axis: 'h' | 'v';
    segIdx: number;
    a: DisplayPoint;
    b: DisplayPoint;
}, otherPath: DisplayPoint[] | undefined, nodes: Node[]) => DisplayPoint[][];
export declare const buildStrictCompanionAroundTerminalCandidates: (path: DisplayPoint[], segment: StrictCrossingSegmentLike, terminal: StrictCrossingSegmentLike, nodes: Node[]) => DisplayPoint[][];
