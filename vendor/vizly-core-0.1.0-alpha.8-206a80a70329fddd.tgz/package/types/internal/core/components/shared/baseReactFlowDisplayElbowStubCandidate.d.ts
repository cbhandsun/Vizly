import type { DisplayPoint } from './baseReactFlowDisplayGeometry.js';
/** Extend a short elbow leg without moving either authored endpoint. */
export declare const buildElbowEndpointStubPaths: (path: readonly DisplayPoint[], minimumStub: number) => DisplayPoint[][];
