import type { Edge } from '@xyflow/react';
import type { RoutingPatch } from '../../routing/routingPatch.js';
import type { BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
import type { BaseReactFlowRoutingChangeSet } from './baseReactFlowDisplayRoutingChangeSet.js';
import type { DisplayRoutingWorkerSessionState } from './baseReactFlowDisplayWorkerSession.js';
import type { DisplayEdgesWorkerResolvedIncrementalRouteRequest } from './baseReactFlowDisplayWorkerProtocol.js';
export type BaseReactFlowTopologyIncrementalRouteAttempt = Readonly<{
    edges: Edge[] | null;
    affectedEdgeCount: number;
    eligibleEdgeIds: string[];
    hardReport?: BaseDisplayBoundedCandidateReport;
}>;
export declare const createBaseReactFlowTopologyIncrementalRoute: ({ request, baselineEdges, baselinePatches, changeSet, exactNextSession, onRejectedReport, }: {
    request: DisplayEdgesWorkerResolvedIncrementalRouteRequest;
    baselineEdges: Edge[];
    baselinePatches: RoutingPatch[];
    changeSet: BaseReactFlowRoutingChangeSet;
    exactNextSession?: DisplayRoutingWorkerSessionState | null;
    onRejectedReport?: (report: BaseDisplayBoundedCandidateReport) => void;
}) => BaseReactFlowTopologyIncrementalRouteAttempt;
