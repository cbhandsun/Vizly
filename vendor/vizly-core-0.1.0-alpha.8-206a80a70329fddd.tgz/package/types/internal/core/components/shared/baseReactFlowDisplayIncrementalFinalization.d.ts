import type { Edge, Node } from '@xyflow/react';
import type { BaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
import type { DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerProtocol.js';
/**
 * Commits an incremental route that already satisfies the complete final
 * safety audit. A defect returns null so the caller enters the existing
 * endpoint and commercial repair pipeline in the same Worker transaction.
 */
export declare const finalizeAuditedIncrementalDisplayResponse: ({ response, edges, nodes, evaluation, onPhaseTrace, }: Readonly<{
    response: DisplayEdgesWorkerResponse;
    edges: Edge[];
    nodes: Node[];
    evaluation: BaseReactFlowFinalEndpointEvaluation;
    onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void;
}>) => DisplayEdgesWorkerResponse | null;
