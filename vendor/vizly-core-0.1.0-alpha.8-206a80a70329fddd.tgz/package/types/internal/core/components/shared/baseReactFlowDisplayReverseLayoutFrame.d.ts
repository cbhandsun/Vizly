import type { Edge, Node } from '@xyflow/react';
/** A temporary isometric coordinate frame, never a committed layout or identity. */
export declare const createDisplayReverseLayoutFrame: (nodes: Node[], edges: Edge[]) => {
    direction: string;
    nodes: Node[];
    edges: Edge[];
    restoreEdges: (routed: Edge[]) => Edge[] | null;
} | null;
