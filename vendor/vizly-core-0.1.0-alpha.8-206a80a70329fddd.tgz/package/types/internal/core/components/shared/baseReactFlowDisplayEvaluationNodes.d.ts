import type { Node } from '@xyflow/react';
import type { BaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
/** Keeps every node-identity keyed context on the same request snapshot. */
export declare const resolveBaseReactFlowEvaluationNodes: (nodes: Node[], evaluation?: BaseReactFlowFinalEndpointEvaluation) => Node[];
