import React from 'react';
import '@xyflow/react/dist/style.css';
import '../custom-edges/SmartEdgeStyles.css';
import type { BaseReactFlowProps } from './baseReactFlowTypes.js';
/**
 * BaseReactFlow 包装组件（函数级注释）
 * - 提供 ReactFlowProvider 上下文
 * - 智能边由画布 worker 统一布线，不再维护逐边障碍物上下文
 */
declare const BaseReactFlow: React.FC<BaseReactFlowProps>;
export default BaseReactFlow;
