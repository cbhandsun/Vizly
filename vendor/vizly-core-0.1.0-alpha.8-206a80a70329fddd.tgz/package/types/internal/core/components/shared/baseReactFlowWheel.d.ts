import type { ReactFlowInstance } from '@xyflow/react';
export declare const createBaseReactFlowWheelHandler: ({ preventScrolling, minZoom, maxZoom, sensitivity, pane, rfInstance, }: {
    preventScrolling: boolean;
    minZoom: number;
    maxZoom: number;
    sensitivity: number;
    pane: {
        getBoundingClientRect: () => Pick<DOMRect, 'left' | 'top'>;
    };
    rfInstance: Pick<ReactFlowInstance, 'getViewport' | 'setViewport'>;
}) => (ev: Event | Pick<WheelEvent, 'clientX' | 'clientY' | 'deltaY' | 'cancelable' | 'preventDefault' | 'stopPropagation'>) => void;
export declare const bindBaseReactFlowWheelHandler: ({ pane, wheelHandler, onPassiveBindFailure, }: {
    pane: Pick<HTMLElement, 'addEventListener' | 'removeEventListener'>;
    wheelHandler: EventListener;
    onPassiveBindFailure?: (error: unknown) => void;
}) => () => void;
