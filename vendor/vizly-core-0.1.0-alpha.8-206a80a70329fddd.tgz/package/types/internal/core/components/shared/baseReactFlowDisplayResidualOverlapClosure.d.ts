import type { Edge, Node } from '@xyflow/react';
import type { BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
export type BaseReactFlowResidualOverlapClosure<T extends Edge[]> = Readonly<{
    edges: T;
    report: BaseDisplayBoundedCandidateReport;
}>;
/**
 * Closes a final exact related-lane overlap without re-entering the full route
 * search. The overlap repair may move one endpoint lane, so the transaction is
 * committed only after a bounded axis re-anchor and an exact full-graph gate.
 */
export declare const repairBaseReactFlowResidualOverlapAxisClosure: <T extends Edge[]>(edges: T, nodes: Node[], baselineReport: BaseDisplayBoundedCandidateReport) => BaseReactFlowResidualOverlapClosure<T>;
