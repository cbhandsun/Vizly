import type { Edge, Node } from '@xyflow/react';
import { type DisplayPoint, type DisplayRect, type DisplaySegment } from './baseReactFlowDisplayGeometry.js';
export { displayTerminalSideCanSwitch } from './baseReactFlowDisplayTerminalPolicy.js';
/**
 * Replaces a tangential terminal departure with an outward stub while keeping
 * the terminal's existing slot on the declared node side. Reusing that slot is
 * important when the side centre is already occupied by an opposite-flow edge.
 * Candidates splice into an existing parallel segment, so the untouched
 * terminal and the stable remainder of the route stay unchanged.
 */
export declare const buildDeclaredTerminalAxisStubCandidates: (path: DisplayPoint[], role: 'source' | 'target', rect: DisplayRect, side: 'top' | 'bottom' | 'left' | 'right', minStub?: number, maxCandidates?: number) => DisplayPoint[][];
export declare const displayTerminalRoleNeedsDeclaredAxisRepair: (edge: Edge, path: DisplayPoint[], role: 'source' | 'target', rect: DisplayRect) => boolean;
export { withDisplayPortBridge } from './baseReactFlowDisplayTerminalPortBridge.js';
export declare const buildOppositeRoleSharedNodeCandidates: <T extends Edge[]>(edges: T, nodes: Node[], first: DisplaySegment, second: DisplaySegment) => T[];
export declare const buildCrossingCompanionOuterPortVariants: <T extends Edge[]>(edges: T, primary: DisplaySegment, companion: DisplaySegment, nodes: Node[]) => T[];
export declare const buildStrictCrossingCompanionShiftVariants: <T extends Edge[]>(edges: T, primaryEdgeIndex: number) => T[];
