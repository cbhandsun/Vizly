import type { Edge, Node } from '@xyflow/react';
export type NodeRect = {
    x: number;
    y: number;
    width: number;
    height: number;
};
export type AnchorSide = 'left' | 'right' | 'top' | 'bottom';
export declare const isVerticalHandle: (handle?: string | null) => boolean;
export declare const getNodeX: (node: Node | undefined) => number;
export declare const getNodeRect: (node: Node | undefined, nodeById?: Map<string, Node>) => NodeRect | null;
export declare const anchorForHandle: (rect: NodeRect, handle?: string | null) => {
    x: number;
    y: number;
};
export declare const sideForHandle: (handle?: string | null) => AnchorSide | null;
export declare const compactOrthogonalPath: (path: Array<{
    x: number;
    y: number;
}>) => Array<{
    x: number;
    y: number;
}>;
export declare const synthesizeStableFallbackPath: ({ edge, nodeById, allowUnroutedFlowEdge, }: {
    edge: Edge;
    nodeById: Map<string, Node>;
    allowUnroutedFlowEdge?: boolean;
}) => Edge;
export declare const isNearPoint: (a: {
    x: number;
    y: number;
}, b: {
    x: number;
    y: number;
}, tolerance?: number) => boolean;
export declare const hasLockedComputedPath: (edge: Edge) => boolean;
