import type { Edge, Node } from '@xyflow/react';
import type { BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
import { type BaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
import { startDisplayRoutingPhaseTrace, type DisplayRoutingPhaseMetrics, type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
import type { DisplayEdgesWorkerRequest, DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerProtocol.js';
export type DisplayWorkerFinalizationOptions = Readonly<{
    commercialStabilizationPass?: number;
    eligibleEdgeIds?: ReadonlySet<string>;
    initialHardReport?: BaseDisplayBoundedCandidateReport;
    initialHardReportEdges?: ReadonlyArray<DisplayEdgesWorkerRequest['edges'][number]>;
    isLargeGraph: boolean;
    finalEvaluation?: DisplayWorkerFinalEvaluation;
    onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void;
    preferredEdges?: ReadonlyArray<DisplayEdgesWorkerRequest['edges'][number]>;
}>;
export type DisplayWorkerFinalEvaluation = Readonly<{
    repairNodes: Node[];
    evaluation: BaseReactFlowFinalEndpointEvaluation;
    hardQualityIsClean: (edges: readonly Edge[]) => boolean;
}>;
export type TracedDisplayWorkerFinalEvaluation = DisplayWorkerFinalEvaluation & Readonly<{
    withExactHardReport: (response: DisplayEdgesWorkerResponse) => DisplayEdgesWorkerResponse;
}>;
/** Builds one final-evaluation scope and safely seeds exact Worker evidence. */
export declare const createDisplayWorkerFinalEvaluation: ({ nodes, responseEdges, initialHardReport, initialHardReportEdges, eligibleEdgeIds, }: Readonly<{
    nodes: Node[];
    responseEdges: Edge[];
    initialHardReport?: BaseDisplayBoundedCandidateReport;
    initialHardReportEdges?: readonly Edge[];
    eligibleEdgeIds?: ReadonlySet<string>;
}>) => DisplayWorkerFinalEvaluation;
/** Owns final-evaluation tracing so the Worker composition root only orchestrates it. */
export declare const createTracedDisplayWorkerFinalEvaluation: ({ nodes, responseEdges, options, }: Readonly<{
    nodes: Node[];
    responseEdges: Edge[];
    options: DisplayWorkerFinalizationOptions;
}>) => TracedDisplayWorkerFinalEvaluation;
/** Finishes the parent finalizer span against the response that will be committed. */
export declare const finishDisplayWorkerFinalization: (timer: ReturnType<typeof startDisplayRoutingPhaseTrace>, response: DisplayEdgesWorkerResponse, changedEdgeCount?: number, metrics?: DisplayRoutingPhaseMetrics) => DisplayEdgesWorkerResponse;
/** Applies the bounded-repair clearance gate before a repair response can commit. */
export declare const finalizeBoundedDisplayWorkerRepairResponse: (response: DisplayEdgesWorkerResponse, nodes: Node[]) => DisplayEdgesWorkerResponse;
