import type { Edge } from '@xyflow/react';
import { type DisplayPoint } from './baseReactFlowDisplayGeometry.js';
export declare const createNonImprovingStrictCandidateGuard: (baseline: Edge[]) => (path: DisplayPoint[], baselineCount: number, candidateCount: number) => boolean;
export declare const strictCandidateCanImproveFrontier: (strict: number, display: number, bestStrict: number, bestDisplay: number, relaxedStrict: number, relaxedDisplay: number) => boolean;
/** Exact global delta is available only for complete, render-stable orthogonal geometry. */
export declare const createExactStrictCandidateCount: (baseline: Edge[], globalCount: number) => (path: DisplayPoint[], baselineEdgeCount: number, candidateEdgeCount: number) => number | null;
