import type { RoutingCorridorPlan, RoutingTopologyGroup } from './baseReactFlowDisplayRoutingTopologyPlan.js';
export type RoutingCorridorMemberAssignment = Readonly<{
    edgeIndex: number;
    laneIndex: number;
    laneCenter: number;
}>;
export type RoutingCorridorReservation = Readonly<{
    groupIndex: number;
    corridorIndex: number | null;
    status: 'reserved' | 'exhausted';
    laneIndexes: readonly number[];
    memberAssignments: readonly RoutingCorridorMemberAssignment[];
}>;
export type RoutingCorridorReservationPlan = Readonly<{
    reservations: readonly RoutingCorridorReservation[];
    exhaustedGroupIndexes: readonly number[];
}>;
/**
 * Reserves worker-private candidate lanes without changing edge geometry.
 * Groups connected by a dual-role edge form one transaction: every group
 * receives a contiguous block or all provisional lanes are released.
 */
export declare const createDisplayRoutingCorridorReservationPlan: (groups: readonly RoutingTopologyGroup[], corridors: readonly RoutingCorridorPlan[]) => RoutingCorridorReservationPlan;
