import type { Edge, Node } from '@xyflow/react';
import type { RoutingTopologyPlan } from './baseReactFlowDisplayRoutingTopologyPlan.js';
export type RoutingGroupTransactionDiagnostics = {
    accepted?: 'reserved-group' | 'hub-roles';
    memberIndexes?: readonly number[];
    reservedGroupIndexes?: readonly number[];
    evaluationCount?: number;
};
export type RoutingGroupTransactionOptions = Readonly<{
    topologyPlan: RoutingTopologyPlan;
    primaryEdgeIndexes: readonly number[];
    /** Borrow the outer transaction's total budget, including exact final acceptance. */
    consumeEvaluation: () => boolean;
    finalCandidateIsAccepted: (edges: Edge[]) => boolean;
    diagnostics?: RoutingGroupTransactionDiagnostics;
}>;
/**
 * One affected endpoint unit chooses ports, reserved lanes and established
 * trunks together. Proposals are private until both the atomic graph gate and
 * the final report accept them. The caller retains its baseline on exhaustion.
 * Reservations constrain the reserved proposal only: an unavailable reservation
 * never makes an existing safe route invalid or grants a partial lane lease.
 */
export declare const repairDisplayRoutingGroupTransaction: <T extends Edge[]>(baseline: T, seed: T, nodes: Node[], options: RoutingGroupTransactionOptions) => T;
