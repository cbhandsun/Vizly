import type { Edge, Node } from '@xyflow/react';
type TerminalRole = 'source' | 'target';
type TerminalSide = 'top' | 'right' | 'bottom' | 'left';
type RoleSlideTerminal = Readonly<{
    edgeIndex: number;
    role: TerminalRole;
}>;
export type DisplayEndpointRoleSlideGroup = Readonly<{
    nodeId: string;
    side: TerminalSide;
    edgeIds: readonly string[];
    terminals: readonly RoleSlideTerminal[];
}>;
/** Complete same-side source/target units; one frozen terminal freezes its whole unit. */
export declare const collectDisplayEndpointRoleSlideGroups: (edges: readonly Edge[], nodes: readonly Node[], eligibleEdgeIds?: ReadonlySet<string>) => DisplayEndpointRoleSlideGroup[];
/**
 * Slide every role by one tangent delta, retaining port order, spacing, handle
 * identity and the remote endpoints. The caller owns group budgets and exact
 * whole-graph acceptance; a useful partial slide is never returned.
 */
export declare const buildDisplayEndpointRoleSlideCandidates: <T extends Edge[]>(edges: T, nodes: readonly Node[], group: DisplayEndpointRoleSlideGroup) => T[];
export {};
