import type { Node, XYPosition } from '@xyflow/react';
export type FastPoint = {
    x: number;
    y: number;
};
export type FastRect = {
    id: string;
    x: number;
    y: number;
    width: number;
    height: number;
};
export type DisplayNode = Node & {
    positionAbsolute?: XYPosition;
    measured?: {
        width?: number;
        height?: number;
    };
};
export declare const finiteNumber: (value: unknown, fallback?: number) => number;
export declare const asRecord: (value: unknown) => Record<string, unknown>;
