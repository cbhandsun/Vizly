import { type BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
import type { DisplayEdgesWorkerRequest, DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerProtocol.js';
export declare const getExactDisplayHardReport: (edges: NonNullable<DisplayEdgesWorkerResponse['edges']>, repairNodes: DisplayEdgesWorkerRequest['nodes']) => BaseDisplayBoundedCandidateReport;
export declare const withExactDisplayHardReport: (response: DisplayEdgesWorkerResponse, repairNodes: DisplayEdgesWorkerRequest['nodes']) => DisplayEdgesWorkerResponse;
/** Finalizes a Worker-owned incremental route only when locking changes no gate input. */
export declare const finalizeStableIncrementalDisplayResponse: (response: DisplayEdgesWorkerResponse, stableEdges: NonNullable<DisplayEdgesWorkerResponse['edges']>, repairNodes: DisplayEdgesWorkerRequest['nodes'], hardReport: BaseDisplayBoundedCandidateReport) => DisplayEdgesWorkerResponse | null;
