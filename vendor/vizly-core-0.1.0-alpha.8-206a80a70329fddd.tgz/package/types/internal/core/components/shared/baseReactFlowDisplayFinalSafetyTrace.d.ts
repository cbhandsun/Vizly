import type { Edge } from '@xyflow/react';
import { type BaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
import { type DisplayRoutingPhaseName, type DisplayRoutingPhaseResolution, type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
export type BaseReactFlowFinalSafetyTraceOptions = Readonly<{
    evaluation?: BaseReactFlowFinalEndpointEvaluation;
    onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void;
    traceParentPhase?: Extract<DisplayRoutingPhaseName, 'final-safety-closure' | 'final-commercial-safety-closure'>;
}>;
export type BaseReactFlowFinalSafetyRepairPhase = Extract<DisplayRoutingPhaseName, 'final-safety-repair-baseline' | 'final-safety-repair-clearance' | 'final-safety-repair-hard' | 'final-safety-repair-trunks' | 'final-safety-repair-bundles' | 'final-safety-repair-corridors' | 'final-safety-repair-skirts' | 'final-safety-repair-strict' | 'final-safety-repair-micro' | 'final-safety-repair-stubs' | 'final-safety-repair-order' | 'final-safety-repair-order-hard' | 'final-safety-repair-order-strict' | 'final-safety-repair-order-finish' | 'final-safety-repair-terminal'>;
export declare const startBaseReactFlowFinalSafetyRepairStage: (baseline: readonly Edge[], options: BaseReactFlowFinalSafetyTraceOptions, phase: BaseReactFlowFinalSafetyRepairPhase) => {
    finish: (resolution: DisplayRoutingPhaseResolution, candidateCount: number, candidate?: readonly Edge[]) => void;
};
