import type { Edge, Node } from '@xyflow/react';
export declare const buildPerpendicularSharedTargetTrunkCandidates: (edges: Edge[], nodes: Node[], eligibleEdgeIds?: ReadonlySet<string>) => Edge[][];
export declare const buildForwardReverseOuterPairCandidates: (edges: Edge[], nodes: Node[], eligibleEdgeIds?: ReadonlySet<string>) => Edge[][];
/**
 * Rebuilds an upward many-to-one passage as a dual-trunk transaction: the
 * nearest incoming edge retains/reuses its top source trunk, remote incoming
 * edges use one outside corridor, and all members share the final bottom-side
 * target trunk. This is the bounded mirror of the perpendicular target bundle
 * above and is only emitted for an audited reverse-passage defect.
 */
export declare const buildReversePassageTargetTrunkCandidates: (edges: Edge[], nodes: Node[], eligibleEdgeIds?: ReadonlySet<string>) => Edge[][];
