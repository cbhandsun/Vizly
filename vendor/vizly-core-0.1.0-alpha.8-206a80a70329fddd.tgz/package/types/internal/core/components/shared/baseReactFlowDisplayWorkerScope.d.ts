import type { DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerProtocol.js';
export interface DisplayEdgesWorkerScope {
    postMessage: (response: DisplayEdgesWorkerResponse) => void;
    onmessage: ((event: MessageEvent<unknown>) => void) | null;
}
export declare const displayEdgesWorkerScope: DisplayEdgesWorkerScope | null;
export declare const postDisplayEdgesResponse: (response: DisplayEdgesWorkerResponse, scope?: DisplayEdgesWorkerScope | null) => void;
export declare const createDisplayEdgesTransportResponse: (response: DisplayEdgesWorkerResponse, incrementalSourceEdges?: import('@xyflow/react').Edge[]) => DisplayEdgesWorkerResponse;
export declare const postTimedDisplayEdgesResponse: (response: DisplayEdgesWorkerResponse, startedAt: number, incrementalSourceEdges?: import('@xyflow/react').Edge[], readyAt?: number, scope?: DisplayEdgesWorkerScope | null) => void;
