import type { Edge, Node } from '@xyflow/react';
/** A bounded two-edge transaction for a visual-clearance route blocked by a peer. */
export declare const repairJointVisualBusinessNodeClearance: (edges: Edge[], nodes: Node[], eligibleEdgeIds: ReadonlySet<string>, acceptsTopology: (candidate: Edge[]) => boolean) => Edge[];
