import type { Edge, Node } from '@xyflow/react';
export type BaseReactFlowRoutingChangeReason = 'node-drag' | 'node-resize' | 'node-add' | 'node-remove' | 'edge-add' | 'edge-remove' | 'port-policy' | 'container-change' | 'layout' | 'unknown';
export type BaseReactFlowRoutingChangeSet = Readonly<{
    reason: BaseReactFlowRoutingChangeReason;
    classification: 'none' | 'style-only' | 'geometry' | 'topology';
    changedNodeIds: string[];
    changedEdgeIds: string[];
    topologyChanged: boolean;
    geometryChanged: boolean;
}>;
export type BaseReactFlowRoutingAffectedClosure = Readonly<{
    mutableEdgeIds: string[];
    contextEdgeIds: string[];
}>;
export declare const createBaseReactFlowRoutingChangeSet: ({ previousNodes, previousEdges, nextNodes, nextEdges, reasonHint, }: {
    previousNodes: readonly Node[];
    previousEdges: readonly Edge[];
    nextNodes: readonly Node[];
    nextEdges: readonly Edge[];
    reasonHint?: BaseReactFlowRoutingChangeReason;
}) => BaseReactFlowRoutingChangeSet;
/**
 * Incident edges are the only initially mutable edges. Siblings and swept-area
 * paths are frozen context, so broad source/target groups cannot silently turn
 * a six-edge node move into a twelve-edge mutation.
 */
export declare const createBaseReactFlowRoutingAffectedClosure: ({ changeSet, previousNodes, nextNodes, baselineEdges, nextEdges, }: {
    changeSet: BaseReactFlowRoutingChangeSet;
    previousNodes: readonly Node[];
    nextNodes: readonly Node[];
    baselineEdges: readonly Edge[];
    nextEdges: readonly Edge[];
}) => BaseReactFlowRoutingAffectedClosure;
