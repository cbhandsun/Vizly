import type { Edge } from '@xyflow/react';
/** Exact no-op proof for the shared-target repair's own crossing geometry. */
export declare const hasSharedTargetEntryStrictCrossing: (edges: Edge[]) => boolean;
export declare const repairSharedTargetEntryStrictCrossingsIfNeeded: <T extends Edge[]>(edges: T, repair?: (candidate: Edge[]) => Edge[]) => T;
