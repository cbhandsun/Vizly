import type { Edge } from '@xyflow/react';
import { type BaseReactFlowPrecompiledRouteLookupInput } from './baseReactFlowPrecompiledRouteRegistry.js';
export type BaseReactFlowDisplayCandidateResolution = Readonly<{
    candidateEdges: Edge[] | null;
    source: 'document' | 'persistent' | 'precompiled' | 'miss';
}>;
export type BaseReactFlowPrecompiledCandidateLoader = (input: BaseReactFlowPrecompiledRouteLookupInput) => Promise<Edge[] | null>;
export declare const resolveBaseReactFlowPrecompiledCandidateTimeoutMs: (value: number) => number;
/**
 * Resolves external display candidates before a worker job starts. A generated
 * precompiled artifact is tried first so an older document or persistent
 * candidate cannot restore a superseded detour when a versioned artifact exists.
 * Document and persistent data are fallbacks for misses, failures, and bounded
 * timeouts. Every returned candidate is still validated inside the Worker job.
 * Callers must treat `null` as a stale/aborted schedule and must not start a
 * worker for it.
 */
export declare const resolveBaseReactFlowDisplayCandidate: ({ input, documentCandidateEdges, persistentCandidateEdges, signal, isCurrent, allowExternalCandidates, loadPrecompiledCandidate, loadTimeoutMs, }: {
    input: BaseReactFlowPrecompiledRouteLookupInput;
    documentCandidateEdges?: Edge[] | null;
    persistentCandidateEdges: Edge[] | null;
    signal: AbortSignal;
    isCurrent: () => boolean;
    allowExternalCandidates?: boolean;
    loadPrecompiledCandidate?: BaseReactFlowPrecompiledCandidateLoader;
    loadTimeoutMs?: number;
}) => Promise<BaseReactFlowDisplayCandidateResolution | null>;
