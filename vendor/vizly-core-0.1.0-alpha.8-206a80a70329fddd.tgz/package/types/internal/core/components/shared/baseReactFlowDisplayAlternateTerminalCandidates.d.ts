import type { Edge, Node } from '@xyflow/react';
import { type DisplayPoint, type DisplaySegment } from './baseReactFlowDisplayGeometry.js';
import { type DisplayTerminalSide } from './baseReactFlowDisplayTerminalPolicy.js';
export type DisplayAlternateTerminalSideCandidate = Readonly<{
    path: DisplayPoint[];
    side: DisplayTerminalSide;
}>;
export declare const buildDisplayAlternateTerminalSideCandidates: (edges: Edge[], segment: DisplaySegment, other: DisplaySegment, nodes: Node[], maxCandidates?: number) => DisplayAlternateTerminalSideCandidate[];
