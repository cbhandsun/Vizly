import type { Edge, Node } from '@xyflow/react';
type TrunkGroup = Readonly<{
    nodeId: string;
    role: 'source' | 'target';
    side: 'top' | 'right' | 'bottom' | 'left';
    edgeIds: readonly string[];
}>;
/** Proposes a shared port slide; the caller owns whole-graph atomic acceptance. */
export declare const buildEndpointTrunkSlideCandidates: <T extends Edge[]>(edges: T, nodes: Node[], group: TrunkGroup) => T[];
export {};
