import { type GeneratedBaseReactFlowPrecompiledRouteDescriptor } from './generated/baseReactFlowPrecompiledRouteLoaders.js';
export type BaseReactFlowPrecompiledRoutePrefetchRegistry = Readonly<Record<string, GeneratedBaseReactFlowPrecompiledRouteDescriptor>>;
type BaseReactFlowPrecompiledRoutePrefetchCache = Map<string, Promise<boolean>>;
export declare const prefetchBaseReactFlowPrecompiledRouteFromRegistry: (presetId: unknown, registry: BaseReactFlowPrecompiledRoutePrefetchRegistry, cache?: BaseReactFlowPrecompiledRoutePrefetchCache) => Promise<boolean>;
/**
 * Starts downloading a known static route artifact. This does not validate or
 * accept the artifact; the measured-geometry lookup and Worker hard gate remain
 * the only path to a visible route.
 */
export declare const prefetchBaseReactFlowPrecompiledRoute: (presetId: unknown) => Promise<boolean>;
export {};
