import type { MutableRefObject } from 'react';
import type { Edge, Node } from '@xyflow/react';
import { type LayoutCandidateAcceptance, type LayoutRouteProof } from '../../algorithms/layoutCandidateAcceptance.js';
import type { RoutingOnlyDocumentSnapshot } from '../../routing/persistedRoutingCandidate.js';
import { type DocumentSnapshotRoutingOptions } from './baseReactFlowDocumentSnapshotSource.js';
import { type BaseReactFlowDisplayCommittedSnapshotBaseline, type BaseReactFlowDisplaySnapshotCommitOptions } from './baseReactFlowDisplayCommittedSnapshot.js';
export type BaseReactFlowRoutingSessionJobOwner = 'display' | 'layout';
export type BaseReactFlowRoutingSessionJob = Readonly<{
    id: number;
    owner: BaseReactFlowRoutingSessionJobOwner;
    signal: AbortSignal;
}>;
export type BaseReactFlowRoutingSessionCommitResult<T> = Readonly<{
    committed: true;
    value: T;
}> | Readonly<{
    committed: false;
}>;
export type BaseReactFlowRoutingSessionRuntime = Readonly<{
    workerRef: MutableRefObject<Worker | null>;
    beginJob: (owner: BaseReactFlowRoutingSessionJobOwner) => BaseReactFlowRoutingSessionJob;
    isCurrentJob: (job: BaseReactFlowRoutingSessionJob) => boolean;
    finishJob: (job: BaseReactFlowRoutingSessionJob) => boolean;
    cancelJob: (job: BaseReactFlowRoutingSessionJob) => boolean;
    commitJob: <T>(job: BaseReactFlowRoutingSessionJob, commit: () => T) => BaseReactFlowRoutingSessionCommitResult<T>;
    commitDisplaySnapshot: (options: BaseReactFlowDisplaySnapshotCommitOptions) => BaseReactFlowDisplayCommittedSnapshotBaseline | null;
    commitLayoutAcceptance: (acceptance: LayoutCandidateAcceptance, nodes: readonly Node[], route: LayoutRouteProof | null) => boolean;
    readLayoutAcceptance: () => LayoutCandidateAcceptance | null;
    rememberDocumentSnapshot: (baseline: BaseReactFlowDisplayCommittedSnapshotBaseline, options: DocumentSnapshotRoutingOptions) => void;
    createDocumentSnapshot: (nodes: Node[], edges: Edge[]) => RoutingOnlyDocumentSnapshot | null;
    registerWorkerDisposer: (disposer: (workerRef: MutableRefObject<Worker | null>) => void) => void;
    isDisposed: () => boolean;
    dispose: () => void;
}>;
/**
 * Owns the one Worker and one commit epoch for a mounted Canvas. Layout and
 * display routing may prepare work independently, but only the current job can
 * publish geometry. Beginning a new job invalidates and aborts its predecessor.
 */
export declare const createBaseReactFlowRoutingSessionRuntime: () => BaseReactFlowRoutingSessionRuntime;
/** Uses an injected Canvas runtime or owns a local one for standalone canvases. */
export declare const useBaseReactFlowRoutingSessionRuntime: (externalRuntime?: BaseReactFlowRoutingSessionRuntime) => BaseReactFlowRoutingSessionRuntime;
