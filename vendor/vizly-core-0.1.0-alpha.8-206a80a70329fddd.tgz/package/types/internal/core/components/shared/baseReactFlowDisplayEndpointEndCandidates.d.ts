import { extractDisplaySegments, type DisplayPoint } from './baseReactFlowDisplayGeometry.js';
export declare const MIN_DISPLAY_ENDPOINT_STUB = 48;
type DisplaySegment = ReturnType<typeof extractDisplaySegments>[number];
type CandidateAppender = (candidate: DisplayPoint[], priority?: boolean) => void;
export declare const appendEndSideStepCandidates: (path: DisplayPoint[], otherSegments: DisplaySegment[], append: CandidateAppender) => void;
export {};
