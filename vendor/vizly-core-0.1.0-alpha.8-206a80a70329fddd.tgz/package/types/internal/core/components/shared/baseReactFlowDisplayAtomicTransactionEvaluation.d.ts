import type { Edge, Node } from '@xyflow/react';
import { auditFinalSameSideEndpointOrder } from '../../strategies/shared/edgeFinalSameSideEndpointOrderRepair.js';
import { type EdgePathQualityEvaluationContext, type EdgePathQualityEvaluationState, type EdgePathQualityScore } from '../../strategies/shared/edgeStrictCrossingGuard.js';
import { type DisplayObstacleEvaluationContext } from './baseReactFlowDisplayEvaluation.js';
import type { DisplayTerminalValidationSnapshot } from './baseReactFlowTerminalValidation.js';
export type AtomicEndpointOrderEvaluation = (edges: readonly Edge[]) => ReturnType<typeof auditFinalSameSideEndpointOrder>;
/**
 * Shared full-graph gate for bounded multi-edge transactions. Candidate
 * builders only propose geometry; this evaluator owns the atomic invariants so
 * a repair cannot improve one edge by regressing another edge's terminal,
 * obstacle clearance, hard quality, or established source/target trunk.
 */
export declare const createAtomicRouteTransactionEvaluation: <T extends Edge[]>(baselineEdges: T, nodes: Node[], reusable?: Readonly<{
    qualityContext?: EdgePathQualityEvaluationContext;
    obstacleContext?: DisplayObstacleEvaluationContext;
    baselineQuality?: EdgePathQualityScore;
    baselineQualityState?: EdgePathQualityEvaluationState;
    baselineObstacleChangedIndexes?: readonly number[];
    baselineObstacleHits?: number;
    endpointOrder?: AtomicEndpointOrderEvaluation;
    terminalValidation?: DisplayTerminalValidationSnapshot;
    trunkPolicy?: 'preserve-length' | 'clearance-margin';
}>) => {
    baselineQuality: EdgePathQualityScore;
    baselineObstacleHits: number;
    evaluate(candidate: T, changedIndexes: number[], knownQualityState?: EdgePathQualityEvaluationState): {
        quality: EdgePathQualityScore;
        obstacleHits: number;
        terminalsAnchored: boolean;
        trunksPreserved: boolean;
        hardQualityDoesNotRegress: boolean;
        obstacleHitsDoNotRegress: boolean;
    };
};
