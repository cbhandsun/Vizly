import type { Edge, Node } from '@xyflow/react';
import { type DisplayPoint } from './baseReactFlowDisplayGeometry.js';
export { MIN_DISPLAY_ENDPOINT_STUB } from './baseReactFlowDisplayEndpointEndCandidates.js';
export declare const buildSafeEndpointSideStepCandidates: (path: DisplayPoint[], edgeIndex: number, edges: Edge[], nodes: Node[]) => DisplayPoint[][];
/** Keep generator order inside equal groups, but try candidates that do not
 * add strict crossings before spending the bounded full-quality budget. */
export declare const prioritizeNonCrossingEndpointStubCandidates: (candidates: DisplayPoint[][], edgeIndex: number, edges: Edge[]) => DisplayPoint[][];
