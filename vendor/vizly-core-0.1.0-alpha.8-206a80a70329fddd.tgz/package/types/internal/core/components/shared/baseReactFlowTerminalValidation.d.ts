import type { Edge, Node } from '@xyflow/react';
export type DisplayTerminalValidation = {
    attached: boolean;
    anchored: boolean;
    sourceAttached: boolean;
    sourceAnchored: boolean;
    targetAttached: boolean;
    targetAnchored: boolean;
};
export type DisplayTerminalValidationSnapshot = {
    validateEdge: (edge: Edge) => DisplayTerminalValidation;
};
export type DisplayTerminalValidationOptions = {
    allowRenderedFilletTransitions?: boolean;
};
export type DisplayTerminalValidationReport = {
    allAttached: boolean;
    allAnchored: boolean;
    unanchoredEdgeIndexes: number[];
};
export declare const createDisplayTerminalValidationSnapshot: (nodes: Node[], options?: DisplayTerminalValidationOptions) => DisplayTerminalValidationSnapshot;
export declare const displayEdgeTerminalValidationDoesNotRegress: (baseline: Edge, candidate: Edge, snapshot: DisplayTerminalValidationSnapshot) => boolean;
export declare const displayTerminalValidationDoesNotRegress: (baseline: readonly Edge[], candidate: readonly Edge[], snapshot: DisplayTerminalValidationSnapshot) => boolean;
export declare const keepDisplayTerminalValidationNonRegressing: (baseline: Edge[], candidate: Edge[], snapshot: DisplayTerminalValidationSnapshot) => Edge[];
export declare const getDisplayTerminalValidationReport: (edges: readonly Edge[], snapshot: DisplayTerminalValidationSnapshot) => DisplayTerminalValidationReport;
export declare const displayEdgesHaveNodeAnchoredTerminals: (edges: Edge[], nodes: Node[], options?: DisplayTerminalValidationOptions) => boolean;
export declare const displayEdgesHaveNodeAttachedTerminals: (edges: Edge[], nodes: Node[]) => boolean;
export declare const keepNodeAnchoredTerminalCandidates: (candidates: Edge[], baseline: Edge[], nodes: Node[]) => Edge[];
