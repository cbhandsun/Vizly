import type { DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerResponseProtocol.js';
/** Interactive routing is a latency tier, not an alternate quality contract. */
export declare const shouldEscalateInteractiveDisplayRoute: (response: Pick<DisplayEdgesWorkerResponse, 'hardClean'>) => boolean;
