import type { Node } from '@xyflow/react';
/** Returns the same array when nothing needs snapping. Never mutates input. */
export declare const snapBaseReactFlowLayoutNodeSizes: (nodes: Node[]) => Node[];
