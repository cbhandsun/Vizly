import type { Edge, Node } from '@xyflow/react';
/** A crossing cannot host both a source fork and a target merge of a third edge. */
export declare const findDisplayDualTrunkJunctionConflicts: (edges: Edge[]) => {
    edgeIndex: number;
    pointIndex: number;
}[];
/**
 * Give a dual-trunk edge a short exclusive middle passage between its fork and
 * merge. Port coordinates stay fixed; a target trunk can move as a complete
 * group to reserve the required channel. The exact gate
 * preserves both trunk memberships, clearance and render-safe terminal stems.
 */
export declare const repairDisplayDualTrunkJunctions: (edges: Edge[], nodes: Node[], eligibleEdgeIds?: ReadonlySet<string>) => Edge[];
