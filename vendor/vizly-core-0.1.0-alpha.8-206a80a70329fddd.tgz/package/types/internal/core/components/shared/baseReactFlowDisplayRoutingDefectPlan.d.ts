import type { Edge } from '@xyflow/react';
import type { BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
type DisplayRoutingDefectQuality = BaseDisplayBoundedCandidateReport['quality'];
export type RoutingDefectStageName = 'post-render-residual' | 'strict-primary-overlap';
export type RoutingDefectStageDecision = Readonly<{
    stage: RoutingDefectStageName;
    scheduled: boolean;
    defect: 'overlap';
}>;
export type RoutingDefectStagePlan = readonly RoutingDefectStageDecision[];
export type RoutingDefectPlan = Readonly<{
    hardClean: boolean;
    needsObstacleRepair: boolean;
    needsOverlapRepair: boolean;
    needsStrictCrossingRepair: boolean;
    needsTerminalRepair: boolean;
    needsMicroRepair: boolean;
    onlyTerminalAxisDefects: boolean;
    terminalClosureEligible: boolean;
    orderedStages: RoutingDefectStagePlan;
}>;
export declare const displayRoutingDefectStageIsScheduled: (plan: RoutingDefectStagePlan, stage: RoutingDefectStageName) => boolean;
export declare const displayRoutingDefectPlanNeedsStrictPrimaryCrossing: (plan: RoutingDefectPlan) => boolean;
export declare const createDisplayRoutingDefectStagePlan: (quality: DisplayRoutingDefectQuality) => RoutingDefectStagePlan;
export declare const displayRoutingQualityNeedsMicroRepair: (quality: DisplayRoutingDefectQuality) => boolean;
export declare const displayRoutingQualityNeedsTerminalRepair: (quality: DisplayRoutingDefectQuality) => boolean;
export declare const createDisplayRoutingDefectPlan: (report: BaseDisplayBoundedCandidateReport, edges?: Edge[]) => RoutingDefectPlan;
export {};
