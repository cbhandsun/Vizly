import type { Edge, Node } from '@xyflow/react';
import { type BusinessNodeClearanceCandidateValidation } from '../../strategies/shared/edgeBusinessNodeClearanceRepair.js';
import { type NodeClearanceGraphEvaluationContext } from '../../strategies/shared/edgeWaypointCandidateRepair.js';
export interface DisplayBusinessNodeClearanceOptions {
    eligibleEdgeIds?: ReadonlySet<string>;
    allowTransientStrictCrossing?: boolean;
    validateCandidate?: (context: BusinessNodeClearanceCandidateValidation) => boolean;
}
/**
 * A constrained commercial route may be unable to reach the preferred 48px
 * clearance. Keep a 44px fallback so fit-to-view diagrams slightly below 10%
 * retain a visible four-pixel gap after bounded DOM positioning drift.
 */
export declare const MINIMUM_VISUAL_BUSINESS_NODE_CLEARANCE = 44;
export declare const resolveDisplayVisualClearanceFallbackCandidateLimit: (nodes: Node[], violatingEdgeCount: number) => number;
export declare const resolveDisplayVisualBusinessNodeClearance: (nodes: Node[], violatingEdgeCount: number) => number;
export declare const displayBusinessNodeCommercialClearanceViolationEdgeIds: (edges: Edge[], nodes: Node[]) => string[];
export declare const displayBusinessNodeCommercialClearanceIsClean: (edges: Edge[], nodes: Node[]) => boolean;
/** Final response metric; indexed pruning is parity-tested against the full scorer. */
export declare const countDisplayBusinessNodeCommercialClearanceViolations: (edges: Edge[], nodes: Node[]) => number;
export declare const eligibleCommercialClearanceDoesNotRegress: (baselineEdges: Edge[], candidateEdges: Edge[], nodes: Node[], eligibleEdgeIds: ReadonlySet<string> | undefined, evaluation?: NodeClearanceGraphEvaluationContext) => boolean;
export declare const eligibleVisualClearanceIsClean: (edges: Edge[], nodes: Node[], eligibleEdgeIds: ReadonlySet<string> | undefined) => boolean;
export declare const eligibleAdaptiveVisualClearanceIsClean: (edges: Edge[], nodes: Node[], eligibleEdgeIds: ReadonlySet<string> | undefined) => boolean;
/**
 * Preserves the 16px safety floor atomically while opportunistically promoting
 * the same route to the 48px commercial clearance target.
 */
export declare const repairBaseReactFlowDisplayBusinessNodeClearance: (edges: Edge[], nodes: Node[], options?: DisplayBusinessNodeClearanceOptions) => Edge[];
/**
 * Closes only the non-negotiable 16px floor. Commercial promotion is a
 * separate transaction because a graph-wide 48px attempt can legitimately be
 * constrained and must never roll back an otherwise safe minimum detour.
 */
export declare const repairBaseReactFlowMinimumBusinessNodeClearanceFloor: (edges: Edge[], nodes: Node[], options?: DisplayBusinessNodeClearanceOptions) => Edge[];
/**
 * Promotes only the supplied constrained routes to the fit-to-view visual
 * floor. The caller still owns the exact graph-wide transaction gate.
 */
export declare const repairBaseReactFlowMinimumVisualBusinessNodeClearanceFloor: (edges: Edge[], nodes: Node[], options?: DisplayBusinessNodeClearanceOptions) => Edge[];
/** Worker transaction wrapper: a temporary peer crossing must be closed before commit. */
export declare const repairBaseReactFlowMinimumBusinessNodeClearance: (edges: Edge[], nodes: Node[], eligibleEdgeIds?: ReadonlySet<string>, allowTransientStrictCrossing?: boolean) => Edge[];
