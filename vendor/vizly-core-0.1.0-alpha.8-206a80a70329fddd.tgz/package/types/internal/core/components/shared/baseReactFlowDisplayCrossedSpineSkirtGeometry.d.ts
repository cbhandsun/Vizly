import type { DisplayTerminalSide } from './baseReactFlowDisplayTerminalPolicy.js';
import { type DisplayPoint, type DisplaySegment } from './baseReactFlowDisplayGeometry.js';
export declare const OUTER_SKIRT_TERMINAL_STUB = 56;
export declare const crossedSpinePathLength: (path: readonly DisplayPoint[]) => number;
export declare const crossedSpineTerminalStubPoint: (anchor: DisplayPoint, side: DisplayTerminalSide) => DisplayPoint;
export declare const blockerEscapeLanesForCrossedSpine: (spine: DisplaySegment, otherSegments: DisplaySegment[]) => number[];
export declare const crossedSpinePerpendicularBlockers: (spine: DisplaySegment, otherSegments: DisplaySegment[]) => DisplaySegment[];
