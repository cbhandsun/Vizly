import type { Edge } from '@xyflow/react';
import { type BaseReactFlowDisplayCommittedSnapshotBaseline, type BaseReactFlowDisplayCommittedSnapshotHit } from './baseReactFlowDisplayCommittedSnapshot.js';
export type BaseReactFlowDisplayCommittedReuse = Readonly<{
    retainedEntry: BaseReactFlowDisplayCommittedSnapshotBaseline | null;
    reusableEntry: BaseReactFlowDisplayCommittedSnapshotHit | null;
    authorityBaseline: BaseReactFlowDisplayCommittedSnapshotBaseline | null;
    authorityEdges: Edge[];
    outputRouteSignature: string | undefined;
}>;
export declare const resolveBaseReactFlowDisplayCommittedReuse: ({ forceFreshFullRoute, retainedBaseline, committedEntry, inputSignature, inputGeometryDigest, }: {
    forceFreshFullRoute: boolean;
    retainedBaseline: BaseReactFlowDisplayCommittedSnapshotBaseline | null;
    committedEntry: BaseReactFlowDisplayCommittedSnapshotHit | null;
    inputSignature: string;
    inputGeometryDigest: string;
}) => BaseReactFlowDisplayCommittedReuse;
