import type { DisplayPoint } from './baseReactFlowDisplayGeometry.js';
/**
 * Remove aligned interior excursions while retaining both endpoint stubs.
 * Callers remain responsible for exact obstacle and whole-graph validation.
 */
export declare const buildTerminalPreservingInteriorShortcutCandidates: (path: DisplayPoint[], maxCandidates?: number, includeCorners?: boolean) => DisplayPoint[][];
