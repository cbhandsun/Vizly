type BaseReactFlowPerformanceConfig = {
    enableVirtualization: boolean;
    batchSize: number;
    debounceMs: number;
};
export declare const DEFAULT_BASE_REACT_FLOW_PERFORMANCE_CONFIG: BaseReactFlowPerformanceConfig;
export declare const readBaseReactFlowZoomSensitivity: ({ readConfig, onReadFailure, }: {
    readConfig: () => unknown;
    onReadFailure?: (error: unknown) => void;
}) => number;
export declare const detectBaseReactFlowTouchDevice: ({ hasTouchStart, maxTouchPoints, }: {
    hasTouchStart: boolean;
    maxTouchPoints: number;
}) => boolean;
export declare const resolveBaseReactFlowReconnectRadius: (value: number | undefined) => number | undefined;
export declare const resolveBaseReactFlowInteractionFlags: ({ preventScrolling, panOnScroll, panOnDrag, isTouchDevice, isMobileScreen, }: {
    preventScrolling?: boolean;
    panOnScroll: boolean;
    panOnDrag: boolean;
    isTouchDevice: boolean;
    isMobileScreen: boolean;
}) => {
    effectivePreventScrolling: boolean;
    effectivePanOnScroll: boolean;
};
export declare const readBaseReactFlowPerformanceConfig: ({ readConfig, onReadFailure, }: {
    readConfig: () => unknown;
    onReadFailure?: (error: unknown) => void;
}) => BaseReactFlowPerformanceConfig;
export declare const computeBaseReactFlowIsLargeGraph: ({ nodeCount, edgeCount, performanceConfig, }: {
    nodeCount: number;
    edgeCount: number;
    performanceConfig: BaseReactFlowPerformanceConfig;
}) => boolean;
export declare const createBaseReactFlowProOptions: ({ isLargeGraph, }: {
    isLargeGraph: boolean;
}) => {
    onlyRenderVisibleElements: boolean;
    hideAttribution: boolean;
};
export declare const createBaseReactFlowDefaultEdgeOptions: ({ isLargeGraph, }: {
    isLargeGraph: boolean;
}) => {
    type: string;
    markerEnd: {
        type: 'arrowclosed';
        color: string;
        width: number;
        height: number;
    };
    style: {
        stroke: string;
        strokeWidth: number;
        strokeOpacity: number;
        filter: string;
    };
};
export {};
