import type { DisplayEdgesWorkerRepairValidateOrRouteRequest, DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerProtocol.js';
type ComputeWorkerResponse = (request: Exclude<import('./baseReactFlowDisplayWorkerProtocol.js').DisplayEdgesWorkerRequest, DisplayEdgesWorkerRepairValidateOrRouteRequest>) => DisplayEdgesWorkerResponse;
/** Normalize reversed layout jobs; retain the existing repair/validation flow otherwise. */
export declare const runDisplayWorkerLayoutRepairTransaction: (request: DisplayEdgesWorkerRepairValidateOrRouteRequest, compute: ComputeWorkerResponse) => DisplayEdgesWorkerResponse;
export {};
