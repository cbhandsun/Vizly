import type { Edge } from '@xyflow/react';
export declare const readDisplayLayoutDirection: (edge: Edge | undefined) => string;
