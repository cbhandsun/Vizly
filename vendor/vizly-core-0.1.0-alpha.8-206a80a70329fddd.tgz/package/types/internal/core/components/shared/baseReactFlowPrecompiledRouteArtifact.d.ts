import type { Edge } from '@xyflow/react';
import { type RoutingPatch } from '../../routing/routingPatch.js';
import { type BaseReactFlowDisplayEdgesCacheEntry } from './baseReactFlowDisplayCache.js';
export declare const BASE_REACT_FLOW_PRECOMPILED_ROUTE_SCHEMA = "vizly-precompiled-display-route-v1";
export declare const BASE_REACT_FLOW_PRECOMPILED_SOURCE_HASH_PATTERN: RegExp;
export declare const BASE_REACT_FLOW_PRECOMPILED_INPUT_SIGNATURE_PATTERN: RegExp;
export type BaseReactFlowPrecompiledRouteArtifact = {
    schema: typeof BASE_REACT_FLOW_PRECOMPILED_ROUTE_SCHEMA;
    routingVersion: string;
    routingSourceHash: string;
    sourceHash: string;
    inputSignature: string;
    inputGeometryDigest: string;
    outputRouteSignature: string;
    hardClean: true;
    routingContract?: unknown;
    patches: RoutingPatch[];
};
export type BaseReactFlowPrecompiledRouteArtifactExpectation = {
    inputSignature: string;
    inputGeometryDigest: string;
    sourceHash: string;
    routingSourceHash?: string;
    routingVersion?: string;
};
export declare const parseBaseReactFlowPrecompiledRoutePatches: (value: unknown) => RoutingPatch[] | null;
export declare const sanitizeBaseReactFlowPrecompiledRoutePatches: (sourceEdges: Edge[], value: unknown) => RoutingPatch[] | null;
export declare const parseBaseReactFlowPrecompiledRouteArtifact: (value: unknown, expectation: BaseReactFlowPrecompiledRouteArtifactExpectation) => BaseReactFlowDisplayEdgesCacheEntry | null;
