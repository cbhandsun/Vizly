import type { Edge, Node } from '@xyflow/react';
import type { BaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
import type { DisplayEdgesWorkerRequest, DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerProtocol.js';
import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
export declare const canReuseBaseReactFlowFinalCommercialSafety: ({ commercialClosureReady, commercialEvaluationEdges, endpointDefectDelegated, finalEdges, orderedEdges, }: Readonly<{
    commercialClosureReady: boolean;
    commercialEvaluationEdges: readonly Edge[] | null;
    endpointDefectDelegated: boolean;
    finalEdges: readonly Edge[];
    orderedEdges: readonly Edge[];
}>) => boolean;
export declare const closeBaseReactFlowFinalCommercialSafety: <T extends Edge[]>({ canReuseClosure, edges, eligibleEdgeIds, evaluation, nodes, onPhaseTrace, }: Readonly<{
    canReuseClosure: boolean;
    edges: T;
    eligibleEdgeIds?: ReadonlySet<string>;
    evaluation: BaseReactFlowFinalEndpointEvaluation;
    nodes: Node[];
    onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void;
}>) => T;
export declare const commitBaseReactFlowFinalCommercialSafety: ({ closedEdges, eligibleEdgeIds, evaluation, nodes, onPhaseTrace, repairNodes, response, }: Readonly<{
    closedEdges: Edge[];
    eligibleEdgeIds?: ReadonlySet<string>;
    evaluation?: BaseReactFlowFinalEndpointEvaluation;
    nodes: DisplayEdgesWorkerRequest['nodes'];
    onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void;
    repairNodes: Node[];
    response: DisplayEdgesWorkerResponse;
}>) => DisplayEdgesWorkerResponse;
