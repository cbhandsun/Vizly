export declare const logArchitectureNodeMissingData: () => void;
export declare const logUnifiedDesignerUnsupportedAction: (method: 'updateNodesBatch' | 'updateEdgesBatch' | 'takeSnapshot' | 'addNode', pluginId?: string) => void;
export declare const logUnifiedDesignerBatchUpdateUnavailable: (method: 'updateNodesBatch' | 'updateEdgesBatch') => void;
export declare const logUnifiedDesignerInitialDataFallback: (pluginId: string | undefined, error: unknown) => void;
