import type { Edge, Node } from '@xyflow/react';
import type { MutableRefObject } from 'react';
import { type LayoutGeometryConstraints } from '../../algorithms/layoutGeometryConstraints.js';
import { type BaseReactFlowDisplayWorkerResult } from './baseReactFlowDisplayWorkerClient.js';
import type { BaseReactFlowRoutingSessionRuntime } from './baseReactFlowRoutingSessionRuntime.js';
import { type BaseReactFlowPrecompiledRouteLookupInput } from './baseReactFlowPrecompiledRouteRegistry.js';
import type { BaseReactFlowPrecompiledLayoutRegeneration } from './baseReactFlowPrecompiledCaptureMode.js';
export { clearBaseReactFlowLayoutEdgeRoutingData } from './baseReactFlowLayoutEdgeRoutingData.js';
export type BaseReactFlowLayoutRoutingCommit = Readonly<{
    committedSourceEdges: Edge[];
    routedEdges: Edge[];
    commitSnapshot: (runtime: BaseReactFlowRoutingSessionRuntime) => boolean;
}>;
export type BaseReactFlowLayoutPrecompiledCandidateLoader = (input: BaseReactFlowPrecompiledRouteLookupInput) => Promise<Edge[] | null>;
type BaseReactFlowLayoutPrecompiledCapture = BaseReactFlowPrecompiledLayoutRegeneration & Readonly<{
    provenance: 'fresh-layout-repair-validated' | 'fresh-full-route';
}>;
/**
 * A layout strategy owns the next relative positions. Runtime absolute
 * geometry belongs to the previous React Flow render and must not enter the
 * hidden transaction identity or the subsequent state commit.
 */
export declare const clearBaseReactFlowLayoutNodeRuntimeGeometry: (nodes: Node[]) => Node[];
/**
 * The full-quality worker refines an existing orthogonal candidate. Dynamic
 * layouts therefore receive a private, geometry-anchored seed; this candidate
 * is never visible and still has to pass the final hard-quality transaction.
 */
export declare const seedBaseReactFlowStagedLayoutEdges: ({ sourceEdges, sourceNodes, }: {
    sourceEdges: Edge[];
    sourceNodes: Node[];
}) => Edge[];
/**
 * Validates an off-screen route against the exact edge graph that will be
 * committed. Its snapshot is keyed to the target geometry, so React Flow can
 * only reuse it when the rendered geometry is identical.
 */
export declare const commitBaseReactFlowStagedLayoutRoutingResult: ({ sourceEdges, sourceNodes, workerResult, enableSmartEdges, smartEdgePadding, isLargeGraph, retainWorkerSession, precompiledLayoutCapture, layoutConstraints, }: {
    sourceEdges: Edge[];
    sourceNodes: Node[];
    workerResult: BaseReactFlowDisplayWorkerResult;
    enableSmartEdges?: boolean;
    smartEdgePadding?: number;
    isLargeGraph?: boolean;
    /**
     * A bounded layout repair is evaluated from seeded edges. Its receipt proves
     * the canonical identity and final quality, but its Worker-private session
     * still records the seeded graph as the source. Omitting that session keeps
     * incremental routing on the portable canonical snapshot instead.
     */
    retainWorkerSession?: boolean;
    precompiledLayoutCapture?: BaseReactFlowLayoutPrecompiledCapture;
    layoutConstraints?: LayoutGeometryConstraints;
}) => BaseReactFlowLayoutRoutingCommit | null;
/** Routes target layout geometry without mutating the visible graph. */
export declare const stageBaseReactFlowLayoutRouting: ({ workerRef, requestId, sourceEdges, sourceNodes: candidateNodes, enableSmartEdges, smartEdgePadding, isLargeGraph, signal, forceFreshFullRoute, loadPrecompiledCandidate, fullRouteTimeoutMs, precompiledLayoutRegeneration, rejectObstacleDirtyBoundedCandidate, rejectUnanchoredFlatElkCandidate, candidateRepairPolicy, layoutConstraints, }: {
    workerRef: MutableRefObject<Worker | null>;
    requestId: string;
    sourceEdges: Edge[];
    sourceNodes: Node[];
    enableSmartEdges?: boolean;
    smartEdgePadding?: number;
    isLargeGraph: boolean;
    signal?: AbortSignal;
    forceFreshFullRoute?: boolean;
    loadPrecompiledCandidate?: BaseReactFlowLayoutPrecompiledCandidateLoader;
    fullRouteTimeoutMs?: number;
    precompiledLayoutRegeneration?: BaseReactFlowPrecompiledLayoutRegeneration | null;
    rejectObstacleDirtyBoundedCandidate?: boolean;
    rejectUnanchoredFlatElkCandidate?: boolean;
    candidateRepairPolicy?: 'default' | 'skip-exact-clean';
    layoutConstraints?: LayoutGeometryConstraints;
}) => Promise<BaseReactFlowLayoutRoutingCommit>;
