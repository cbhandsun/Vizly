import type { BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
export declare const displayReportOnlyNeedsTerminalAnchoring: (report: BaseDisplayBoundedCandidateReport) => boolean;
export declare const displayReportCanFinishWithAnchoringCluster: (report: BaseDisplayBoundedCandidateReport) => boolean;
