import type { Edge, Node } from '@xyflow/react';
import type { BaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
import { auditBaseReactFlowFinalSafetyClosure } from './baseReactFlowDisplayFinalSafetyAudit.js';
import type { DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerProtocol.js';
import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
export declare const runBaseReactFlowFinalSafetyClosure: <T extends Edge[]>({ edges, eligibleEdgeIds, evaluation, nodes, onPhaseTrace, routeResolution, }: Readonly<{
    edges: T;
    eligibleEdgeIds?: ReadonlySet<string>;
    evaluation: BaseReactFlowFinalEndpointEvaluation;
    nodes: Node[];
    onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void;
    routeResolution: DisplayEdgesWorkerResponse['routeResolution'];
}>) => Readonly<{
    edges: T;
    endpointDefectDelegated: boolean;
    safetyAudit: ReturnType<typeof auditBaseReactFlowFinalSafetyClosure>;
}>;
