import { type SharedNodePortPoint, type SharedNodePortRect, type SharedNodePortSide } from './baseReactFlowSharedNodePortRoleRepair.js';
import type { OuterPortTerminalStubProfile } from './baseReactFlowDisplayOuterPortStubProfiles.js';
type StubInput = number | OuterPortTerminalStubProfile;
export declare const buildOuterFacingPortPathCandidates: (sourceRect: SharedNodePortRect, targetRect: SharedNodePortRect, sourceSide: SharedNodePortSide, targetSide: SharedNodePortSide, stubInput?: StubInput) => SharedNodePortPoint[][];
export declare const buildDiverseFacingPortPathCandidates: (sourceRect: SharedNodePortRect, targetRect: SharedNodePortRect, sourceSide: SharedNodePortSide, targetSide: SharedNodePortSide, stubInput?: StubInput) => SharedNodePortPoint[][];
export {};
