import type { Edge, Node } from '@xyflow/react';
import { type EdgePathQualityScore } from '../../strategies/shared/edgeStrictCrossingGuard.js';
export declare const displayObstacleEdgeSignature: (edge: Edge) => string;
type DisplayHardGateMetrics = {
    signature: string;
    renderNormalizedEdges: Edge[];
    quality: EdgePathQualityScore;
    obstacleHits: number;
    minimumClearanceViolationEdgeIds: string[];
    containerBoundarySkimLength: number;
    containerBoundarySkimEdgeIds: string[];
};
export type DisplayHardGateScanMetrics = Readonly<{
    scannedNodeCount: number;
    scannedEdgePairCount: number;
}>;
export type DisplayHardGateMetricsEvaluation = Readonly<{
    metrics: DisplayHardGateMetrics;
    scanMetrics: DisplayHardGateScanMetrics;
}>;
export declare const getDisplayHardGateMetricsEvaluation: (edges: Edge[], nodes: Node[]) => DisplayHardGateMetricsEvaluation;
export {};
