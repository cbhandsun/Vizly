export type TerminalGeometryPoint = {
    x: number;
    y: number;
};
export type TerminalGeometryRect = {
    x: number;
    y: number;
    width: number;
    height: number;
};
export type TerminalGeometrySide = 'top' | 'bottom' | 'left' | 'right';
/** Infers the terminal side solely from finalized path and node geometry. */
export declare const inferTerminalGeometrySide: (path: TerminalGeometryPoint[], role: 'source' | 'target', rect: TerminalGeometryRect) => TerminalGeometrySide | null;
