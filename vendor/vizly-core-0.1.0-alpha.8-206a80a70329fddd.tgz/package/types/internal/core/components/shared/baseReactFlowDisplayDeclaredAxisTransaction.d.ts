import type { Edge, Node } from '@xyflow/react';
export declare const createDisplayDeclaredAxisMismatchCounter: (nodes: Node[]) => ((edge: Edge) => number);
export declare const rollbackIncompleteDeclaredAxisTransactions: <T extends Edge[]>(baseline: T, candidate: T, countMismatches: (edge: Edge) => number) => T;
