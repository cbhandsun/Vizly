import type { Edge, Node } from '@xyflow/react';
import type { DisplayExactThresholdResidualPair } from './baseReactFlowDisplayParallelOverlapGeometry.js';
/**
 * Builds bounded two-edge transactions for an overlap that cannot be removed
 * by shifting either member independently. Shared-node opposite roles first
 * get a local port-side transaction; unrelated edges get complementary global
 * outer lanes so their branches cannot swap order through the same corridor.
 */
export declare const buildAtomicOverlapCompanionCandidates: <T extends Edge[]>(edges: T, nodes: Node[], pair: DisplayExactThresholdResidualPair) => T[];
