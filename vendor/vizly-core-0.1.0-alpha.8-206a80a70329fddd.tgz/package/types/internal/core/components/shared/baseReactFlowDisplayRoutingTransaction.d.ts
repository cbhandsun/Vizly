import type { Edge } from '@xyflow/react';
import { type RoutingPatch } from '../../routing/routingPatch.js';
import { type BaseReactFlowDisplayEdgesCacheEntry } from './baseReactFlowDisplayCache.js';
export declare const createBaseReactFlowDisplayEdgePatches: (sourceEdges: Edge[], routedEdges: Edge[]) => RoutingPatch[] | null;
export declare const mergeBaseReactFlowDisplayEdgePatches: (sourceEdges: Edge[], patches: RoutingPatch[]) => Edge[] | null;
/**
 * Projects untrusted persistent-cache patches onto geometry-only routing DTOs.
 * Intent flags and tree-bus identity remain owned by the current source graph;
 * cache data can update an existing tree's geometry but cannot create one.
 */
export declare const sanitizeBaseReactFlowDisplayCachePatches: (sourceEdges: Edge[], patches: RoutingPatch[]) => RoutingPatch[] | null;
/**
 * Projects a parsed routing-only document candidate onto the current graph.
 * Unlike the browser cache boundary, a document snapshot may restore bounded
 * router intent because it is still revalidated by the Worker before commit.
 */
export declare const sanitizeBaseReactFlowDocumentCandidatePatches: (sourceEdges: Edge[], patches: RoutingPatch[]) => RoutingPatch[] | null;
/**
 * Internal worker output may carry the router-owned trunk intent and may clear
 * stale optional route carriers. It is still projected through a routing-only
 * schema before being retained across React renders.
 */
export declare const sanitizeBaseReactFlowTrustedDisplayPatches: (sourceEdges: Edge[], patches: RoutingPatch[]) => RoutingPatch[] | null;
export declare const mergeBaseReactFlowDisplayRoutingTransactions: ({ latestSourceEdges, workerRoutingPatches, repairRoutingPatches, }: {
    latestSourceEdges: Edge[];
    workerRoutingPatches: RoutingPatch[];
    repairRoutingPatches?: RoutingPatch[];
}) => {
    edges: Edge[];
    displayPatches: RoutingPatch[];
    cachePatches: RoutingPatch[] | null;
} | null;
/**
 * Proves that routing-only persisted patches replay the exact final route.
 * Sanitization may intentionally drop unauthorized tree/quality intent, so a
 * hard-clean final result is not automatically cacheable.
 */
export declare const resolveBaseReactFlowDisplayCacheReplaySignature: ({ sourceEdges, finalEdges, cachePatches, finalOutputRouteSignature, }: {
    sourceEdges: Edge[];
    finalEdges: Edge[];
    cachePatches: RoutingPatch[];
    finalOutputRouteSignature: string | null;
}) => string | null;
/** Checks routing-owned geometry directly, independently of cache size limits. */
export declare const doBaseReactFlowDisplayRoutesMatchExactly: (workerEdges: readonly Edge[], mergedEdges: readonly Edge[]) => boolean;
/** Returns the exact routing-owned indexes changed by an immutable candidate. */
export declare const getChangedBaseReactFlowDisplayRoutingIndexes: (baseline: readonly Edge[], candidate: readonly Edge[]) => number[];
export declare const mergeTrustedBaseReactFlowDisplayCacheEntry: (sourceEdges: Edge[], cacheEntry: BaseReactFlowDisplayEdgesCacheEntry) => Edge[] | null;
export declare const mergeBaseReactFlowDocumentCandidateEntry: (sourceEdges: Edge[], candidate: BaseReactFlowDisplayEdgesCacheEntry) => Edge[] | null;
