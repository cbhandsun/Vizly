export type DisplayCrossingClusterCandidateBudget = Readonly<{
    maxLocalCandidates: number;
    maxSidePairCandidates: number;
}>;
export declare const DISPLAY_CROSSING_CLUSTER_MAX_EDGES = 24;
/**
 * Keeps ordinary clusters on a cheap ordered sample while preserving the
 * broader search needed by the bounded 17–24-edge multi-trunk closure.
 */
export declare const resolveDisplayCrossingClusterCandidateBudget: (edgeCount: number) => DisplayCrossingClusterCandidateBudget | null;
