import type { Edge } from '@xyflow/react';
import type { BaseReactFlowDisplayEdgesArgs, BaseReactFlowFullRouteSeedResult, BaseReactFlowPreDisplayFinalEdgesFactory } from './baseReactFlowDisplayFullRouteTypes.js';
import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
export declare const selectBaseReactFlowFullRouteSeedEdges: (rawEdges: Edge[], preparedBoundedEdges: Edge[] | null) => Edge[];
export declare const prepareBaseReactFlowFullRouteSeed: ({ edges, nodes, enableSmartEdges, smartEdgePadding, isLargeGraph, displayEdgeEpoch, forceFullQuality, preparedInteractiveEdges, seedUnroutedFlowEdges, reusePreparedGlobalRouting, skipBoundedAttempt, skipFinalizedReuse, onPhaseTrace, onSeedPhaseTrace, createPreDisplayFinalEdges, evaluationSession: providedEvaluationSession, }: BaseReactFlowDisplayEdgesArgs & {
    createPreDisplayFinalEdges?: BaseReactFlowPreDisplayFinalEdgesFactory;
    onSeedPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void;
}) => BaseReactFlowFullRouteSeedResult;
