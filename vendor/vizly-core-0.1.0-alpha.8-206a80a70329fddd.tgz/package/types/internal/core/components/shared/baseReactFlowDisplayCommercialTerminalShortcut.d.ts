import type { Edge, Node } from '@xyflow/react';
/** An alternate source side can make an exterior corridor shorter than an
 * interior staircase. Preserve the old target suffix for shared-trunk checks.
 */
export declare const buildCommercialExteriorSourceShortcutCandidates: (edge: Edge, nodes: Node[]) => Edge[];
/**
 * Negotiates automatic ELK terminal roles before graph topology is locked.
 * Hidden layout candidates can still contain redundant ELK bends, so this
 * variant relies on material savings plus the authoritative Worker gates
 * instead of requiring an already compact four-point rectangle.
 */
export declare const buildLayoutFacingTerminalShortcutCandidates: (edge: Edge, nodes: Node[]) => Edge[];
/**
 * Truncates an already-safe outer corridor at an earlier waypoint and lands on
 * the nearest legal target side. Callers must still apply the graph-wide hard,
 * obstacle, terminal, and true-trunk transaction gates.
 */
export declare const buildCommercialTerminalShortcutCandidates: (edge: Edge, nodes: Node[]) => Edge[];
/**
 * Mirrors the target-side shortcut at the source while preserving the already
 * accepted target corridor. This is important for tree-bus edges: a source
 * detour may be shortened without destroying a true shared target trunk.
 */
export declare const buildCommercialSourceTerminalShortcutCandidates: (edge: Edge, nodes: Node[]) => Edge[];
/**
 * Pulls a four-point same-side outer rectangle toward its endpoints while
 * retaining render-safe terminal stubs. The graph-wide caller remains
 * responsible for obstacle, overlap, crossing, and true-trunk acceptance.
 */
export declare const buildCommercialSameSideRectangularShortcutPaths: (edge: Edge, nodes: Node[], allEdges?: readonly Edge[]) => Array<Array<{
    x: number;
    y: number;
}>>;
/**
 * Collapses a locally stepped clearance skirt onto one of its already proven
 * interior lanes while preserving both terminal stubs. Exact graph and node
 * acceptance remains the caller's responsibility.
 */
export declare const buildCommercialTerminalCorridorShortcutPaths: (path: Array<{
    x: number;
    y: number;
}>, nodes?: Node[], edge?: Edge) => Array<Array<{
    x: number;
    y: number;
}>>;
/** Separates a facing-port shortcut immediately after its legal source stub. */
export declare const buildCommercialBranchedTerminalShortcutCandidates: (edge: Edge) => Edge[];
