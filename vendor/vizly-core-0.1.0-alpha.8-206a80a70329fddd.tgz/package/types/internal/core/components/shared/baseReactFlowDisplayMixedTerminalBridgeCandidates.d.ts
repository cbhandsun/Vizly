import type { Edge, Node } from '@xyflow/react';
import { type DisplayPoint, type DisplaySegment } from './baseReactFlowDisplayGeometry.js';
type VerticalSide = 'top' | 'bottom';
type PortSide = VerticalSide | 'left' | 'right';
type BridgeEdge = (edge: Edge, path: DisplayPoint[], sourceSide: PortSide, targetSide: PortSide) => Edge;
interface BuildMixedTerminalBridgeOptions<T extends Edge[]> {
    edges: T;
    primary: DisplaySegment;
    companion: DisplaySegment;
    nodes: Node[];
    bridgeEdge: BridgeEdge;
}
/**
 * Builds an H-V-H bridge when a horizontal terminal is trapped by a vertical
 * spine. Both terminals move to vertical ports so the horizontal breakouts can
 * pass above or below adjacent spines before the long vertical leg begins.
 */
export declare const buildCrossedHorizontalMixedTerminalBridgeVariants: <T extends Edge[]>(options: BuildMixedTerminalBridgeOptions<T>) => T[];
export {};
