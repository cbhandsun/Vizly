import type { Edge } from '@xyflow/react';
import type { EdgePathQualityScore } from '../../strategies/shared/edgeStrictCrossingGuard.js';
export type DisplayLoopShortcutRepairDiagnostics = {
    candidateEdgeCount: number;
    qualityEvaluationCount: number;
};
export declare const createDisplayLoopShortcutRepairDiagnostics: () => DisplayLoopShortcutRepairDiagnostics;
export declare const hardLoopDefectsDoNotRegress: (baseline: EdgePathQualityScore, candidate: EdgePathQualityScore) => boolean;
export declare const hasCommerciallyExcessiveDetour: (edges: readonly Edge[]) => boolean;
export declare const loopDefectScore: (quality: EdgePathQualityScore, edges: readonly Edge[]) => number;
