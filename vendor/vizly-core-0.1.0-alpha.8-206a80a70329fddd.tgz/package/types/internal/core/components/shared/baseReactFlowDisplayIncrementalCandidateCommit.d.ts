import type { Edge, Node } from '@xyflow/react';
import type { BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
import type { BaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
export type BaseReactFlowDisplayIncrementalRouteOutcome = Readonly<{
    edges: Edge[] | null;
    affectedEdgeCount: number;
    eligibleEdgeIds: string[];
    hardReport?: BaseDisplayBoundedCandidateReport;
}>;
/** Applies the complete incremental commit contract while preferring stable
 * baseline routes for context edges promoted only to make the edit safe. */
export declare const commitBaseReactFlowIncrementalCandidate: ({ candidateEdges, baselineEdges, repairNodes, promotedIds, transactionMutableIds, incidentMutableIds, commercialClearanceRepairIds, rigidEdgeIds, evaluation, minimumClearance, }: Readonly<{
    candidateEdges: Edge[];
    baselineEdges: readonly Edge[];
    repairNodes: Node[];
    promotedIds: ReadonlySet<string>;
    transactionMutableIds: ReadonlySet<string>;
    incidentMutableIds: ReadonlySet<string>;
    commercialClearanceRepairIds: ReadonlySet<string>;
    rigidEdgeIds: ReadonlySet<string>;
    evaluation: BaseReactFlowFinalEndpointEvaluation;
    minimumClearance?: number;
}>) => BaseReactFlowDisplayIncrementalRouteOutcome | null;
