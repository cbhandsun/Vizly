export type BaseReactFlowFitMode = 'fitWidthTop' | 'fitAll' | 'none';
type Size = {
    width: number;
    height: number;
};
type BaseReactFlowFitScheduleInput = {
    fitMode: BaseReactFlowFitMode;
    hasInstance: boolean;
    nodeCount: number;
    fitTriggerKey: string | number | undefined;
    lastFitTriggerKey: string | number | undefined;
    pinFit: boolean;
    hasInitialized: boolean;
    containerSize: Size;
    previousContainer: Size | null;
    defaultDebounceMs: number;
};
type BaseReactFlowFitSchedulePlan = {
    shouldSchedule: false;
    isTriggerKeyChanged: boolean;
} | {
    shouldSchedule: true;
    isTriggerKeyChanged: boolean;
    debounceTime: number;
};
export declare const hasBaseReactFlowSignificantContainerDelta: ({ containerSize, previousContainer, threshold, }: {
    containerSize: Size;
    previousContainer: Size | null;
    threshold?: number;
}) => boolean;
export declare const resolveBaseReactFlowFitDebounceTime: ({ defaultDebounceMs, hasInitialized, isTriggerKeyChanged, }: {
    defaultDebounceMs: number;
    hasInitialized: boolean;
    isTriggerKeyChanged: boolean;
}) => number;
export declare const resolveBaseReactFlowFitSchedule: ({ fitMode, hasInstance, nodeCount, fitTriggerKey, lastFitTriggerKey, pinFit, hasInitialized, containerSize, previousContainer, defaultDebounceMs, }: BaseReactFlowFitScheduleInput) => BaseReactFlowFitSchedulePlan;
export {};
