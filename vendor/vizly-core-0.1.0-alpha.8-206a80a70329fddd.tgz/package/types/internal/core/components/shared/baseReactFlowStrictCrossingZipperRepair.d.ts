export type StrictCrossingZipperPoint = Readonly<{
    x: number;
    y: number;
}>;
export type StrictCrossingZipperAxis = 'h' | 'v';
export type StrictCrossingZipperSegmentRef = Readonly<{
    segmentIndex: number;
    axis: StrictCrossingZipperAxis;
    a: StrictCrossingZipperPoint;
    b: StrictCrossingZipperPoint;
}>;
export type StrictCrossingZipperBlocker = Readonly<{
    path: readonly StrictCrossingZipperPoint[];
    segment: StrictCrossingZipperSegmentRef;
}>;
/**
 * Builds bounded, geometry-only zipper candidates for a strictly crossed
 * internal segment. Every blocker is converted into a 24px forward tap along
 * the target segment's successor direction. The caller remains responsible
 * for obstacle and whole-graph quality acceptance.
 */
export declare const buildStrictCrossingZipperCandidates: (path: readonly StrictCrossingZipperPoint[], target: StrictCrossingZipperSegmentRef, blockers: readonly StrictCrossingZipperBlocker[]) => StrictCrossingZipperPoint[][];
