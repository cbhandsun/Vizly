import type { Edge, Node } from '@xyflow/react';
/** Move a skimming lane and its blocking parallel neighbour as one candidate.
 * Endpoints stay fixed; callers must validate the entire graph before publication.
 */
export declare function pairedDisplayClearanceCandidates(edges: Edge[], nodes: Node[]): Generator<Edge[]>;
