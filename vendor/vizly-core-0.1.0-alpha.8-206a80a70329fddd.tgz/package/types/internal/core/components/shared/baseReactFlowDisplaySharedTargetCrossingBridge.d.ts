import type { Edge, Node } from '@xyflow/react';
import { type DisplaySegment } from './baseReactFlowDisplayGeometry.js';
/**
 * Moves a final horizontal target approach above or below a crossing spine,
 * then joins an existing vertical same-target trunk. This keeps the target
 * port order planar without replacing a real shared target trunk with an
 * unrelated outer detour.
 */
export declare const buildSharedTargetCrossingBridgeCandidates: (edges: Edge[], nodes: Node[], edgeIndex: number, spine: DisplaySegment) => Edge[];
