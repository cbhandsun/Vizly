import type { EdgePathQualityScore } from '../../strategies/shared/edgeStrictCrossingGuard.js';
import { type DisplayPoint, type DisplayRect } from './baseReactFlowDisplayGeometry.js';
export declare const detachedTerminalQualityDoesNotRegress: (baseline: EdgePathQualityScore, candidate: EdgePathQualityScore) => boolean;
export declare const buildApproachSideTerminalCandidate: (path: DisplayPoint[], role: 'source' | 'target', rect: DisplayRect) => {
    path: DisplayPoint[];
    side: 'top' | 'bottom' | 'left' | 'right';
} | null;
