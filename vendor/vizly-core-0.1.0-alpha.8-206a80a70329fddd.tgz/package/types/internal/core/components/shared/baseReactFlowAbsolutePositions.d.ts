import type { Node } from '@xyflow/react';
/** Resolve nested React Flow coordinates without importing the routing engine. */
export declare const withDisplayAbsolutePositions: (nodes: Node[], nodeById: Map<string, Node>) => Node[];
