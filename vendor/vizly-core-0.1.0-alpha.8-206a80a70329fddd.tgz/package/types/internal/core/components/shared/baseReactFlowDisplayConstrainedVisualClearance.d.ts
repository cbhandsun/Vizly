import type { Edge, Node } from '@xyflow/react';
import type { DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerProtocol.js';
export declare const constrainedCommercialClearanceEdgeIds: (edges: readonly Edge[]) => ReadonlySet<string>;
export declare const closeConstrainedVisualBusinessNodeClearance: ({ response, repairNodes, exactReport, lockComputedPaths, endpointTopologyDoesNotRegress, }: Readonly<{
    response: DisplayEdgesWorkerResponse;
    repairNodes: Node[];
    exactReport: (candidate: DisplayEdgesWorkerResponse, repairNodes: Node[]) => DisplayEdgesWorkerResponse;
    lockComputedPaths: (edges: Edge[]) => Edge[];
    endpointTopologyDoesNotRegress: (before: Edge[], after: Edge[], nodes: Node[]) => boolean;
}>) => DisplayEdgesWorkerResponse;
