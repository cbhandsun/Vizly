import type { Edge, Node } from '@xyflow/react';
import { type SameSideEndpointTrunkIdentity } from '../../strategies/shared/edgeFinalSameSideEndpointOrderRepair.js';
import type { BaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
export type BaseReactFlowFinalSafetyCandidateOptions = Readonly<{
    eligibleEdgeIds?: ReadonlySet<string>;
    evaluation?: BaseReactFlowFinalEndpointEvaluation;
}>;
export declare const sameFinalSafetyEdgeReferences: (first: readonly Edge[], second: readonly Edge[]) => boolean;
export declare const finalSafetyPreservesInitialTrueTrunks: (initial: readonly SameSideEndpointTrunkIdentity[], next: readonly SameSideEndpointTrunkIdentity[]) => boolean;
export declare const finalSafetyCandidateIsAccepted: (baseline: readonly Edge[], candidate: Edge[], nodes: Node[], options: BaseReactFlowFinalSafetyCandidateOptions, getInitialTrueTrunks: () => readonly SameSideEndpointTrunkIdentity[]) => boolean;
