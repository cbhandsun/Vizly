import type { Edge, Node } from '@xyflow/react';
import { type DisplayRoutingPhaseName, type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
type GlobalRefinePhase = Extract<DisplayRoutingPhaseName, 'quality-crossing-global-refine-initial' | 'quality-crossing-global-refine-fixed-point' | 'quality-crossing-global-refine-dogleg' | 'quality-crossing-final-candidates-global' | 'quality-crossing-final-candidates-post-shared' | 'quality-crossing-final-candidates-post-lane'>;
export type DisplayQualityGlobalRefineSession = Readonly<{
    run: (args: Readonly<{
        edges: Edge[];
        mutableEdgeIndexes?: readonly number[];
        normalize?: boolean;
        phase: GlobalRefinePhase;
    }>) => Edge[];
}>;
export declare const createDisplayQualityGlobalRefineSession: ({ nodes, onPhaseTrace, }: {
    nodes: Node[];
    onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void;
}) => DisplayQualityGlobalRefineSession;
export {};
