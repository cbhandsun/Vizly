import type { Edge, Node } from '@xyflow/react';
export declare const repairBoundedPortAndInternalStrictCrossings: <T extends Edge[]>(edges: T, nodes: Node[], maxQualityEvaluations?: number) => T;
