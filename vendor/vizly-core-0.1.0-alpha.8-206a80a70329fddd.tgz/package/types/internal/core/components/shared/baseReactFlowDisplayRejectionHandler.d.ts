import { type BaseReactFlowDisplayFailure, type BaseReactFlowDisplayFailureReason } from './baseReactFlowDisplayFailure.js';
import type { BaseReactFlowRoutingSessionJob, BaseReactFlowRoutingSessionRuntime } from './baseReactFlowRoutingSessionRuntime.js';
type RejectionRequest = Readonly<{
    job: BaseReactFlowRoutingSessionJob | null;
    input: Readonly<{
        cacheSignature: string;
        inputGeometryDigest: string;
    }> | null;
}>;
/** Settles only the current request, keeping terminal state and feedback together. */
export declare const createDisplayRoutingRejectionHandler: ({ runtime, inputSignature, inputGeometryDigest, readRequest, setFailure, onFallbackResolved, }: Readonly<{
    runtime: BaseReactFlowRoutingSessionRuntime;
    inputSignature: string;
    inputGeometryDigest: string;
    readRequest: () => RejectionRequest | null;
    setFailure: (failure: BaseReactFlowDisplayFailure) => void;
    onFallbackResolved?: () => void;
}>) => (reason: BaseReactFlowDisplayFailureReason, error?: unknown) => void;
export {};
