import type { Edge } from "@xyflow/react";
import type { BaseReactFlowPreDisplayFinalEdgesArgs } from './baseReactFlowDisplayFullRouteTypes.js';
export declare const createBaseReactFlowPreDisplayFinalEdges: (args: BaseReactFlowPreDisplayFinalEdgesArgs) => Edge[];
