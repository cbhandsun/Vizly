import type { Edge, Node } from '@xyflow/react';
/**
 * Builds endpoint-local trunk candidates before the full two-ended synthesis.
 *
 * Keeping source and target transactions independent prevents a useful trunk
 * from being rejected when the opposite endpoint is quantized by a fraction of
 * a pixel. The caller owns the exact hard gate and true-trunk preservation.
 */
export declare const buildSharedEndpointTrunkSynthesisCandidates: (baseline: Edge[], nodes: Node[]) => Edge[][];
