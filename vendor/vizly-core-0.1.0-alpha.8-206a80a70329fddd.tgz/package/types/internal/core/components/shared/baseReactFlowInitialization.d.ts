import type { MutableRefObject } from 'react';
import type { Node } from '@xyflow/react';
export declare const computeBaseReactFlowNodeStructureSignature: (nodes: Node[]) => string;
export declare const shouldResetBaseReactFlowInitialization: ({ currentSignature, previousSignature, nodeCount, }: {
    currentSignature: string;
    previousSignature: string;
    nodeCount: number;
}) => boolean;
export declare const scheduleBaseReactFlowInitializationReset: <TBBox, TContainer>({ setHasInitialized, prevBBoxRef, prevContainerRef, cooldownUntilRef, lastZoomRef, initAtRef, now, }: {
    setHasInitialized: (value: boolean) => void;
    prevBBoxRef: MutableRefObject<TBBox | null>;
    prevContainerRef: MutableRefObject<TContainer | null>;
    cooldownUntilRef: MutableRefObject<number>;
    lastZoomRef: MutableRefObject<number | null>;
    initAtRef: MutableRefObject<number>;
    now?: number;
}) => ReturnType<typeof setTimeout>;
