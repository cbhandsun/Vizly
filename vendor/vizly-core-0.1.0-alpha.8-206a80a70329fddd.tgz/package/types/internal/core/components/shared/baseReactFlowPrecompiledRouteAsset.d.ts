type RouteArtifactFetch = (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;
/** Loads a generated route as bounded same-origin data rather than executable JS. */
export declare const loadBaseReactFlowPrecompiledRouteAsset: (url: URL, fetchRouteArtifact?: RouteArtifactFetch) => Promise<unknown>;
export {};
