import type { Edge, Node } from '@xyflow/react';
import { type LayoutCandidateAcceptance } from '../../algorithms/layoutCandidateAcceptance.js';
import { type RoutingOnlyDocumentSnapshot } from '../../routing/persistedRoutingCandidate.js';
import type { RoutingPatch } from '../../routing/routingPatch.js';
import type { BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
import { type DisplayRoutingHardReportDigest, type RoutingHardReport } from './baseReactFlowDisplayHardReportDigest.js';
import { type RoutingWorkerSessionRef, type RoutingIdentity } from './baseReactFlowDisplayRoutingSession.js';
import { type BaseReactFlowPrecompiledLayoutRegeneration } from './baseReactFlowPrecompiledCaptureMode.js';
type CommittedHardReportIdentity = Readonly<{
    hardReport: BaseDisplayBoundedCandidateReport;
    hardReportDigest?: never;
}> | Readonly<{
    hardReport?: never;
    hardReportDigest: DisplayRoutingHardReportDigest;
}>;
export type RoutingCommittedSnapshot = Readonly<{
    identity: RoutingIdentity;
    projectedSourceGeometry: Readonly<{
        nodes: Node[];
        edges: Edge[];
    }>;
    routingPatches: RoutingPatch[];
    outputRouteSignature: string;
    hardReportDigest: DisplayRoutingHardReportDigest;
    hardReport?: RoutingHardReport;
    workerSessionRef?: RoutingWorkerSessionRef;
    layoutAcceptance?: LayoutCandidateAcceptance;
}>;
/** Transitional aliases keep existing incremental callers source-compatible. */
export type BaseReactFlowDisplayCommittedSnapshotBaseline = RoutingCommittedSnapshot & Readonly<{
    inputSignature: string;
    inputGeometryDigest: string;
    nodes: Node[];
    sourceEdges: Edge[];
    displayPatches: RoutingPatch[];
    outputRouteSignature: string;
    workerSessionRef?: RoutingWorkerSessionRef;
}>;
export type BaseReactFlowDisplayCommittedSnapshotHit = Readonly<{
    edges: Edge[];
    outputRouteSignature: string;
    baseline: BaseReactFlowDisplayCommittedSnapshotBaseline;
    trustedTransactionHandoff: boolean;
}>;
export declare const doesBaseReactFlowDisplayCommittedBaselineMatchIdentity: (baseline: BaseReactFlowDisplayCommittedSnapshotBaseline | null, inputSignature: string, inputGeometryDigest: string) => baseline is BaseReactFlowDisplayCommittedSnapshotBaseline;
/**
 * A historical L0 entry may bootstrap a canvas or serve the identity that is
 * already active. It must not replace a different active baseline during an
 * edit transition: that would turn undoing a topology edit into an unobserved
 * cache replay and skip the required atomic Worker transaction.
 */
export declare const canReuseBaseReactFlowDisplayCommittedSnapshot: (activeBaseline: BaseReactFlowDisplayCommittedSnapshotBaseline | null, candidate: BaseReactFlowDisplayCommittedSnapshotHit | null, inputSignature: string, inputGeometryDigest: string) => candidate is BaseReactFlowDisplayCommittedSnapshotHit;
export declare const readBaseReactFlowDisplayCommittedSnapshot: ({ inputSignature, inputGeometryDigest, sourceEdges, }: {
    inputSignature: string;
    inputGeometryDigest: string;
    sourceEdges: Edge[];
}) => BaseReactFlowDisplayCommittedSnapshotHit | null;
/** Realm-local proof that a baseline came from the committed snapshot store. */
export declare const isBaseReactFlowDisplayCommittedSnapshotBaselineTrusted: (value: unknown) => value is BaseReactFlowDisplayCommittedSnapshotBaseline;
/** Marks only the exact edge array produced by an active staged layout transaction. */
export declare const markBaseReactFlowStagedLayoutSnapshotHandoff: (sourceEdges: Edge[]) => boolean;
/** Consumes the short-lived layout handoff after Canvas adopts its snapshot. */
export declare const consumeBaseReactFlowStagedLayoutSnapshotHandoff: (candidate: BaseReactFlowDisplayCommittedSnapshotHit) => void;
export type BaseReactFlowDisplaySnapshotCommitOptions = {
    inputSignature: string;
    inputGeometryDigest: string;
    sourceEdges: Edge[];
    sourceNodes: Node[];
    displayPatches: RoutingPatch[];
    outputRouteSignature: string | null;
    workerSessionRef?: RoutingWorkerSessionRef;
    precompiledCapturePresetId?: string | null;
    layoutAcceptance?: LayoutCandidateAcceptance;
    precompiledLayoutCapture?: BaseReactFlowPrecompiledLayoutRegeneration & Readonly<{
        provenance: 'fresh-layout-repair-validated' | 'fresh-full-route';
    }>;
} & CommittedHardReportIdentity;
/** Internal mutation primitive; production callers commit through the Canvas runtime. */
export declare const commitBaseReactFlowDisplaySnapshot: (options: BaseReactFlowDisplaySnapshotCommitOptions) => BaseReactFlowDisplayCommittedSnapshotBaseline | null;
export declare const clearBaseReactFlowDisplayCommittedSnapshots: () => void;
/**
 * Creates a portable routing-only snapshot only from geometry that Canvas has
 * atomically committed for this exact source-edge collection. Display paint,
 * marker, label, selection, and business metadata are never serialized here.
 */
export declare const createBaseReactFlowRoutingOnlyDocumentSnapshot: (sourceEdges: Edge[]) => RoutingOnlyDocumentSnapshot | null;
export {};
