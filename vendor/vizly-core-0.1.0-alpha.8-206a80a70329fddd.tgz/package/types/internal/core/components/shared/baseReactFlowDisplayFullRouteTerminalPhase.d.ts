import type { Edge } from '@xyflow/react';
import { type OuterPortEvaluationBudget } from './baseReactFlowDisplayOuterPortTransaction.js';
import type { BaseReactFlowFullRouteContext } from './baseReactFlowDisplayFullRouteTypes.js';
export declare const runBaseReactFlowFullRouteTerminalPhase: (context: BaseReactFlowFullRouteContext, strictCandidate: Edge[], evaluationBudget?: OuterPortEvaluationBudget) => Edge[];
