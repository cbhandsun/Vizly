export declare const readBaseReactFlowFitRatio: ({ search, readConfig, onReadFailure, }: {
    search: string;
    readConfig: () => unknown;
    onReadFailure?: (error: unknown) => void;
}) => number;
export declare const readBaseReactFlowMaxFitZoom: ({ readConfig, onReadFailure, }: {
    readConfig: () => unknown;
    onReadFailure?: (error: unknown) => void;
}) => number;
