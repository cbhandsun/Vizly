import type { Edge } from '@xyflow/react';
type DisplayDiagnosticsWindow = {
    __vizlyDisplayRoutingDiagnosticsEnabled?: unknown;
};
export type DisplayRoutingPairDiagnostic = {
    first: Edge;
    second: Edge;
    overlap: number;
};
export type DisplayRoutingPairDiagnosticReport = {
    pairs: DisplayRoutingPairDiagnostic[];
    evaluatedPairCount: number;
    truncated: boolean;
};
/** Expensive pair diagnostics are opt-in and compiled out of production. */
export declare const isBaseReactFlowDisplayDiagnosticsEnabled: (windowLike?: DisplayDiagnosticsWindow | undefined) => boolean;
/**
 * Samples pair diagnostics within count and wall-clock budgets. Dense local
 * diagrams therefore cannot turn developer tooling into an unbounded O(E²)
 * main-thread task.
 */
export declare const collectBoundedDisplayRoutingPairDiagnostics: ({ edges, maxEdgeCount, maxPairEvaluations, maxDurationMs, maxReportedPairs, now, }: {
    edges: readonly Edge[];
    maxEdgeCount?: number;
    maxPairEvaluations?: number;
    maxDurationMs?: number;
    maxReportedPairs?: number;
    now?: () => number;
}) => DisplayRoutingPairDiagnosticReport;
export {};
