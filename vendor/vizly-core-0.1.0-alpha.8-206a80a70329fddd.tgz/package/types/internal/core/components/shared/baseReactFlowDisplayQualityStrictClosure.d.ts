import type { Edge, Node } from '@xyflow/react';
import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
export declare const repairDisplayQualityStrictClosure: (finalQualityCandidateEdges: Edge[], repairNodes: Node[], onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void) => Edge[];
