import type { Edge, Node } from '@xyflow/react';
import { type EdgePathQualityEvaluationContext, type EdgePathQualityScore } from '../../strategies/shared/edgeStrictCrossingGuard.js';
export { countDisplayStrictCrossings } from './baseReactFlowDisplayStrictCrossingCount.js';
import { type DisplayHardGateScanMetrics } from './baseReactFlowDisplayHardGateMetrics.js';
export { displayObstacleEdgeSignature } from './baseReactFlowDisplayHardGateMetrics.js';
export type DisplaySoftQualityOptions = {
    maxEdges: number;
    maxCandidatesPerEdge: number;
    maxQualityEvaluations: number;
    skipOuterFallback?: boolean;
    diagnostics?: DisplayObstacleRepairDiagnostics;
};
export type DisplayObstacleRepairDiagnostics = {
    generatedCandidateCount: number;
    scoredCandidateCount: number;
    evaluatedCandidateCount: number;
    quickAcceptedCount: number;
    processedEdgeCount: number;
    initialObstacleHits: number;
    finalObstacleHits: number;
};
export type DisplayQualityBudget = {
    mode: 'full' | 'bounded' | 'fast';
    soft: DisplaySoftQualityOptions;
    finalSoft: DisplaySoftQualityOptions;
};
export type DisplayObstacleEvaluationContext = {
    evaluate: (candidate: Edge[]) => number;
    evaluateChanged: (candidate: Edge[], changedIndexes: readonly number[]) => number;
    /**
     * Exact incremental evaluation for candidates constructed immutably from this
     * context's baseline. The caller guarantees that every changed edge index is
     * listed and that the baseline nodes have not been mutated.
     */
    evaluateKnownChanges: (candidate: Edge[], changedIndexes: readonly number[]) => number;
};
export type BaseDisplayBoundedCandidateReport = {
    candidate: 'terminal-lane' | 'polished';
    hardClean: boolean;
    obstacleHits: number;
    terminalsAttached: boolean;
    terminalsAnchored: boolean;
    quality: EdgePathQualityScore;
    /** Visual-risk diagnostics for unrelated business-node clearance below 16px. */
    minimumClearanceViolations?: number;
    minimumClearanceViolationEdgeIds?: readonly string[];
    /** Final-only commercial contract; internal candidate gates continue to use 16px. */
    commercialClearanceViolations?: number;
    containerBoundarySkims?: number;
    containerBoundarySkimEdgeIds?: readonly string[];
};
export type DisplayTerminalGateEvaluation = {
    terminalsAttached: boolean;
    terminalsAnchored: boolean;
};
export type DisplayTerminalGateEvaluator = (edges: Edge[], nodes: Node[]) => DisplayTerminalGateEvaluation;
export declare const displayHardQualityReportGeometryIsClean: (report: BaseDisplayBoundedCandidateReport) => boolean;
export declare const resolveDisplayQualityBudget: (edges: Edge[], nodes: Node[], isLargeGraph: boolean, forceFullQuality?: boolean) => DisplayQualityBudget;
export declare const finalVisualPolishScoreFromQuality: (score: EdgePathQualityScore) => number;
export declare const visualPolishHardQualityDoesNotRegress: (baseline: EdgePathQualityScore, candidate: EdgePathQualityScore) => boolean;
export declare const visualPolishHardQualityWithoutStrictDoesNotRegress: (baseline: EdgePathQualityScore, candidate: EdgePathQualityScore) => boolean;
export declare const DISPLAY_STRICT_REPAIR_OVERLAP_SLACK = 256;
export declare const displayStrictRepairHardQualityIsAcceptable: (baseline: EdgePathQualityScore, candidate: EdgePathQualityScore) => boolean;
export declare const changedDisplayEdgeIndexesByReference: (baseline: Edge[], candidate: Edge[]) => number[] | null;
export declare const evaluateDisplayQualityCandidate: (context: EdgePathQualityEvaluationContext, baseline: Edge[], candidate: Edge[]) => EdgePathQualityScore;
export declare const uniqueDisplayRoutingCandidates: <T extends Edge[]>(baseline: T, candidates: readonly T[]) => T[];
export declare const chooseFinalVisualPolishCandidate: <T extends Edge[]>(baseline: T, ...candidates: T[]) => T;
export declare const countDisplayObstacleHits: (edges: Edge[], nodes: Node[]) => number;
export declare const keepPerEdgeObstacleNonRegressingCandidates: <T extends Edge[]>(baseline: T, candidate: T, nodes: Node[]) => T;
export declare const changedEdgesObstacleHitsDoNotRegress: (baseline: readonly Edge[], candidate: readonly Edge[], changedIndexes: readonly number[], nodes: Node[]) => boolean;
export type DisplayObstacleEvaluationInitializationMetrics = {
    cacheHit: boolean;
    scannedNodeCount: number;
};
export declare const createDisplayObstacleEvaluationContext: (baseline: Edge[], nodes: Node[], initializationMetrics?: DisplayObstacleEvaluationInitializationMetrics) => DisplayObstacleEvaluationContext;
export declare const evaluateDisplayObstacleCandidate: (context: DisplayObstacleEvaluationContext, baseline: Edge[], candidate: Edge[]) => number;
export declare const obstacleRepairScore: (quality: EdgePathQualityScore, obstacleHits: number) => number;
export declare const obstacleRepairHardQualityIsAcceptable: (baseline: EdgePathQualityScore, candidate: EdgePathQualityScore) => boolean;
export declare const displayHardSafetyIsClean: (edges: Edge[], nodes: Node[]) => boolean;
export declare const getDisplayHardQualityGateReportWithMetrics: (edges: Edge[], nodes: Node[], candidate: BaseDisplayBoundedCandidateReport['candidate'], evaluateTerminals: DisplayTerminalGateEvaluator) => Readonly<{
    report: BaseDisplayBoundedCandidateReport;
    scanMetrics: DisplayHardGateScanMetrics;
}>;
export declare const getDisplayHardQualityGateReport: (edges: Edge[], nodes: Node[], candidate: BaseDisplayBoundedCandidateReport['candidate'], evaluateTerminals: DisplayTerminalGateEvaluator) => BaseDisplayBoundedCandidateReport;
export declare const displayHardQualityGatesAreClean: (edges: Edge[], nodes: Node[], evaluateTerminals: DisplayTerminalGateEvaluator) => boolean;
export declare const chooseFinalObstacleAwarePolishCandidate: <T extends Edge[]>(nodes: Node[], baseline: T, ...candidates: T[]) => T;
export declare const chooseFinalTerminalTransactionCandidate: <T extends Edge[]>(nodes: Node[], baseline: T, ...candidates: T[]) => T;
export declare const chooseDisplayStrictPolishCandidate: <T extends Edge[]>(nodes: Node[], baseline: T, ...candidates: T[]) => T;
export declare const hasHardDisplayOverlapRisk: (quality: EdgePathQualityScore) => boolean;
