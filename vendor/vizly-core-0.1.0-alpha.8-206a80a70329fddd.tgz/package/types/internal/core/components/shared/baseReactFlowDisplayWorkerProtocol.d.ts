import type { Edge, Node } from '@xyflow/react';
import type { RoutingPatch } from '../../routing/routingPatch.js';
import type { BaseReactFlowRoutingChangeSet } from './baseReactFlowDisplayRoutingChangeSet.js';
import { type RoutingIdentity, type RoutingWorkerSessionRef } from './baseReactFlowDisplayRoutingSession.js';
import type { DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerResponseProtocol.js';
import { type DisplayEdgesWorkerRepairRequest, type DisplayEdgesWorkerRepairValidateOrRouteRequest, type DisplayEdgesWorkerValidatedRepairRequest, type DisplayEdgesWorkerValidatedRepairValidateRequest } from './baseReactFlowDisplayWorkerLayoutProtocol.js';
export type { DisplayEdgesWorkerRepairRequest, DisplayEdgesWorkerRepairValidateOrRouteRequest, } from './baseReactFlowDisplayWorkerLayoutProtocol.js';
export type { DisplayEdgesWorkerResponse, DisplayEdgesWorkerRouteResolution, DisplayRoutingFallbackLevel, } from './baseReactFlowDisplayWorkerResponseProtocol.js';
export declare const DISPLAY_WORKER_MAX_GRAPH_ITEMS = 10000;
export declare const DISPLAY_WORKER_MAX_PATH_POINTS = 2000;
export declare const DISPLAY_WORKER_MAX_TOTAL_PATH_POINTS = 200000;
export declare const DISPLAY_WORKER_MAX_COORDINATE_MAGNITUDE = 1000000000;
export declare const OUTPUT_ROUTE_SIGNATURE_PATTERN: RegExp;
export type DisplayQualityMode = 'full' | 'interactive';
export type DisplayEdgesWorkerCandidateSource = 'document' | 'persistent' | 'precompiled';
export type DisplayEdgesWorkerRouteRequest = {
    operation: 'route';
    requestId: string;
    edges: Edge[];
    nodes: Node[];
    enableSmartEdges: boolean;
    smartEdgePadding: number;
    isLargeGraph: boolean;
    displayEdgeEpoch: number;
    qualityMode: DisplayQualityMode;
    inputIdentity?: RoutingIdentity;
};
export type DisplayEdgesWorkerValidateOrRouteRequest = Omit<DisplayEdgesWorkerRouteRequest, 'operation'> & {
    operation: 'validate-or-route';
    /** Legacy full candidate. New clients send routing-only patches instead. */
    candidateEdges?: Edge[] | null;
    /** Null means the routing-only candidate failed protocol validation. */
    candidatePatches?: RoutingPatch[] | null;
    candidateSource: DisplayEdgesWorkerCandidateSource;
};
export type DisplayEdgesWorkerIncrementalRouteRequest = Omit<DisplayEdgesWorkerRouteRequest, 'operation'> & {
    operation: 'incremental-route';
    baselineSessionRef?: RoutingWorkerSessionRef;
    baselineInputSignature: string;
    baselineInputGeometryDigest: string;
    baselineNodes?: Node[];
    baselineSourceEdges?: Edge[];
    baselinePatches?: RoutingPatch[];
    baselineOutputRouteSignature: string;
    nextInputSignature: string;
    nextInputGeometryDigest: string;
    changeSet: BaseReactFlowRoutingChangeSet;
    mutableEdgeIds: string[];
    contextEdgeIds: string[];
};
export type DisplayEdgesWorkerResolvedIncrementalRouteRequest = DisplayEdgesWorkerIncrementalRouteRequest & Required<Pick<DisplayEdgesWorkerIncrementalRouteRequest, 'baselineNodes' | 'baselineSourceEdges' | 'baselinePatches'>>;
export type DisplayEdgesWorkerRequest = DisplayEdgesWorkerRouteRequest | DisplayEdgesWorkerValidateOrRouteRequest | DisplayEdgesWorkerRepairValidateOrRouteRequest | DisplayEdgesWorkerIncrementalRouteRequest | DisplayEdgesWorkerRepairRequest;
/**
 * A request that has crossed the Worker protocol boundary. Pure routing tests
 * may omit identity when they do not publish a session, but production
 * transport only exposes this validated form to the Worker computation.
 */
type DisplayEdgesWorkerValidatedRouteRequest = Omit<DisplayEdgesWorkerRouteRequest, 'inputIdentity'> & {
    inputIdentity: RoutingIdentity;
};
type DisplayEdgesWorkerValidatedValidateRequest = Omit<DisplayEdgesWorkerValidateOrRouteRequest, 'inputIdentity'> & {
    inputIdentity: RoutingIdentity;
};
type DisplayEdgesWorkerValidatedIncrementalRequest = Omit<DisplayEdgesWorkerIncrementalRouteRequest, 'inputIdentity'> & {
    inputIdentity: RoutingIdentity;
};
export type DisplayEdgesWorkerValidatedRequest = DisplayEdgesWorkerValidatedRouteRequest | DisplayEdgesWorkerValidatedValidateRequest | DisplayEdgesWorkerValidatedRepairValidateRequest | DisplayEdgesWorkerValidatedIncrementalRequest | DisplayEdgesWorkerValidatedRepairRequest;
export declare const isRecord: (value: unknown) => value is Record<string, unknown>;
export declare const isDisplayEdgesWorkerEdgeList: (value: unknown) => value is Edge[];
export declare const readDisplayEdgesWorkerRequestId: (value: unknown) => string | null;
/**
 * Treats worker messages as an external boundary. The main thread already
 * projects graph values before posting; this parser rejects malformed roots,
 * oversized graphs, non-finite geometry, and invalid protocol variants before
 * routing code can observe them.
 */
export declare const parseDisplayEdgesWorkerRequest: (value: unknown) => DisplayEdgesWorkerValidatedRequest | null;
export declare const hasFinalDisplayWorkerResponseMetadata: (value: Record<string, unknown>) => boolean;
/** Validates a response before the main thread merges worker-owned geometry. */
export declare const parseDisplayEdgesWorkerResponse: (value: unknown, expectedRequestId: string) => DisplayEdgesWorkerResponse | null;
/**
 * Main-thread commit boundary. Progress, error, and rejected final responses
 * remain parseable, while a hard-clean geometry result must carry the complete
 * current-version receipt issued by the Worker session.
 */
export declare const parseDisplayEdgesWorkerCommitResponse: (value: unknown, expectedRequestId: string) => DisplayEdgesWorkerResponse | null;
