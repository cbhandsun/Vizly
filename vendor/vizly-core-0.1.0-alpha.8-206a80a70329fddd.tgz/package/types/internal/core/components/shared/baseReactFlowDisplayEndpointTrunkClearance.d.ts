import type { Edge, Node } from '@xyflow/react';
export type DisplayEndpointTrunkClearanceOptions = Readonly<{
    eligibleEdgeIds?: ReadonlySet<string>;
    maxGroups?: number;
}>;
/**
 * Builds bounded endpoint-group transactions that reuse an already safe
 * sibling stem. This lets a risky nested pair join an existing larger true
 * trunk without inventing a new lane or moving its anchored terminal.
 */
export declare const buildBaseReactFlowDisplayEndpointTrunkClearanceCandidates: <T extends Edge[]>(edges: T, nodes: Node[], options?: DisplayEndpointTrunkClearanceOptions) => T[];
export declare const repairBaseReactFlowDisplayEndpointTrunkClearance: <T extends Edge[]>(edges: T, nodes: Node[], options?: DisplayEndpointTrunkClearanceOptions) => T;
