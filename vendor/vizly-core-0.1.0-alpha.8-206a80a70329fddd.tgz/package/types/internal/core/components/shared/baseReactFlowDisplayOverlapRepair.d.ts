import type { Edge, Node } from '@xyflow/react';
export { DISPLAY_BOUNDED_DETACHED_OVERLAP_REPAIR_OPTIONS, DISPLAY_BOUNDED_RESIDUAL_OVERLAP_REPAIR_OPTIONS, DISPLAY_DETACHED_OVERLAP_REPAIR_OPTIONS, DISPLAY_EXTENDED_RESIDUAL_OVERLAP_REPAIR_OPTIONS } from './baseReactFlowDisplayOverlapRepairOptions.js';
import { repairExactThresholdResidualOverlaps } from './baseReactFlowDisplayExactOverlapRepair.js';
import { type DisplayRoutingPhaseName, type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
export { repairBoundedReverseParallelOverlapsWithCandidates } from './baseReactFlowDisplayReverseParallelRepair.js';
type DisplayResidualRepairTraceOptions = Readonly<{
    parentPhase: DisplayRoutingPhaseName;
    onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void;
}>;
export declare const repairResidualDisplayOverlaps: <T extends Edge[]>(edges: T, nodes: Node[], options?: {
    maxIterations: number;
    maxHitBudget: number;
    maxQualityEvaluations: number;
    maxResidualPasses: number;
}, extendedOptions?: {
    maxIterations: number;
    maxHitBudget: number;
    maxQualityEvaluations: number;
    maxResidualPasses: number;
    qualityOnly: boolean;
}, traceOptions?: DisplayResidualRepairTraceOptions) => T;
export declare const repairNearParallelResidualOverlaps: <T extends Edge[]>(edges: T, nodes: Node[], maxQualityEvaluations?: number) => T;
export { repairExactThresholdResidualOverlaps };
