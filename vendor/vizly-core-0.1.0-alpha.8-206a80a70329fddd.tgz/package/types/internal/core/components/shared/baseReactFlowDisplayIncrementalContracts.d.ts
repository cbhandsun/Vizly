import type { Edge, Node } from '@xyflow/react';
import type { BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
import type { BaseReactFlowRoutingChangeSet } from './baseReactFlowDisplayRoutingChangeSet.js';
export declare const baseReactFlowIdentifierListsMatch: (first: readonly string[], second: readonly string[]) => boolean;
export declare const baseReactFlowTopologyAffectedEdgeCount: (changedEdgeIds: readonly string[], eligibleEdgeIds: readonly string[]) => number;
export declare const baseReactFlowRoutingChangeSetMatches: (verified: BaseReactFlowRoutingChangeSet, requested: BaseReactFlowRoutingChangeSet) => boolean;
export declare const baseReactFlowReportHasOnlyObstacleDefects: (report: BaseDisplayBoundedCandidateReport) => boolean;
export declare const baseReactFlowReportHasOnlyStrictDefects: (report: BaseDisplayBoundedCandidateReport) => boolean;
export declare const preservesBaseReactFlowIncrementalBoundary: (baselineEdges: readonly Edge[], candidateEdges: readonly Edge[], mutableIds: ReadonlySet<string>) => boolean;
/** Prefer the baseline route for edges promoted only to make an incremental
 * repair transaction safe. A promoted route may still need to change, so the
 * original candidate remains the fallback when restoring the baseline route
 * fails the caller's complete commit validation.
 */
export declare const evaluateBaseReactFlowStablePromotedCandidate: <Result>({ candidateEdges, baselineEdges, promotedIds, evaluateCandidate, }: {
    candidateEdges: Edge[];
    baselineEdges: readonly Edge[];
    promotedIds: ReadonlySet<string>;
    evaluateCandidate: (edges: Edge[], restoredPromotedRoutes: boolean) => Result | null;
}) => Result | null;
/** Lock only the transaction's mutable routes. Frozen precompiled edges may
 * omit runtime lock flags; materializing those flags would replace their
 * identities and invalidate an otherwise legal incremental candidate.
 * Preserve the candidate's frozen entries so boundary checks still detect
 * any unauthorized changes made before this step.
 */
export declare const lockBaseReactFlowIncrementalComputedPaths: (edges: Edge[], nodes: Node[], mutableIds: ReadonlySet<string>) => Edge[];
export declare const repairBaseReactFlowIncrementalClearance: ({ edges, nodes, baselineEdges, mutableIds, clearanceIds, hardReport, }: {
    edges: Edge[];
    nodes: Node[];
    baselineEdges: Edge[];
    mutableIds: ReadonlySet<string>;
    clearanceIds: ReadonlySet<string>;
    hardReport: (edges: Edge[]) => BaseDisplayBoundedCandidateReport;
}) => Edge[];
export declare const baseReactFlowIncrementalEdgesHaveNodeClearance: (edges: readonly Edge[], nodes: Node[], eligibleIds: ReadonlySet<string>, minimumClearance?: number) => boolean;
