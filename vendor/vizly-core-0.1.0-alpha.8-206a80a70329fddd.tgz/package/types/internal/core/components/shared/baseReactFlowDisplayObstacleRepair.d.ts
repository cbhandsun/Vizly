import type { Edge, Node } from '@xyflow/react';
import { type DetachedStrictCrossingRepairDiagnostics } from '../../strategies/shared/edgeDetachedStrictCrossingRepair.js';
import { type DisplayObstacleRepairDiagnostics, type DisplaySoftQualityOptions } from './baseReactFlowDisplayEvaluation.js';
import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
export type ResolvedDisplayObstacleRepairBudget = Readonly<{
    maxEdges: number;
    maxCandidatesPerEdge: number;
    maxQualityEvaluations: number;
}>;
export declare const createDisplayObstacleRepairDiagnostics: () => DisplayObstacleRepairDiagnostics;
/** Keeps explicit bounded latency budgets as caps instead of graph-size floors. */
export declare const resolveDisplayObstacleRepairBudget: (edgeCount: number, nodeCount: number, options: DisplaySoftQualityOptions) => ResolvedDisplayObstacleRepairBudget;
export declare const repairDisplayObstacleHits: <T extends Edge[]>(edges: T, nodes: Node[], layoutDirection: string, options: DisplaySoftQualityOptions) => T;
export declare const repairStrictBypassesIfNeeded: <T extends Edge[]>(edges: T, nodes: Node[], diagnostics?: DetachedStrictCrossingRepairDiagnostics) => T;
export declare const finishDisplaySoftQuality: <T extends Edge[]>(edges: T, repairNodes: Node[], layoutDirection: string, options: DisplaySoftQualityOptions, onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void) => T;
