import type { DisplayGeometryBarrierResolution } from './baseReactFlowDisplayGeometryBarrier.js';
import type { LayoutGeometryReport } from '../../algorithms/layoutGeometryConstraints.js';
import type { DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
import type { BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
import type { LaneRankDecision } from '../../types/domainLaneRank.js';
import type { DisplayEdgesWorkerResponse, DisplayEdgesWorkerRouteResolution, DisplayRoutingFallbackLevel } from './baseReactFlowDisplayWorkerProtocol.js';
import type { BaseReactFlowPrecompiledRouteDiagnostic } from './baseReactFlowPrecompiledRouteRegistry.js';
export type DisplayRoutingPrecompiledRouteDiagnosticSummary = Readonly<{
    totalCount: number;
    hitCount: number;
    missCount: number;
    rejectCount: number;
    reasonCounts: Partial<Record<BaseReactFlowPrecompiledRouteDiagnostic['reason'], number>>;
}>;
export type DisplayRoutingDebugState = {
    stage?: string;
    signature?: string;
    nodeCount?: number;
    edgeCount?: number;
    requestId?: string;
    updatedAt?: number;
    scheduledAt?: number;
    workerStartedAt?: number;
    workerResponseParsedAt?: number;
    finalAppliedAt?: number;
    cacheHitAt?: number;
    routeMs?: number;
    /** User-visible latency from scheduling through final state commit. */
    totalRouteMs?: number;
    workerStartCount?: number;
    workerAbortCount?: number;
    error?: string;
    workerInvalidResponseReason?: string;
    boundedCandidate?: DisplayEdgesWorkerResponse['boundedCandidate'];
    boundedCandidateTrace?: NonNullable<DisplayEdgesWorkerResponse['boundedCandidate']>[];
    inputGeometryDigest?: string;
    outputRouteSignature?: string;
    routingVersion?: string;
    workerResolution?: DisplayEdgesWorkerRouteResolution;
    cacheTrustLevel?: 'runtime-committed' | 'external-candidate' | 'miss';
    precompiledRouteDiagnostic?: BaseReactFlowPrecompiledRouteDiagnostic;
    precompiledRouteDiagnosticTrace?: BaseReactFlowPrecompiledRouteDiagnostic[];
    precompiledRouteDiagnosticSummary?: DisplayRoutingPrecompiledRouteDiagnosticSummary;
    terminalDiagnostics?: unknown;
    phaseTrace?: DisplayRoutingPhaseTrace[];
    lastPhaseTrace?: DisplayRoutingPhaseTrace;
    phaseProgressTrace?: DisplayRoutingPhaseTrace[];
    affectedEdgeCount?: number;
    fallbackLevel?: DisplayRoutingFallbackLevel;
    geometryBarrierResolution?: DisplayGeometryBarrierResolution;
    geometryBarrierMs?: number;
    geometryBarrierSamples?: number;
    hardGateDiagnostics?: BaseDisplayBoundedCandidateReport;
    stagedLayoutPrimarySignature?: string;
    stagedLayoutPrimaryGeometryDigest?: string;
    stagedLayoutSourceSignature?: string;
    stagedLayoutSourceGeometryDigest?: string;
    layoutSeedTerminalsAttached?: boolean;
    layoutGeometryReport?: LayoutGeometryReport;
    layoutSeedTerminalsAnchored?: boolean;
    layoutSeedObstacleHits?: number;
    layoutSeedStrictCrossings?: number;
    layoutSeedStageAudits?: Partial<Record<'raw' | 'anchored' | 'detached-fallback' | 'axis-repaired' | 'geometry-normalized' | 'final', Readonly<{
        terminalsAttached: boolean;
        terminalsAnchored: boolean;
        obstacleHits: number;
        strictCrossings: number;
    }>>>;
    incrementalBaselineSignature?: string;
    incrementalPlanStatus?: 'ready' | 'missing-baseline' | 'rejected';
    renderAuthorityStatus?: BaseReactFlowRenderAuthorityStatus;
    renderAuthorityIssue?: BaseReactFlowRenderAuthorityIssue;
    layoutTransactionJobId?: number;
    layoutTransactionStatus?: DisplayLayoutTransactionStatus;
    layoutTransactionAttemptCount?: number;
    layoutTransactionErrorCode?: DisplayLayoutTransactionErrorCode;
    layoutPhaseTrace?: DisplayLayoutPhaseTrace[];
    laneRankDecision?: LaneRankDecision;
};
export declare const resolveDisplayRoutingCacheTrustLevel: ({ candidateSource, incremental, }: Readonly<{
    candidateSource: 'precompiled' | 'document' | 'persistent' | 'miss';
    incremental: boolean;
}>) => NonNullable<DisplayRoutingDebugState['cacheTrustLevel']>;
export type DisplayLayoutPhase = 'command' | 'input-preparation' | 'layout-calculation' | 'dynamic-import' | 'worker-routing' | 'state-commit' | 'render-reconcile' | 'fit-request';
export type DisplayLayoutPhaseTrace = Readonly<{
    sequence: number;
    phase: DisplayLayoutPhase;
    status: 'running' | 'completed' | 'failed';
    startedAt: number;
    durationMs?: number;
}>;
export type DisplayLayoutTransactionStatus = 'running' | 'committed' | 'failed';
export type DisplayLayoutTransactionErrorCode = 'cancelled' | 'hard-quality-rejected' | 'worker-timeout' | 'no-layoutable-nodes' | 'strategy-failed';
export type BaseReactFlowRenderAuthorityIssue = 'untrusted-baseline' | 'missing-worker-session' | 'missing-hard-report' | 'output-signature-mismatch' | 'invalid-authority-payload';
export type BaseReactFlowRenderAuthorityStatus = 'accepted' | 'missing-commit' | 'input-signature-mismatch' | 'input-geometry-mismatch' | 'output-signature-mismatch' | 'edge-claim-mismatch';
export declare const updateDisplayRoutingDebugState: (patch: DisplayRoutingDebugState) => void;
export declare const updateDisplayRoutingLifecycleState: (stage: string, signature: string, nodeCount: number, edgeCount: number) => void;
export declare const updateDisplayLayoutTransactionState: ({ jobId, status, attemptCount, errorCode, }: Readonly<{
    jobId: number;
    status: DisplayLayoutTransactionStatus;
    attemptCount: number;
    errorCode?: DisplayLayoutTransactionErrorCode;
}>) => void;
export declare const classifyDisplayLayoutTransactionError: (error: unknown) => DisplayLayoutTransactionErrorCode;
export declare const recordDisplayRoutingPrecompiledRouteDiagnostic: (diagnostic: BaseReactFlowPrecompiledRouteDiagnostic) => void;
export declare const updateDisplayRoutingFinalAppliedState: (patch: DisplayRoutingDebugState) => void;
export declare const resolveDisplayRoutingCommittedReuseTiming: ({ current, signature, inputGeometryDigest, outputRouteSignature, now, }: {
    current: DisplayRoutingDebugState | undefined;
    signature: string;
    inputGeometryDigest: string;
    outputRouteSignature?: string;
    now: number;
}) => Pick<DisplayRoutingDebugState, 'scheduledAt' | 'workerStartedAt' | 'workerResponseParsedAt' | 'finalAppliedAt' | 'routeMs' | 'totalRouteMs' | 'phaseTrace' | 'workerResolution' | 'hardGateDiagnostics'>;
/**
 * Only an atomic staged-layout handoff may retain the Worker request evidence
 * that immediately preceded committed-snapshot reuse. Ordinary cache reuse
 * must clear it, otherwise a failed layout can make the previous canvas look
 * as though it committed the newer layout request.
 */
export declare const resolveDisplayRoutingCommittedReuseTransactionEvidence: (current: DisplayRoutingDebugState | undefined, trustedTransactionHandoff: boolean) => Pick<DisplayRoutingDebugState, 'requestId' | 'lastPhaseTrace' | 'phaseProgressTrace'>;
export declare const readDisplayRoutingDebugState: () => DisplayRoutingDebugState | undefined;
/** Timing and request evidence must describe the same accepted reuse. */
export declare const resolveDisplayRoutingCommittedReuseState: (options: Parameters<typeof resolveDisplayRoutingCommittedReuseTiming>[0] & {
    trustedTransactionHandoff: boolean;
}) => DisplayRoutingDebugState;
export declare const appendDisplayRoutingPhaseProgress: (trace: DisplayRoutingPhaseTrace) => void;
export declare const appendDisplayRoutingBoundedCandidate: (boundedCandidate: NonNullable<DisplayEdgesWorkerResponse['boundedCandidate']>, requestId: string) => void;
