import type { Edge, Node } from '@xyflow/react';
import { type DirectionalOuterLaneCandidateBatch } from './baseReactFlowDirectionalOuterLaneSearch.js';
import { type DisplayPoint } from './baseReactFlowDisplayGeometry.js';
export declare const STRICT_OUTER_LANE_MIN_SPAN = 420;
export declare const STRICT_OUTER_LANE_MAX_REPAIRED_EDGES = 4;
export declare const STRICT_OUTER_LANE_MAX_CANDIDATES = 48;
export declare const STRICT_OUTER_LANE_STUB_LENGTHS: number[];
export declare const buildDirectionalStrictOuterLaneCandidates: (path: DisplayPoint[], nodes: Node[], edge: Edge) => Iterable<DirectionalOuterLaneCandidateBatch<DisplayPoint[]>>;
