import type { Edge, Node } from '@xyflow/react';
import { type BaseReactFlowFinalSafetyCandidateOptions } from './baseReactFlowDisplayFinalSafetyEvaluation.js';
import { type BaseReactFlowFinalSafetyTraceOptions } from './baseReactFlowDisplayFinalSafetyTrace.js';
export { buildTrueTrunkCrossingSkirtCandidates } from './baseReactFlowDisplayTrueTrunkCrossingCandidates.js';
export type BaseReactFlowFinalSafetyClosureOptions = BaseReactFlowFinalSafetyCandidateOptions & BaseReactFlowFinalSafetyTraceOptions & Readonly<{
    onNoopCacheHit?: () => void;
}>;
/**
 * Rebuild a crossed one-to-many/many-to-one bundle as one atomic candidate.
 *
 * A through-edge cannot always skirt a source trunk locally: the skirt can be
 * trapped by a sibling target approach farther downstream. For the bounded
 * vertical-flow case, this transaction moves the whole affected bundle:
 * source siblings share one terminal stem, the through-edge uses the outside
 * lane, and every later target sibling joins the earliest protected target
 * trunk. The caller still applies the complete hard/order/trunk gate.
 */
export declare const buildBidirectionalPortBundleTransactionCandidates: (edges: Edge[], nodes: Node[], eligibleEdgeIds?: ReadonlySet<string>) => Edge[][];
export declare const buildAlternateSourceCorridorCandidates: (edges: Edge[], eligibleEdgeIds?: ReadonlySet<string>) => Edge[][];
/**
 * Final fail-closed transaction for the interaction between orthogonality,
 * obstacle avoidance, bidirectional port ordering, and dual-role true trunks.
 *
 * Expensive routing stages may time out after improving only one metric. This
 * bounded closure never commits a partial improvement: the whole rendered
 * graph must pass the hard gate and the final port-order audit in one result.
 */
export declare const repairBaseReactFlowFinalSafetyClosure: <T extends Edge[]>(edges: T, nodes: Node[], options?: BaseReactFlowFinalSafetyClosureOptions) => T;
