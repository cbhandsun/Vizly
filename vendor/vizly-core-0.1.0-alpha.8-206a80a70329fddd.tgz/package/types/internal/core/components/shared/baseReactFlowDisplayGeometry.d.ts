import type { Edge, Node } from '@xyflow/react';
export type DisplayPoint = {
    x: number;
    y: number;
};
export type DisplaySegment = {
    edgeIndex: number;
    segmentIndex: number;
    axis: 'h' | 'v';
    direction: -1 | 0 | 1;
    a: DisplayPoint;
    b: DisplayPoint;
};
export type DisplayRect = {
    x: number;
    y: number;
    width: number;
    height: number;
};
export declare const NEAR_PARALLEL_LANE_TOLERANCE = 4;
export declare const OBSTACLE_REPAIR_NODE_PADDING = 8;
export declare const RESIDUAL_PARALLEL_LANE_GAP = 24;
export declare const isDisplayContainerNode: (node: Node) => boolean;
export declare const getDisplayNodeRect: (node: Node) => DisplayRect | null;
export declare const displayRoutingObstaclesSignature: (nodes: Node[]) => string;
export declare const buildDisplayRoutingObstacles: (nodes: Node[]) => Map<string, DisplayRect>;
export declare const compactDisplayEdgePaths: <T extends Edge[]>(edges: T) => T;
export declare const getDisplayComputedPath: (edge: Edge) => DisplayPoint[];
export declare const withDisplayComputedPath: (edge: Edge, path: DisplayPoint[]) => Edge;
export declare const displayAxisOf: (first: DisplayPoint, second: DisplayPoint) => 'h' | 'v' | null;
export declare const displaySegmentDirection: (first: DisplayPoint, second: DisplayPoint, axis: 'h' | 'v') => -1 | 0 | 1;
export declare const displayPathLength: (path: DisplayPoint[]) => number;
export declare const segmentDisplayLength: (first: DisplayPoint, second: DisplayPoint) => number;
export declare const countDisplayShortEndpointStubs: (edges: Edge[], minLength: number) => number;
export declare const displayRangeOverlap: (a1: number, a2: number, b1: number, b2: number) => number;
export declare const rangesOverlapWithMargin: (firstStart: number, firstEnd: number, secondStart: number, secondEnd: number, margin?: number) => boolean;
export declare const displaySegmentOverlap: (first: DisplaySegment, second: DisplaySegment) => number;
export declare const displayEdgesRelated: (first: Edge, second: Edge) => boolean;
export declare const displaySegmentsForPath: (path: DisplayPoint[], edgeIndex: number) => DisplaySegment[];
/**
 * A shared endpoint alone does not make an overlap a trunk. Every preceding
 * source segment (or following target segment) must be the same directed
 * geometric chain. This mirrors the rendered audit and keeps source/target
 * identities independent for dual-trunk edges.
 */
export declare const isProtectedDisplaySharedTrunkPair: (first: DisplaySegment, firstPath: DisplayPoint[], firstEdge: Edge, second: DisplaySegment, secondPath: DisplayPoint[], secondEdge: Edge) => boolean;
export declare const extractDisplaySegments: (edges: Edge[]) => DisplaySegment[];
export declare const displayStrictCrossesHorizontal: (horizontalStart: DisplayPoint, horizontalEnd: DisplayPoint, vertical: DisplaySegment) => boolean;
export declare const displayStrictCrossesVertical: (verticalStart: DisplayPoint, verticalEnd: DisplayPoint, horizontal: DisplaySegment) => boolean;
/** Raw geometric intersections, including readable crossings. */
export declare const findDisplayGeometricCrossingHits: (edges: Edge[]) => Array<{
    a: DisplaySegment;
    b: DisplaySegment;
}>;
/** Only unresolved crossings enter hard-repair candidate selection. */
export declare const findDisplayStrictCrossingHits: (edges: Edge[]) => Array<{
    a: DisplaySegment;
    b: DisplaySegment;
}>;
export declare const candidateUnrelatedOverlapForEdge: (edgeIndex: number, path: DisplayPoint[], edges: Edge[], otherSegments: DisplaySegment[]) => number;
export declare const candidateStrictCrossingsForEdge: (edgeIndex: number, path: DisplayPoint[], otherSegments: DisplaySegment[]) => number;
export type DisplayCandidateInteractionCounts = Readonly<{
    strictCrossings: number;
    unrelatedOverlap: number;
}>;
export type DisplayCandidateInteractionContext = Readonly<{
    evaluate: (path: DisplayPoint[]) => DisplayCandidateInteractionCounts;
}>;
/**
 * Reuses the mover-independent half of candidate interaction scoring. The
 * overlap partitions preserve the original segment order; strict crossings use
 * one immutable coordinate index for all candidates. Both retain the boundary
 * behavior of the standalone scorers without candidate segment objects. The
 * returned context snapshots segment geometry and edge relationships.
 */
export declare const createDisplayCandidateInteractionContext: (edgeIndex: number, edges: Edge[], otherSegments: DisplaySegment[]) => DisplayCandidateInteractionContext;
export declare const displaySegmentIntersectsRect: (first: DisplayPoint, second: DisplayPoint, rect: DisplayRect, padding?: number) => boolean;
export declare const sortedUniqueNumbers: (values: number[], preferred: number) => number[];
export declare const prioritizeLaneValues: (preferred: number, priorityValues: number[], secondaryValues: number[], maxLanes: number) => number[];
export declare const collectPathHitObstacleRects: (path: DisplayPoint[], obstacles: DisplayRect[]) => DisplayRect[];
export declare const shiftDisplayInternalSegment: (path: DisplayPoint[], segmentIndex: number, axis: 'h' | 'v', laneValue: number) => DisplayPoint[] | null;
export declare const fullDisplayPortSide: (side: 'l' | 'r' | 't' | 'b' | undefined) => 'left' | 'right' | 'top' | 'bottom' | undefined;
export declare const oppositeDisplayPortSide: (side: 'l' | 'r' | 't' | 'b') => 'left' | 'right' | 'top' | 'bottom';
export declare const displayPointsCoincide: (first: DisplayPoint | undefined, second: DisplayPoint | undefined) => boolean;
