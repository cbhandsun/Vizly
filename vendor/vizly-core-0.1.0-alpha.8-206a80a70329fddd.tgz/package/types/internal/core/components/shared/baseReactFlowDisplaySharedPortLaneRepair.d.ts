import type { Edge, Node } from '@xyflow/react';
export declare const buildBoundedSharedPortLaneSchedule: (tangentCandidates: readonly number[], bridgeCandidates: readonly number[], limit?: number) => Array<{
    tangent: number;
    bridge: number;
}>;
export declare const interleaveBoundedRepairCandidates: <T>(preferred: readonly T[], secondary: readonly T[], limit: number) => T[];
export declare const repairSharedPortAndTinyTerminalLanes: <T extends Edge[]>(edges: T, nodes: Node[], maxQualityEvaluations?: number, options?: Readonly<{
    allowTransientStrictCrossing?: boolean;
}>) => T;
