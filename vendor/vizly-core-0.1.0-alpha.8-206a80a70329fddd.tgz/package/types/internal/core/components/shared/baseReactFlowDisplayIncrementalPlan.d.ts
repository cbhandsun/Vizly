import type { Edge, Node } from '@xyflow/react';
import type { BaseReactFlowDisplayCommittedSnapshotBaseline } from './baseReactFlowDisplayCommittedSnapshot.js';
import { type BaseReactFlowRoutingAffectedClosure, type BaseReactFlowRoutingChangeSet } from './baseReactFlowDisplayRoutingChangeSet.js';
export type BaseReactFlowDisplayIncrementalPlan = Readonly<{
    baseline: BaseReactFlowDisplayCommittedSnapshotBaseline;
    changeSet: BaseReactFlowRoutingChangeSet;
    affectedClosure: BaseReactFlowRoutingAffectedClosure;
}>;
export declare const hasBaseReactFlowDisplayIncrementalWork: (changeSet: BaseReactFlowRoutingChangeSet, affectedClosure: BaseReactFlowRoutingAffectedClosure) => boolean;
export declare const createBaseReactFlowDisplayIncrementalPlan: ({ baseline, nextInputSignature, nextInputGeometryDigest, nextNodes, nextEdges, draggedNodeIds, }: {
    baseline: BaseReactFlowDisplayCommittedSnapshotBaseline | null;
    nextInputSignature: string;
    nextInputGeometryDigest: string;
    nextNodes: Node[];
    nextEdges: Edge[];
    draggedNodeIds: readonly string[];
}) => BaseReactFlowDisplayIncrementalPlan | null;
