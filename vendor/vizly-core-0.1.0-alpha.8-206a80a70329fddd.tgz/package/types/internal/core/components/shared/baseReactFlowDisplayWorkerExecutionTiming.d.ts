/** Epoch-relative monotonic times; never Date.now() values or graph content. */
export type DisplayWorkerExecutionTiming = {
    readyAt: number;
    receivedAt: number;
    finishedAt: number;
};
export declare const parseDisplayWorkerExecutionTiming: (value: unknown) => DisplayWorkerExecutionTiming | null;
type DisplayWorkerTimingMetadata = {
    workerDurationMs?: number;
    workerExecutionTiming?: DisplayWorkerExecutionTiming;
};
export declare const parseDisplayWorkerTimingMetadata: (value: Record<string, unknown>) => DisplayWorkerTimingMetadata | null;
export {};
