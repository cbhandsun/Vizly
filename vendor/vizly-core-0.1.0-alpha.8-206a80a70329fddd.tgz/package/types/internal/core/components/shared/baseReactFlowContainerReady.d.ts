type ContainerSize = {
    width: number;
    height: number;
};
export declare const hasBaseReactFlowRenderableSize: ({ containerSize, liveRect, }: {
    containerSize: ContainerSize;
    liveRect?: Pick<DOMRect, 'width' | 'height'> | null;
}) => boolean;
export declare const scheduleBaseReactFlowContainerReadyUpdate: ({ hasRenderableSize, isContainerReady, setIsContainerReady, setTimeoutImpl, }: {
    hasRenderableSize: boolean;
    isContainerReady: boolean;
    setIsContainerReady: (ready: boolean) => void;
    setTimeoutImpl?: (handler: TimerHandler, timeout?: number) => number;
}) => number | null;
export {};
