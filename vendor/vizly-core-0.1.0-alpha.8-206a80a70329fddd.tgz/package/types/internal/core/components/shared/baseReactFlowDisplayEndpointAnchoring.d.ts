import type { Edge, Node } from '@xyflow/react';
/**
 * Commits only terminal boundary geometry after route quality selection.
 *
 * Unlike the interactive endpoint beautifier below, this boundary does not
 * fold dominant-axis elbows. It keeps the accepted route lanes intact while
 * snapping sub-pixel terminal drift and turning a boundary tangent into one
 * short outward stub when the adjacent lane already provides enough room.
 */
export declare const commitComputedDisplayEdgeTerminals: (edges: Edge[], nodes: Node[], nodeById?: Map<string, Node>) => Edge[];
export declare const anchorComputedDisplayEdgeEndpoints: (edges: Edge[], nodes: Node[]) => Edge[];
