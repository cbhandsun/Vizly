export type RankedOuterPortPair<T> = {
    firstIndex: number;
    secondIndex: number;
    quickScore: number;
    value: T;
};
/**
 * Selects a bounded set of port-pair seeds without letting globally short
 * combinations starve a port path. Every first/second port contributes its
 * best available pairing before remaining capacity is split between the
 * lowest and highest direct-pair scores. High-score seeds are intentional:
 * they expose port-topology conflicts that the outer path is meant to repair.
 *
 * With the production bounds (at most 16 ports per edge and 32 seeds), the
 * coverage phase itself is guaranteed to fit. A smaller caller-provided cap
 * remains a strict cap and keeps the best deterministic prefix.
 */
export declare const selectDiverseOuterPortPairSeeds: <T>(pairs: ReadonlyArray<RankedOuterPortPair<T>>, firstCount: number, secondCount: number, limit?: number) => T[];
