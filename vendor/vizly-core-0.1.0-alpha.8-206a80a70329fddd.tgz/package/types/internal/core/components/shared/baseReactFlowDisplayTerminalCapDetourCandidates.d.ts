import type { Edge, Node } from '@xyflow/react';
import { type DisplayPoint, type DisplaySegment } from './baseReactFlowDisplayGeometry.js';
/**
 * Builds a bounded detour around the node that caps a competing terminal
 * segment. A local crossing zipper cannot pass such a segment without
 * entering either terminal node, so the mover crosses behind the whole node
 * on the hemisphere opposite that terminal's declared handle.
 */
export declare const buildTerminalCapDetourCandidates: (path: readonly DisplayPoint[], segment: DisplaySegment, otherPath: readonly DisplayPoint[], otherSegment: DisplaySegment, otherEdge: Edge, nodes: readonly Node[], clearance?: number) => DisplayPoint[][];
