import type { Edge, Node } from '@xyflow/react';
import { type DisplayPoint, type DisplaySegment } from './baseReactFlowDisplayGeometry.js';
export declare const buildObstacleSkirtCandidates: (path: DisplayPoint[], nodes: Node[], edge: Edge, allEdges: Edge[], allSegments?: DisplaySegment[], maxCandidates?: number) => DisplayPoint[][];
export declare const buildObstacleOuterEscapeCandidates: (path: DisplayPoint[], nodes: Node[], edge: Edge) => DisplayPoint[][];
export declare const buildWholePathOuterLaneCandidates: (path: DisplayPoint[], nodes: Node[], edge: Edge, includeOuterRing?: boolean) => DisplayPoint[][];
