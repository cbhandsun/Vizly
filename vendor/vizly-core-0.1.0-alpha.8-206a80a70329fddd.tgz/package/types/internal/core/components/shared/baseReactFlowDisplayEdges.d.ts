import type { Edge } from '@xyflow/react';
import { type BaseReactFlowDisplayEdgesArgs } from './baseReactFlowDisplayFullRoutePipeline.js';
export type { BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
export { repairBoundedReverseParallelOverlaps } from './baseReactFlowDisplayReverseParallelOverlapClosure.js';
export { baseReactFlowDisplayHardQualityIsClean, computeBaseReactFlowDisplayEdgeEpoch, } from './baseReactFlowDisplayQualityGates.js';
export { createBaseReactFlowInteractiveDisplayEdges } from './baseReactFlowDisplayQualitySeedPipeline.js';
export { repairBaseReactFlowMeasuredDisplayEdges, repairBaseReactFlowMeasuredDisplayEdgesWithReport, } from './baseReactFlowDisplayMeasuredRepair.js';
export { createBaseReactFlowPreDisplayFinalEdges } from './baseReactFlowDisplayPreDisplayPipeline.js';
/**
 * Compatibility facade retained while tests migrate to the production Worker.
 * Production rendering must use the Worker-owned Routing Session transaction.
 */
export declare const createBaseReactFlowDisplayEdges: (args: BaseReactFlowDisplayEdgesArgs) => Edge[];
