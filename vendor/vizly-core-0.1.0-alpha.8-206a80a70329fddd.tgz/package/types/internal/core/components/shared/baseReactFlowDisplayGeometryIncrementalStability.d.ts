import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
import type { DisplayEdgesWorkerResolvedIncrementalRouteRequest, DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerProtocol.js';
/**
 * A geometry edit may temporarily promote a frozen context edge for clearance
 * repair. Restore those promoted routes collectively when the exact historical
 * geometry remains hard-clean at the new node positions. Requested incident
 * edges stay mutable; the final commit gate freezes every other route.
 */
export declare const preserveDisplayGeometryIncrementalRoutes: (request: DisplayEdgesWorkerResolvedIncrementalRouteRequest, response: DisplayEdgesWorkerResponse, onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void) => DisplayEdgesWorkerResponse;
