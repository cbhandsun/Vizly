import type { Edge, Node } from '@xyflow/react';
/**
 * Commits geometry-selected automatic terminal sides to the stable route.
 *
 * Late quality selection can restore a legal path candidate whose terminal
 * handle token is absent even though its first/last segment unambiguously
 * leaves a node boundary. Persisting that inconsistency makes a precompiled
 * route render correctly once but prevents a later incremental reconnect from
 * identifying the terminal role. This boundary is intentionally geometry-only
 * and never changes source-authored fixed terminal declarations.
 */
export declare const materializeDisplayTerminalHandles: <T extends Edge[]>(edges: T, nodes: Node[], nodeById?: Map<string, Node>) => T;
