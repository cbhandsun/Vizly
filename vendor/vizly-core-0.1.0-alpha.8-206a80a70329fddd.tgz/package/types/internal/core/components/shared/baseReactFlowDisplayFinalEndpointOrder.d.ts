import type { Edge, Node } from '@xyflow/react';
import { type BaseReactFlowFinalEndpointOrderOptions } from './baseReactFlowDisplayFinalEndpointGate.js';
export { finalSameSideTrueTrunksDoNotRegress } from './baseReactFlowDisplayTrueTrunkContract.js';
export { repairBaseReactFlowFinalCommercialDetours, traceSkippedFinalCommercialDetours, } from './baseReactFlowDisplayCommercialDetourRepair.js';
export type { BaseReactFlowFinalEndpointOrderOptions } from './baseReactFlowDisplayFinalEndpointGate.js';
export { traceSkippedFinalEndpointPhases } from './baseReactFlowDisplayFinalEndpointTrace.js';
/**
 * Last display transaction for automatic same-side endpoint and passage ordering.
 *
 * The strategy layer owns bounded geometry generation. This wrapper adds the
 * exact render hard gate and retains every source/target true-trunk identity
 * independently, so a dual-trunk edge cannot lose either endpoint role.
 */
export declare const repairBaseReactFlowFinalEndpointOrder: <T extends Edge[]>(edges: T, nodes: Node[], options?: BaseReactFlowFinalEndpointOrderOptions) => T;
