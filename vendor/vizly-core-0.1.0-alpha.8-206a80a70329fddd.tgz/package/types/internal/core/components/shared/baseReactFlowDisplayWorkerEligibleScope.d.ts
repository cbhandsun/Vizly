/** Missing evidence remains unavailable; malformed evidence invalidates the message. */
export declare const parseDisplayWorkerEligibleScope: (response: Record<string, unknown>) => string[] | null | undefined;
