import type { Edge } from '@xyflow/react';
export declare const buildSingleEdgeZipperCandidates: <T extends Edge[]>(edges: T, moverEdgeIndex: number, maxCandidates?: number) => T[];
