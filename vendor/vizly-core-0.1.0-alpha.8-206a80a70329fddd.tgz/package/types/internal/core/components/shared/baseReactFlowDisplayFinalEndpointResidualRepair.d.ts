import type { Edge, Node } from '@xyflow/react';
import type { BaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
type FinalEndpointResidualCandidateValidator = (baselineEdges: readonly Edge[], candidateEdges: readonly Edge[], changedEdgeIndexes: readonly number[]) => boolean;
export type BaseReactFlowFinalEndpointResidualRepair = Readonly<{
    strict: (baseline: Edge[]) => Edge[];
    overlap: (baseline: Edge[]) => Edge[];
    fixedPoint: (baseline: Edge[]) => Edge[];
}>;
export declare const createBaseReactFlowFinalEndpointResidualRepair: ({ nodes, evaluation, validate, repairOverlap, repairStrict, scoreResidualOverlap, }: {
    nodes: Node[];
    evaluation: BaseReactFlowFinalEndpointEvaluation;
    validate: FinalEndpointResidualCandidateValidator;
    repairOverlap?: (edges: Edge[], nodes: Node[]) => Edge[];
    repairStrict?: (edges: Edge[], nodes: Node[]) => Edge[];
    scoreResidualOverlap?: (edges: readonly Edge[]) => number;
}) => BaseReactFlowFinalEndpointResidualRepair;
export {};
