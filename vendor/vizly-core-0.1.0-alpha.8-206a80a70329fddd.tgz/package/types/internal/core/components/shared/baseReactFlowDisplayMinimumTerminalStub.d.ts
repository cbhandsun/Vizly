import type { XYPosition } from '@xyflow/react';
import type { AnchorSide, NodeRect } from './baseReactFlowDisplayEdgeGeometry.js';
/** Extends a short terminal lane as one orthogonal transaction. */
export declare const ensureMinimumOutwardTerminalStub: (path: XYPosition[], terminalIndex: number, rect: NodeRect, handle: string | null | undefined, fallbackSide: AnchorSide) => boolean;
