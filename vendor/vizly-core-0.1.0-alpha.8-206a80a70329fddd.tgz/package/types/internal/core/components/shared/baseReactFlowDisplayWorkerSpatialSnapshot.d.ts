import type { Edge, Node } from '@xyflow/react';
import { type NodeClearanceGraphEvaluationContext } from '../../strategies/shared/edgeWaypointCandidateRepair.js';
import { type DisplayRect } from './baseReactFlowDisplayGeometry.js';
export type DisplayRoutingSegmentIndexMetrics = Readonly<{
    indexedSegmentCount: number;
    overflowEdgeCount: number;
    queryCount: number;
    scannedBucketCount: number;
    candidateEdgeCount: number;
}>;
export type DisplayRoutingSegmentSpatialIndex = Readonly<{
    outputRouteSignature: string;
    edgeCount: number;
    queryEdgeIds: (rectangles: readonly DisplayRect[], padding?: number) => ReadonlySet<string> | null;
    readMetrics: () => DisplayRoutingSegmentIndexMetrics;
}>;
export type DisplayRoutingWorkerSpatialSnapshot = Readonly<{
    outputRouteSignature: string;
    segmentIndex: DisplayRoutingSegmentSpatialIndex;
    nodeClearanceIndex: NodeClearanceGraphEvaluationContext;
}>;
export declare const createDisplayRoutingSegmentSpatialIndex: (edges: readonly Edge[], expectedOutputRouteSignature?: string) => DisplayRoutingSegmentSpatialIndex | null;
export declare const createDisplayRoutingWorkerSpatialSnapshot: ({ nodes, edges, outputRouteSignature, }: {
    nodes: Node[];
    edges: Edge[];
    outputRouteSignature: string;
}) => DisplayRoutingWorkerSpatialSnapshot | null;
