import { type TerminalAxis as Axis, type TerminalPoint as Point } from './baseReactFlowTerminalGeometry.js';
export declare const compactTerminalAxisPath: (path: Point[]) => Point[];
export declare const terminalAxisSegments: (path: Point[]) => Array<{
    a: Point;
    b: Point;
    axis: Axis;
    index: number;
}>;
export declare const terminalAxisPathLength: (path: Point[]) => number;
export declare const hasTerminalAxisHairpin: (path: Point[]) => boolean;
export declare const hasTinyTerminalInteriorDogleg: (path: Point[], minimumInteriorLength: number) => boolean;
