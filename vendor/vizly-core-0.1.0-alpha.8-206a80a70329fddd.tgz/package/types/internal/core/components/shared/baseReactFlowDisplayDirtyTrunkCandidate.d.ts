import type { Edge, Node } from '@xyflow/react';
/** Propose repairs only for endpoint groups with an existing unexplained overlap. */
export declare const buildDirtySharedTrunkCandidate: <T extends Edge[]>(edges: T, nodes: Node[]) => T;
