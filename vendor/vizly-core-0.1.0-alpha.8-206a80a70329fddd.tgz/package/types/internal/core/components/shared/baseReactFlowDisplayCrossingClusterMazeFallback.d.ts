import type { Edge, Node } from '@xyflow/react';
/** A separate fallback after terminal bridges fail. At most four alternatives
 * yield fifteen nonempty subsets, each moving no more than four edges. Consume
 * only the caller's remaining quality budget; preserve the proven fast path.
 */
export declare const repairDisplayCrossingClusterMazeFallback: <T extends Edge[]>(edges: T, nodes: Node[], remainingEvaluations: number, acceptCandidate?: (candidate: T) => boolean) => T;
