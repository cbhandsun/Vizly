import type { BaseReactFlowRoutingSessionJob, BaseReactFlowRoutingSessionRuntime } from './baseReactFlowRoutingSessionRuntime.js';
import type { DisplayWorkerFailureCode } from './baseReactFlowDisplayFailureSummary.js';
export type BaseReactFlowDisplayFailureReason = 'quality-rejected' | 'route-mismatch' | 'receipt-missing' | 'source-shape-mismatch' | 'session-commit-rejected' | 'worker-timeout' | 'worker-failed';
export type BaseReactFlowDisplayFailureIdentity = Readonly<{
    inputSignature: string;
    inputGeometryDigest: string;
}>;
export type BaseReactFlowDisplayFailure = BaseReactFlowDisplayFailureIdentity & Readonly<{
    jobId: number;
    reason: BaseReactFlowDisplayFailureReason;
    workerFailureCode?: DisplayWorkerFailureCode;
}>;
export declare const displayFailureMatchesInput: (failure: BaseReactFlowDisplayFailure | null, identity: BaseReactFlowDisplayFailureIdentity) => boolean;
/** A rejected result has no authority to affect a newer geometry or session job. */
export declare const createCurrentDisplayFailure: ({ runtime, job, requested, current, reason, workerFailureCode, }: Readonly<{
    runtime: Pick<BaseReactFlowRoutingSessionRuntime, 'isCurrentJob'>;
    job: BaseReactFlowRoutingSessionJob;
    requested: BaseReactFlowDisplayFailureIdentity;
    current: BaseReactFlowDisplayFailureIdentity | null;
    reason: BaseReactFlowDisplayFailureReason;
    workerFailureCode?: DisplayWorkerFailureCode;
}>) => BaseReactFlowDisplayFailure | null;
export declare const classifyDisplayFinalRejection: ({ hardClean, routesMatch, hasReceipt, }: Readonly<{
    hardClean: boolean;
    routesMatch: boolean;
    hasReceipt: boolean;
}>) => BaseReactFlowDisplayFailureReason | null;
/** Never propagate worker-provided text to the UI or diagnostics. */
export declare const classifyDisplayWorkerFailure: (error: unknown) => BaseReactFlowDisplayFailureReason | null;
