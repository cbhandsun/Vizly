import type { BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
export type BaseReactFlowMeasuredRepairNeeds = {
    obstacle: boolean;
    overlap: boolean;
    strict: boolean;
    terminal: boolean;
};
/**
 * Derives the minimum exact-repair stages required by a hard-gate report.
 * Stages may still be re-evaluated after an accepted edit because an edit can
 * expose a different defect, but a known-zero stage is never run speculatively.
 */
export declare const getBaseReactFlowMeasuredRepairNeeds: (report: BaseDisplayBoundedCandidateReport) => BaseReactFlowMeasuredRepairNeeds;
