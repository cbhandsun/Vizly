import type { Edge, Node } from '@xyflow/react';
import type { RoutingPatch } from '../../routing/routingPatch.js';
import type { RoutingIdentity } from './baseReactFlowDisplayRoutingSession.js';
export type DisplayEdgesWorkerRepairRequest = {
    operation: 'repair';
    requestId: string;
    edges: Edge[];
    nodes: Node[];
    inputIdentity?: RoutingIdentity;
    /** Bounded runs measured repair only; finalized also closes commercial safety. */
    repairMode: 'bounded' | 'finalized';
    /** Ends a disposable candidate pass once its obstacle stage remains dirty. */
    stopAfterObstacleFailure?: boolean;
};
export type DisplayEdgesWorkerValidatedRepairRequest = Omit<DisplayEdgesWorkerRepairRequest, 'inputIdentity'> & {
    inputIdentity: RoutingIdentity;
};
export type DisplayEdgesWorkerRepairValidateOrRouteRequest = {
    operation: 'repair-validate-or-route';
    requestId: string;
    edges: Edge[];
    nodes: Node[];
    enableSmartEdges: boolean;
    smartEdgePadding: number;
    isLargeGraph: boolean;
    displayEdgeEpoch: number;
    qualityMode: 'full' | 'interactive';
    inputIdentity?: RoutingIdentity;
    candidateEdges?: Edge[];
    candidatePatches?: RoutingPatch[];
    fallbackCandidateEdges?: Edge[];
    fallbackCandidatePatches?: RoutingPatch[];
    candidateSource: 'persistent';
    stopAfterObstacleFailure?: boolean;
};
export type DisplayEdgesWorkerValidatedRepairValidateRequest = Omit<DisplayEdgesWorkerRepairValidateOrRouteRequest, 'inputIdentity'> & {
    inputIdentity: RoutingIdentity;
};
type ValidatedRouteFields = Omit<DisplayEdgesWorkerValidatedRepairValidateRequest, 'operation' | 'candidateEdges' | 'candidatePatches' | 'fallbackCandidateEdges' | 'fallbackCandidatePatches' | 'candidateSource' | 'stopAfterObstacleFailure'>;
export declare const parseDisplayWorkerLayoutRepairRequest: ({ value, routeFields, isEdgeList, }: {
    value: Record<string, unknown>;
    routeFields: ValidatedRouteFields;
    isEdgeList: (candidate: unknown) => candidate is Edge[];
}) => DisplayEdgesWorkerValidatedRepairValidateRequest | null;
export {};
