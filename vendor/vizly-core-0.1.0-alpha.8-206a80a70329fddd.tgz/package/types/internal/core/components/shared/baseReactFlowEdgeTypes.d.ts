import type { EdgeTypes } from '@xyflow/react';
type BaseReactFlowEdgeTypeComponents = {
    advancedSmartStepEdge: React.ElementType;
    advancedSmartBezierEdge: React.ElementType;
    advancedSmartStraightEdge: React.ElementType;
    smartOrthogonalEdge: React.ElementType;
    elkEdge: React.ElementType;
    stablePathEdge: React.ElementType;
    canvasRefEdge: React.ElementType;
    editableEdge: React.ElementType;
};
export declare const createBaseReactFlowMergedEdgeTypes: ({ edgeTypes, components, }: {
    edgeTypes?: EdgeTypes;
    components: BaseReactFlowEdgeTypeComponents;
}) => EdgeTypes;
export {};
