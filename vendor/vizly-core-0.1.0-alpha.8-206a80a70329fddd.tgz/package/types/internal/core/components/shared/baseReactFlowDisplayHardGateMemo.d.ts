import type { Edge, Node } from '@xyflow/react';
import type { BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
import type { DisplayTerminalValidationSnapshot } from './baseReactFlowTerminalAxisRepair.js';
type HardGateEvaluator = (edges: Edge[], nodes: Node[], candidate: BaseDisplayBoundedCandidateReport['candidate'], terminalSnapshot?: DisplayTerminalValidationSnapshot) => BaseDisplayBoundedCandidateReport;
export type BaseDisplayHardGateMemo = {
    getReport: HardGateEvaluator;
    getImmutableReport: (edges: readonly Edge[], candidate: BaseDisplayBoundedCandidateReport['candidate']) => BaseDisplayBoundedCandidateReport;
    getRememberedImmutableReport: (edges: readonly Edge[], candidate: BaseDisplayBoundedCandidateReport['candidate']) => BaseDisplayBoundedCandidateReport | undefined;
    getRememberedReport: (edges: readonly Edge[], candidate: BaseDisplayBoundedCandidateReport['candidate']) => BaseDisplayBoundedCandidateReport | undefined;
    rememberReport: (edges: readonly Edge[], report: BaseDisplayBoundedCandidateReport) => boolean;
    rememberImmutableReport: (edges: readonly Edge[], report: BaseDisplayBoundedCandidateReport) => boolean;
    readMetrics: () => Readonly<{
        evaluationCount: number;
        cacheHitCount: number;
        scannedNodeCount: number;
        scannedEdgePairCount: number;
    }>;
};
/** Exact geometry and terminal-policy identity consumed by every hard gate. */
export declare const computeBaseDisplayHardGateEvidenceSignature: (edges: readonly Edge[]) => string | null;
/**
 * Request-local memo for the exact hard-gate report of a rendered route.
 * The candidate label describes the pipeline stage; it does not participate in
 * any quality, obstacle, or terminal calculation, so one route can safely reuse
 * the same evidence across stage labels.
 */
export declare const createBaseDisplayHardGateMemo: (nodes: Node[], terminalSnapshot: DisplayTerminalValidationSnapshot, evaluateReport?: HardGateEvaluator) => BaseDisplayHardGateMemo;
export {};
