import type { Edge, Node } from '@xyflow/react';
export type TerminalPoint = {
    x: number;
    y: number;
};
export type TerminalAxis = 'h' | 'v';
export type TerminalHandleSide = 't' | 'b' | 'l' | 'r';
export type TerminalRect = {
    x: number;
    y: number;
    width: number;
    height: number;
};
export declare const TERMINAL_EPSILON = 0.5;
export declare const TERMINAL_ATTACHMENT_TOLERANCE = 1.5;
export declare const MAX_RENDERED_FILLET_TRANSITION = 24;
export declare const MIN_TERMINAL_STUB = 48;
export declare const expectedTerminalAxis: (side: TerminalHandleSide | null) => TerminalAxis | null;
export declare const fixedTerminalHandleSide: (edge: Edge, role: 'source' | 'target') => TerminalHandleSide | null;
export declare const terminalAxisOf: (first: TerminalPoint, second: TerminalPoint) => TerminalAxis | null;
export declare const readTerminalEdgePath: (edge: Edge) => TerminalPoint[];
export declare const readTerminalNodeRect: (node: Node) => TerminalRect | null;
export declare const boundarySideFromTerminalEndpoint: (point: TerminalPoint, rect: TerminalRect | undefined) => TerminalHandleSide | null;
export declare const terminalCoordinateIsOutward: (coordinate: number, point: TerminalPoint, side: TerminalHandleSide) => boolean;
