import type { Edge, Node } from '@xyflow/react';
import type { BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
import type { BaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
export type BaseReactFlowDisplayExactReport = Readonly<{
    inputNodes: Node[];
    repairNodes: Node[];
    outputRouteSignature: string;
    report: BaseDisplayBoundedCandidateReport;
}>;
export type BaseReactFlowDisplayFinalizerOutcome<T extends Edge[] = Edge[]> = Readonly<{
    edges: T;
    measuredRepairReachedFixedPoint?: boolean;
    report: BaseDisplayBoundedCandidateReport;
}>;
export declare const createBaseReactFlowDisplayExactReport: (edges: Edge[], inputNodes: Node[], repairNodes: Node[], report: BaseDisplayBoundedCandidateReport) => BaseReactFlowDisplayExactReport | undefined;
export declare const resolveBaseReactFlowDisplayExactReport: (edges: Edge[], nodes: Node[], exactReport?: BaseReactFlowDisplayExactReport) => BaseReactFlowDisplayExactReport | undefined;
/**
 * Applies the measured, terminal-axis, render-safety, and bounded terminal
 * transactions to a full-route candidate. The returned report always belongs
 * to the returned route. An exact signed-by-geometry report can be supplied by
 * an earlier stage so the pairwise hard gate is not repeated.
 */
export declare const finalizeBaseReactFlowDisplayEdgesWithReport: <T extends Edge[]>(fullRouteEdges: T, nodes: Node[], exactReport?: BaseReactFlowDisplayExactReport, onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void, deferStrictOnlyMeasuredRepair?: boolean, allowCompoundMeasuredResidualClosure?: boolean, evaluation?: BaseReactFlowFinalEndpointEvaluation) => BaseReactFlowDisplayFinalizerOutcome<T>;
export declare const finalizeBaseReactFlowDisplayEdges: <T extends Edge[]>(fullRouteEdges: T, nodes: Node[], exactReport?: BaseReactFlowDisplayExactReport, onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void, deferStrictOnlyMeasuredRepair?: boolean, evaluation?: BaseReactFlowFinalEndpointEvaluation) => T;
