import type { Edge, Node } from '@xyflow/react';
export { displayCrossingClusterPathSignature, firstDisplayCrossingClusterStrictHits, selectDisplayCrossingClusterOtherSegments, } from './baseReactFlowDisplayCrossingClusterGeometry.js';
export type { DisplayCrossingClusterStrictHit } from './baseReactFlowDisplayCrossingClusterGeometry.js';
/**
 * Last-resort bounded search for residual crossing clusters that require moving
 * several edges together. Larger graphs use a bounded crossing component as
 * the moving scope, while all nodes and edges remain in the quality context.
 */
export declare const repairBoundedMultiEdgeResidualStrictCrossings: <T extends Edge[]>(edges: T, nodes: Node[], options?: {
    /** Invariants required of every intermediate and returned candidate. */
    acceptCandidate?: (candidate: T) => boolean;
}) => T;
