import type { Edge, Node } from '@xyflow/react';
export declare const repairTerminalHandleHemisphereHairpins: <T extends Edge[]>(edges: T, _nodes: Node[]) => T;
