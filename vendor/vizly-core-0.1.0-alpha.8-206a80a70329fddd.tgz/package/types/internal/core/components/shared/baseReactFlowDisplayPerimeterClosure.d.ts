import type { Edge, Node } from '@xyflow/react';
/** Last bounded geometric closure; publish nothing unless every exact gate passes. */
export declare const repairBaseReactFlowDisplayPerimeterClosure: (edges: Edge[], nodes: Node[]) => Edge[];
