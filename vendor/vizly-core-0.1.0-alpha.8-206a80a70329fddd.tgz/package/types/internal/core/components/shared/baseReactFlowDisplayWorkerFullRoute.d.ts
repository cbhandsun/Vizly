import type { Node } from '@xyflow/react';
import type { BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
import type { BaseReactFlowDisplayEdgesArgs } from './baseReactFlowDisplayFullRouteTypes.js';
import type { DisplayEdgesWorkerRequest, DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerProtocol.js';
import { type DisplayWorkerFinalizationOptions } from './baseReactFlowDisplayWorkerFinalEvaluation.js';
import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
type WorkerFullRouteInput = Readonly<{
    request: Exclude<DisplayEdgesWorkerRequest, {
        operation: 'repair';
    }>;
    commonInput: BaseReactFlowDisplayEdgesArgs;
    escalatedFromInteractive: boolean;
    preparedInteractiveEdges?: BaseReactFlowDisplayEdgesArgs['edges'];
    phaseTrace: DisplayRoutingPhaseTrace[];
    fallbackMetadata: Readonly<{
        affectedEdgeCount?: number;
        fallbackLevel?: 'full';
    }>;
    onPhaseTrace: (trace: DisplayRoutingPhaseTrace) => void;
    onBoundedCandidate?: (report: BaseDisplayBoundedCandidateReport) => void;
    completeResponse: (response: DisplayEdgesWorkerResponse) => DisplayEdgesWorkerResponse;
    finalizeResponse: (response: DisplayEdgesWorkerResponse, nodes: Node[], options: DisplayWorkerFinalizationOptions) => DisplayEdgesWorkerResponse;
}>;
export declare const resolveBaseReactFlowFullRouteClosureSeed: (response: Pick<DisplayEdgesWorkerResponse, 'edges'>, fullRouteEdges: BaseReactFlowDisplayEdgesArgs['edges']) => BaseReactFlowDisplayEdgesArgs['edges'];
/** Owns the expensive full-route branch of one Worker transaction. */
export declare const runBaseReactFlowDisplayWorkerFullRoute: ({ request, commonInput, escalatedFromInteractive, preparedInteractiveEdges, phaseTrace, fallbackMetadata, onPhaseTrace, onBoundedCandidate, completeResponse, finalizeResponse, }: WorkerFullRouteInput) => DisplayEdgesWorkerResponse;
export {};
