import type { Edge, Node } from '@xyflow/react';
/**
 * Final bounded closure for axis-mismatched edges that become repairable only
 * after a same-source peer has established a clean terminal trunk.
 */
export declare const repairResidualSharedSourceTrunkAxisMismatches: <T extends Edge[]>(edges: T, nodes: Node[], maxQualityEvaluations?: number) => T;
