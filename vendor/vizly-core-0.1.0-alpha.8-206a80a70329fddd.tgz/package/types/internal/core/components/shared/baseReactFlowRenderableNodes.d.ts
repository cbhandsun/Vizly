import type { Node, XYPosition } from '@xyflow/react';
export declare const isBaseReactFlowNodeHidden: (node: Node) => boolean;
export declare const normalizeBaseReactFlowRenderableNodes: (nodes: Node[]) => Node[];
export declare const filterBaseReactFlowVisibleNodes: (nodes: Node[]) => Node[];
type BaseReactFlowInternalNode = Node & {
    internals?: {
        positionAbsolute?: XYPosition;
    };
    positionAbsolute?: XYPosition;
};
type BaseReactFlowInternalNodeLookup = Pick<Map<string, BaseReactFlowInternalNode>, 'get'>;
/**
 * Full-quality display routing must use the DOM geometry published by React Flow.
 * Starting the worker from source fallbacks makes the first ResizeObserver update
 * invalidate the request and can repeatedly restart an expensive route.
 */
export declare const areBaseReactFlowInternalNodesReadyForRouting: (nodeIds: string[], nodeLookup: BaseReactFlowInternalNodeLookup | undefined) => boolean;
/**
 * React Flow mutates nodeLookup entries in place when ResizeObserver publishes DOM geometry.
 * Selecting the Map reference therefore misses updates; this primitive signature lets Zustand
 * notify only when routing-relevant measured geometry actually changes.
 */
export declare const computeBaseReactFlowInternalNodeGeometrySignature: (nodeIds: string[], nodeLookup: BaseReactFlowInternalNodeLookup | undefined) => string;
export declare const collectBaseReactFlowInternalNodes: (nodeIds: string[], nodeLookup: BaseReactFlowInternalNodeLookup | undefined) => Node[];
export declare const mergeBaseReactFlowMeasuredNodes: (sourceNodes: Node[], internalNodes: Node[]) => Node[];
export {};
