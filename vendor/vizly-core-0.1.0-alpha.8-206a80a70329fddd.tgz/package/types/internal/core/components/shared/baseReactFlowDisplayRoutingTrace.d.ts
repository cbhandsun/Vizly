export declare const DISPLAY_ROUTING_PHASE_NAMES: readonly ['candidate-validation', 'incremental-closure', 'local-route', 'local-reconnect-seed', 'local-reconnect-setup', 'local-reconnect-path-generation', 'local-reconnect-ranking', 'local-reconnect-strict-scan', 'local-reconnect-candidates', 'local-fast-fallback', 'hard-gate', 'seed', 'seed-interactive', 'seed-interactive-route', 'seed-interactive-normalize', 'seed-interactive-endpoint-seed', 'seed-interactive-trunk-seed', 'seed-interactive-local-seed', 'seed-interactive-crossing-repair', 'seed-interactive-lane-repair', 'seed-interactive-global-route', 'seed-interactive-local-polish', 'seed-interactive-detached-repair', 'seed-interactive-endpoint-final', 'seed-interactive-finish', 'seed-interactive-finish-projection', 'seed-interactive-finish-hard-gate', 'seed-interactive-finish-micro', 'seed-interactive-finish-local', 'seed-interactive-finish-obstacle', 'seed-interactive-finish-commit', 'seed-interactive-terminal-cleanup', 'seed-initial-gate', 'seed-hard-safety', 'seed-local-cleanup', 'seed-strict', 'seed-terminal-axis', 'seed-terminal-gate', 'quality', 'quality-global-route', 'quality-global-route-waypoint', 'quality-global-route-detached', 'quality-topology-seed', 'quality-topology', 'quality-topology-endpoints', 'quality-topology-trunks', 'quality-topology-trunks-initial', 'quality-topology-trunks-dogleg', 'quality-topology-trunks-secondary', 'quality-topology-detached', 'quality-topology-finalize', 'quality-crossing-sweeps', 'quality-crossing-structural', 'quality-crossing-structural-reverse-initial', 'quality-crossing-structural-shared-initial', 'quality-crossing-structural-reverse-final', 'quality-crossing-structural-shared-final', 'quality-crossing-structural-endpoint-lane', 'quality-crossing-global-refine', 'quality-crossing-global-refine-initial', 'quality-crossing-global-refine-fixed-point', 'quality-crossing-global-refine-dogleg', 'quality-crossing-global-refine-context', 'quality-crossing-global-refine-dogleg-initial', 'quality-crossing-global-refine-dogleg-final', 'quality-crossing-early-closure', 'quality-crossing-global-refine-shared-target', 'quality-crossing-global-refine-endpoint', 'quality-crossing-final-candidates', 'quality-crossing-final-prepare', 'quality-crossing-final-prepare-detached', 'quality-crossing-final-prepare-detached-target', 'quality-crossing-final-prepare-detached-overlap', 'quality-crossing-final-prepare-detached-endpoint', 'quality-crossing-final-prepare-dogleg', 'quality-crossing-final-prepare-dogleg-local', 'quality-crossing-final-prepare-dogleg-target', 'quality-crossing-final-prepare-dogleg-overlap', 'quality-crossing-final-prepare-dogleg-endpoint', 'quality-crossing-final-shared-lane', 'quality-crossing-final-shared-target', 'quality-crossing-final-shared-trunk', 'quality-crossing-final-lane-initial', 'quality-crossing-final-lane-final', 'quality-crossing-final-overlap', 'quality-crossing-final-selection', 'quality-crossing-final-candidates-global', 'quality-crossing-final-candidates-post-shared', 'quality-crossing-final-candidates-post-lane', 'quality-strict-closure', 'quality-strict-closure-initial-scan', 'quality-strict-closure-sweep', 'quality-strict-closure-endpoint-lane', 'quality-strict-closure-bypass', 'quality-strict-closure-post-bypass', 'quality-strict-closure-loop', 'quality-polish', 'quality-polish-candidates', 'quality-polish-local', 'quality-polish-detached', 'quality-polish-detached-micro', 'quality-polish-detached-local', 'quality-polish-endpoint', 'quality-polish-micro', 'quality-polish-local-after-endpoint', 'quality-polish-endpoint-after-local', 'quality-polish-selection', 'quality-polish-residual', 'residual-exact', 'residual-loop-shortcut', 'residual-exact-selection', 'residual-polish-selection', 'residual-micro-baseline', 'residual-micro-derivative', 'residual-endpoint-derivative', 'residual-obstacle-selection', 'residual-detached-primary', 'residual-detached-default', 'residual-detached-extended', 'residual-near-parallel', 'quality-polish-obstacle-selection', 'post-render', 'post-render-finalize', 'post-render-soft-closure', 'post-render-micro', 'post-render-soft-quality', 'post-render-soft-risk', 'post-render-soft-obstacle', 'post-render-residual', 'post-render-terminal-gate', 'strict', 'strict-primary', 'strict-primary-overlap', 'strict-primary-endpoint-target', 'strict-primary-crossing', 'strict-primary-cleanup-selection', 'strict-closure', 'terminal', 'terminal-attachment-axis', 'terminal-anchor', 'terminal-polish', 'terminal-finalize', 'terminal-finalize-orthogonal', 'terminal-finalize-axis', 'terminal-finalize-outer-port', 'terminal-finalize-fail-closed', 'terminal-fail-closed-normalize', 'terminal-fail-closed-overlap', 'terminal-fail-closed-local', 'terminal-fail-closed-strict', 'terminal-fail-closed-selection', 'terminal-fail-closed-micro', 'terminal-fail-closed-gate', 'finalizer', 'finalizer-outer-port', 'final-evaluation-context', 'measured-repair', 'measured-repair-normalize', 'measured-repair-lanes', 'measured-repair-obstacle', 'measured-repair-overlap', 'measured-repair-strict', 'measured-repair-terminal', 'measured-repair-fallback', 'measured-repair-selection', 'measured-repair-residual', 'final-clearance', 'final-hard-safety', 'final-endpoint-seed', 'final-endpoint-topology', 'final-endpoint-order', 'final-endpoint-closure', 'final-endpoint-closure-residual', 'final-endpoint-closure-trunks', 'final-endpoint-closure-obstacles', 'final-endpoint-closure-obstacles-post-trunk', 'final-endpoint-closure-obstacles-sibling', 'final-endpoint-closure-obstacles-micro', 'final-endpoint-closure-terminal', 'final-endpoint-closure-terminal-stubs', 'final-endpoint-closure-terminal-micro', 'final-endpoint-closure-commercial', 'final-endpoint-closure-commercial-detour', 'final-endpoint-closure-commercial-hard-gate', 'final-endpoint-closure-commercial-restore-source', 'final-endpoint-closure-commercial-endpoint-order', 'final-endpoint-closure-commercial-source-branches', 'final-safety-closure', 'final-safety-hard-gate', 'final-safety-stubs', 'final-safety-endpoint-order', 'final-safety-passage-order', 'final-safety-repair-baseline', 'final-safety-repair-clearance', 'final-safety-repair-hard', 'final-safety-repair-trunks', 'final-safety-repair-bundles', 'final-safety-repair-corridors', 'final-safety-repair-skirts', 'final-safety-repair-strict', 'final-safety-repair-micro', 'final-safety-repair-stubs', 'final-safety-repair-order', 'final-safety-repair-order-hard', 'final-safety-repair-order-strict', 'final-safety-repair-order-finish', 'final-safety-repair-terminal', 'final-commercial-clearance', 'final-commercial-terminal-preserving', 'final-commercial-terminal-changing', 'final-commercial-source-stairs', 'final-commercial-evaluation', 'final-commercial-safety-closure', 'final-exact-hard-report', 'session-commit'];
export declare const DISPLAY_ROUTING_PHASE_TRACE_LIMIT = 224;
export declare const DISPLAY_ROUTING_PHASE_RESOLUTIONS: readonly ['hit', 'skip', 'accepted', 'rejected', 'fallback'];
export type DisplayRoutingPhaseName = typeof DISPLAY_ROUTING_PHASE_NAMES[number];
export type DisplayRoutingPhaseResolution = typeof DISPLAY_ROUTING_PHASE_RESOLUTIONS[number];
export type DisplayRoutingPhaseMetrics = Readonly<{
    candidateCount?: number;
    evaluationCount?: number;
    cacheHitCount?: number;
    scannedNodeCount?: number;
    scannedSegmentCount?: number;
    scannedEdgePairCount?: number;
    workItemCount?: number;
    processedEdgeCount?: number;
    passCount?: number;
    deduplicatedCandidateCount?: number;
    scalarCandidateCount?: number;
    channelCandidateCount?: number;
    outerLaneCandidateCount?: number;
    tinyLaneCandidateCount?: number;
    obstacleLaneCandidateCount?: number;
    endpointLaneCandidateCount?: number;
    endpointOffsetCandidateCount?: number;
    terminalBridgeCandidateCount?: number;
    returnCandidateCount?: number;
    budgetCount?: number;
    underBudgetCount?: number;
    minimumCandidateCount?: number;
    maximumCandidateCount?: number;
}>;
export type DisplayRoutingPhaseTrace = Readonly<{
    phase: DisplayRoutingPhaseName;
    parentPhase?: DisplayRoutingPhaseName;
    durationMs: number;
    exclusiveDurationMs?: number;
    candidateCount: number;
    changedEdgeCount: number;
    evaluationCount?: number;
    cacheHitCount?: number;
    scannedNodeCount?: number;
    scannedSegmentCount?: number;
    scannedEdgePairCount?: number;
    workItemCount?: number;
    processedEdgeCount?: number;
    passCount?: number;
    deduplicatedCandidateCount?: number;
    scalarCandidateCount?: number;
    channelCandidateCount?: number;
    outerLaneCandidateCount?: number;
    tinyLaneCandidateCount?: number;
    obstacleLaneCandidateCount?: number;
    endpointLaneCandidateCount?: number;
    endpointOffsetCandidateCount?: number;
    terminalBridgeCandidateCount?: number;
    returnCandidateCount?: number;
    budgetCount?: number;
    underBudgetCount?: number;
    minimumCandidateCount?: number;
    maximumCandidateCount?: number;
    resolution: DisplayRoutingPhaseResolution;
}>;
export declare const countChangedRoutingItems: <T>(before: readonly T[], after: readonly T[]) => number;
type DisplayRoutingPhaseTimer = Readonly<{
    finish: (resolution: DisplayRoutingPhaseResolution, changedEdgeCount?: number, metrics?: DisplayRoutingPhaseMetrics) => void;
}>;
export declare const getDisplayRoutingParentPhase: (phase: DisplayRoutingPhaseName) => DisplayRoutingPhaseName | undefined;
/**
 * Adds aggregate-exclusive durations without retaining graph identifiers or
 * relying on trace emission order. Some phases buffer child traces until the
 * parent finishes, so child time is distributed proportionally across repeated
 * parent samples. The aggregate exclusive total remains exact and non-negative.
 */
export declare const finalizeDisplayRoutingPhaseTrace: (traces: readonly DisplayRoutingPhaseTrace[]) => DisplayRoutingPhaseTrace[];
/**
 * Creates one aggregate-only phase measurement. It deliberately never accepts
 * graph IDs, labels, paths, or arbitrary metadata, so traces remain safe to
 * expose through local diagnostics and future telemetry adapters.
 */
export declare const startDisplayRoutingPhaseTrace: ({ phase, parentPhase, candidateCount, onTrace, }: {
    phase: DisplayRoutingPhaseName;
    parentPhase?: DisplayRoutingPhaseName;
    candidateCount: number;
    onTrace?: (trace: DisplayRoutingPhaseTrace) => void;
}) => DisplayRoutingPhaseTimer;
export declare const startFinalEndpointTerminalClosureTrace: (phase: 'final-endpoint-closure-terminal-stubs' | 'final-endpoint-closure-terminal-micro', candidateCount: number, onTrace?: (trace: DisplayRoutingPhaseTrace) => void) => DisplayRoutingPhaseTimer;
export {};
