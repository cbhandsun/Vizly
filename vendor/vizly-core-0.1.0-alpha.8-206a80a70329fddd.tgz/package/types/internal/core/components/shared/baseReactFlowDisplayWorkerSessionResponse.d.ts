import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
import { type DisplayRoutingWorkerSessionState } from './baseReactFlowDisplayWorkerSession.js';
import type { BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
import type { DisplayEdgesWorkerIncrementalRouteRequest, DisplayEdgesWorkerRequest, DisplayEdgesWorkerResolvedIncrementalRouteRequest, DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerProtocol.js';
import type { DisplayRoutingWorkerSpatialSnapshot } from './baseReactFlowDisplayWorkerSpatialSnapshot.js';
type ResolvedDisplayWorkerIncrementalRequest = Readonly<{
    request: DisplayEdgesWorkerResolvedIncrementalRouteRequest;
    baselineSpatialSnapshot: DisplayRoutingWorkerSpatialSnapshot | null;
    exactNextSession: DisplayRoutingWorkerSessionState | null;
}>;
export declare const runDisplayWorkerIncrementalRequest: ({ request, onPhaseTrace, onBoundedCandidate, }: {
    request: DisplayEdgesWorkerIncrementalRouteRequest;
    onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void;
    onBoundedCandidate?: (report: BaseDisplayBoundedCandidateReport) => void;
}) => Readonly<{
    edges: import('@xyflow/react').Edge[] | null;
    affectedEdgeCount: number;
    eligibleEdgeIds: string[];
    hardReport?: BaseDisplayBoundedCandidateReport;
}>;
export declare const resolveDisplayWorkerIncrementalRequest: (request: DisplayEdgesWorkerIncrementalRouteRequest) => ResolvedDisplayWorkerIncrementalRequest | null;
export declare const completeDisplayWorkerResponse: ({ request, response, phaseTrace, }: {
    request: DisplayEdgesWorkerRequest;
    response: DisplayEdgesWorkerResponse;
    phaseTrace: DisplayRoutingPhaseTrace[];
}) => DisplayEdgesWorkerResponse;
export declare const createDisplayWorkerResponseCompleter: (request: DisplayEdgesWorkerRequest, phaseTrace: DisplayRoutingPhaseTrace[]) => ((response: DisplayEdgesWorkerResponse) => DisplayEdgesWorkerResponse);
export {};
