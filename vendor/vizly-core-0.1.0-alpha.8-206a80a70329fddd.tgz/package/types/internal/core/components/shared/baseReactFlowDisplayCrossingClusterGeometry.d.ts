import type { Edge } from '@xyflow/react';
import { type DisplayPoint, type DisplayRect, type DisplaySegment } from './baseReactFlowDisplayGeometry.js';
import type { DisplayCrossingClusterPortSide } from './baseReactFlowDisplayCrossingClusterRanking.js';
export type DisplayCrossingClusterStrictHit = {
    a: DisplaySegment;
    b: DisplaySegment;
};
export declare const displayCrossingClusterSideAxis: (side: DisplayCrossingClusterPortSide) => 'h' | 'v';
export declare const displayCrossingClusterOutwardStub: (anchor: DisplayPoint, side: DisplayCrossingClusterPortSide, clearance: number) => DisplayPoint;
export declare const displayCrossingClusterPointOnSide: (point: DisplayPoint, rect: DisplayRect, side: DisplayCrossingClusterPortSide) => boolean;
export declare const displayCrossingClusterFacingSidePair: (sourceRect: DisplayRect, targetRect: DisplayRect) => [DisplayCrossingClusterPortSide, DisplayCrossingClusterPortSide];
/**
 * Stable, allocation-light path identity used as a deterministic candidate
 * tie-breaker. Keep this byte-for-byte compatible with the legacy map/join
 * representation, including sparse arrays and non-finite numeric values.
 */
export declare const displayCrossingClusterPathSignature: (path: DisplayPoint[]) => string;
export declare const displayCrossingClusterEdgeStateSignature: (edges: readonly Edge[], changedIndexes: readonly number[]) => string;
export declare const firstDisplayCrossingClusterStrictHits: (segments: readonly DisplaySegment[], limit?: number) => DisplayCrossingClusterStrictHit[];
export declare const selectDisplayCrossingClusterOtherSegments: (segments: readonly DisplaySegment[], moverIndex: number) => DisplaySegment[];
export declare const displayCrossingClusterCrossingPairSignature: (segments: readonly DisplaySegment[]) => string;
