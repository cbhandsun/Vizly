import type { Edge, Node } from '@xyflow/react';
import { type DisplayPoint } from './baseReactFlowDisplayGeometry.js';
export type OuterPortSide = 'top' | 'right' | 'bottom' | 'left';
export type OuterPortTransactionCandidate<T extends Edge[]> = {
    edges: T;
    movingEdgeIndex: number;
    ringAxis: 'x' | 'y';
    ringLane: number;
    transitionLane: number;
    quickScore: number;
};
export type OuterPortCandidateOptions = {
    includeStrictCrossings?: boolean;
    minStub?: number;
    maxSeedCandidates?: number;
    maxCandidates?: number;
    maxPortCandidatesPerEdge?: number;
};
export declare const outerPortCandidateQuickScore: (seedQuickScore: number, path: DisplayPoint[]) => number;
export declare const interleaveOuterPortCandidateBuckets: <T>(buckets: T[][], limit: number) => T[];
export declare const buildBoundedOuterPortTransactionCandidates: <T extends Edge[]>(edges: T, nodes: Node[], options?: OuterPortCandidateOptions) => Array<OuterPortTransactionCandidate<T>>;
