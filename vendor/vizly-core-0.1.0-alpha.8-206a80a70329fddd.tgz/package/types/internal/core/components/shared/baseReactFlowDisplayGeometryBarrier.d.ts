export type DisplayGeometryBarrierResolution = 'stable' | 'timed-out';
export type DisplayGeometryBarrierResult = Readonly<{
    resolution: DisplayGeometryBarrierResolution;
    durationMs: number;
    sampleCount: number;
}>;
type CancelDisplayGeometryBarrier = () => void;
export declare const resolveDisplayGeometryBarrierPolicy: (incremental: boolean) => Readonly<{
    minimumStableMs?: number;
    sampleIncrementalMicrotask?: boolean;
    waitForFonts: boolean;
}>;
/**
 * Starts routing as soon as measured geometry is identical when sampled after
 * fonts settle and again on the next observation. Released node drags may use
 * one microtask observation because their position/digest belongs to the
 * already committed React state; a mismatch falls back to frame sampling. A
 * bounded timeout preserves liveness when fonts, ResizeObserver, or layout
 * never become perfectly stable.
 */
export declare const scheduleBaseReactFlowStableGeometry: ({ run, readGeometryIdentity, maximumWaitMs, minimumStableMs, sampleIncrementalMicrotask, waitForFonts, }: {
    run: (result: DisplayGeometryBarrierResult) => void;
    readGeometryIdentity: () => string | null;
    maximumWaitMs?: number;
    minimumStableMs?: number;
    sampleIncrementalMicrotask?: boolean;
    waitForFonts?: boolean;
}) => CancelDisplayGeometryBarrier;
export {};
