import type { Edge, Node } from '@xyflow/react';
export type BaseReactFlowRigidMoveSeed = Readonly<{
    edges: Edge[];
    rigidEdgeIds: string[];
}>;
/** Rigid paths are already translated exactly. Re-read the current mutable
 * closure so later context promotions remain eligible, but never polish a
 * rigid path's terminals as a side effect of finalizing a neighbouring edge.
 */
export declare const getBaseReactFlowNonRigidMutableEdgeIds: (mutableEdgeIds: Iterable<string>, rigidEdgeIds: ReadonlySet<string>) => string[];
/**
 * Translates committed paths whose two terminals moved by the same finite
 * delta. This preserves a hard-clean internal corridor when an entire
 * compound subtree moves; boundary edges remain available for reconnect.
 * The caller must already have proved that edge topology is unchanged.
 */
export declare const createBaseReactFlowRigidMoveSeed: ({ baselineEdges, baselineNodes, nextNodes, changedNodeIds, mutableEdgeIds, }: {
    baselineEdges: Edge[];
    baselineNodes: Node[];
    nextNodes: Node[];
    changedNodeIds: readonly string[];
    mutableEdgeIds: readonly string[];
}) => BaseReactFlowRigidMoveSeed;
