import type { Edge, Node } from '@xyflow/react';
import { type RoutingOnlyDocumentSnapshot } from '../../routing/persistedRoutingCandidate.js';
import { type BaseReactFlowDisplayCommittedSnapshotBaseline } from './baseReactFlowDisplayCommittedSnapshot.js';
export type DocumentSnapshotRoutingOptions = Readonly<{
    enableSmartEdges: boolean;
    smartEdgePadding: number;
    isLargeGraph: boolean;
}>;
export type BaseReactFlowDocumentSnapshotSource = Readonly<{
    read: (nodes: Node[], edges: Edge[]) => RoutingOnlyDocumentSnapshot | null;
}>;
/** A Canvas-scoped export capability, created only after an accepted commit. */
export declare const createBaseReactFlowDocumentSnapshotSource: (baseline: BaseReactFlowDisplayCommittedSnapshotBaseline, options: DocumentSnapshotRoutingOptions) => BaseReactFlowDocumentSnapshotSource | null;
