import type { Edge } from '@xyflow/react';
import { type DisplaySegment } from './baseReactFlowDisplayGeometry.js';
export declare const buildPairedTerminalStrictCandidates: <T extends Edge[]>(edges: T, terminalSegment: DisplaySegment, internalSegment: DisplaySegment) => T[];
