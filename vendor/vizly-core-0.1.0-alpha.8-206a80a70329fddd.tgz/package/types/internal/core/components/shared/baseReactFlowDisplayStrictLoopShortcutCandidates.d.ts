import type { DisplayPoint } from './baseReactFlowDisplayGeometry.js';
/**
 * Removes a clearable interior loop without changing either terminal stub.
 * Obstacle and whole-graph quality checks intentionally stay with the caller.
 */
export declare const buildStrictLoopShortcutCandidates: (inputPath: readonly DisplayPoint[], maxCandidates?: number) => DisplayPoint[][];
