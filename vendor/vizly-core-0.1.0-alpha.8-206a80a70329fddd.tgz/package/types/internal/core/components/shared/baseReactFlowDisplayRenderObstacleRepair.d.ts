import type { Edge, Node } from '@xyflow/react';
import type { DisplaySoftQualityOptions } from './baseReactFlowDisplayEvaluation.js';
import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
export declare const repairDisplayObstacleHitsWithTrace: <T extends Edge[]>({ edges, nodes, layoutDirection, options, onPhaseTrace, }: {
    edges: T;
    nodes: Node[];
    layoutDirection: string;
    options: DisplaySoftQualityOptions;
    onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void;
}) => T;
