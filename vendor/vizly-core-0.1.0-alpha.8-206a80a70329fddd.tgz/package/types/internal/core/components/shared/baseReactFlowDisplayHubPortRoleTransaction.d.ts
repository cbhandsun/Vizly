import type { Edge, Node } from '@xyflow/react';
import { type SharedNodePortRole, type SharedNodePortSide } from './baseReactFlowSharedNodePortRoleRepair.js';
export type HubRole = {
    edgeIndex: number;
    nodeId: string;
    role: SharedNodePortRole;
};
export interface BoundedHubPortRoleTransactionOptions {
    /** Seed edges whose port roles created the small crossing cluster. */
    primaryEdgeIndexes?: readonly number[];
    /** Optional caller-owned object populated without production logging. */
    diagnostics?: BoundedHubPortRoleTransactionDiagnostics;
    /** A production caller lends its existing transaction budget; no nested budget is added. */
    consumeEvaluation?: () => boolean;
    maxQualityEvaluations?: number;
    /** Complete group/trunk and final-report acceptance remains owned by the caller. */
    candidateIsAccepted?: (edges: Edge[]) => boolean;
}
export interface BoundedHubPortRoleTransactionDiagnostics {
    reason?: 'invalid' | 'no-roles' | 'accepted' | 'exhausted';
    primaryEdgeIndexes?: number[];
    roles?: Array<HubRole & {
        candidateCount: number;
        generatedBySide: Record<SharedNodePortSide, number>;
        selectedBySide: Record<SharedNodePortSide, number>;
    }>;
    evaluations?: number;
    pruned?: {
        duplicate: number;
        strict: number;
        hardQuality: number;
        obstacle: number;
    };
    bestPartial?: {
        changedEdgeIndexes: number[];
        obstacleHits: number;
        strictCrossings: number;
        reverseOverlap: number;
        unrelatedOverlap: number;
        unexplainedRelatedOverlap: number;
        shortEndpointStubs: number;
        tinyInteriorDoglegs: number;
        hairpins: number;
        roleSides: Array<HubRole & {
            side: SharedNodePortSide | null;
        }>;
        remainingStrictCompanionIndexes: number[];
    };
}
/**
 * Repairs a small strict-crossing cluster produced by a bounded primary port
 * transaction. Crossing companions are associated with the primary edges by a
 * shared endpoint node; their terminal roles are then searched jointly.
 */
export declare const repairBoundedHubPortRoleTransaction: <T extends Edge[]>(seedEdges: T, nodes: Node[], acceptanceEdges: T, options?: BoundedHubPortRoleTransactionOptions) => T;
