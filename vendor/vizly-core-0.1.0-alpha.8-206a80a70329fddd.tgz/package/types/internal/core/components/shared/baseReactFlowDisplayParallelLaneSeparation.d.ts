import type { Edge, Node } from '@xyflow/react';
/**
 * Builds a conservative route-level separation candidate for same-terminal
 * directed parallel edges. The caller must run the display hard-quality gate
 * before committing the returned candidate.
 */
export declare const separateBaseReactFlowDisplayParallelLanes: <T extends readonly Edge[]>(edges: T) => Edge[];
export declare const selectHardCleanDisplayParallelLaneCandidate: (edges: readonly Edge[], nodes: Node[], eligibleEdgeIds?: ReadonlySet<string>) => Edge[];
