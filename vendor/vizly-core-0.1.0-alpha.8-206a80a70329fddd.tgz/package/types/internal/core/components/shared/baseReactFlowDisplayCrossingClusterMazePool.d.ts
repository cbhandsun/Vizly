import type { Edge, Node } from '@xyflow/react';
import type { DisplaySegment } from './baseReactFlowDisplayGeometry.js';
/** Per-search lazy alternatives, limited to the first two baseline crossing pairs.
 * Geometry is never recomputed for each beam state. Every consumer must evaluate
 * the cached alternative against its current full graph before accepting it.
 */
export declare const createDisplayCrossingClusterMazePool: (edges: Edge[], nodes: Node[], segments: readonly DisplaySegment[]) => {
    edgeIndexes: readonly number[];
    get: (edgeIndex: number) => Edge | null;
};
