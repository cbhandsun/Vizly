import type { Edge, Node as ReactFlowNode } from '@xyflow/react';
import { type EdgePathQualityScore } from '../../strategies/shared/edgeStrictCrossingGuard.js';
import { type BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
import type { BaseReactFlowFullRouteContext } from './baseReactFlowDisplayFullRouteTypes.js';
export declare const repairPostRenderEndpointOrthogonalPaths: (edges: Edge[], nodes: readonly ReactFlowNode[], isHardClean: (candidate: Edge[]) => boolean) => Edge[];
export declare const repairPostRenderNearParallelOverlaps: (edges: Edge[], isHardClean: (candidate: Edge[]) => boolean) => Edge[];
export type BaseReactFlowFullRoutePostRenderResult = {
    kind: 'finalized';
    edges: Edge[];
} | {
    kind: 'continue';
    edges: Edge[];
    quality: EdgePathQualityScore;
    skipInitialStrictOverlapRepair: boolean;
};
export declare const shouldDeferFullRenderPolishForStrictTrunkClosure: (edges: Edge[], nodes: BaseReactFlowFullRouteContext['repairNodes'], qualityReport: BaseDisplayBoundedCandidateReport) => boolean;
export declare const shouldUseBoundedPostRenderResidualRepair: (useBoundedLargeRepair: boolean, mustCloseHardOverlapFirst: boolean) => boolean;
export declare const runBaseReactFlowFullRoutePostRenderPhase: (context: BaseReactFlowFullRouteContext, finalQualityEdges: Edge[], qualityReport: BaseDisplayBoundedCandidateReport) => BaseReactFlowFullRoutePostRenderResult;
