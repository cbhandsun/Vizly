import type { Edge, Node } from '@xyflow/react';
import { type DisplayPoint, type DisplaySegment } from './baseReactFlowDisplayGeometry.js';
export declare const buildTerminalStrictStubPaths: (path: DisplayPoint[], segment: {
    axis: 'h' | 'v';
    segIdx: number;
    a: DisplayPoint;
    b: DisplayPoint;
    edgeIndex?: number;
}, other: {
    axis: 'h' | 'v';
    a: DisplayPoint;
    b: DisplayPoint;
}, edge?: Edge, blockers?: DisplaySegment[]) => DisplayPoint[][];
export declare const repairAnchoredTerminalCrossingCluster: <T extends Edge[]>(edges: T, nodes: Node[]) => T;
export declare const repairTerminalEndpointStrictCrossingStubs: <T extends Edge[]>(edges: T, nodes: Node[], maxQualityEvaluations?: number) => T;
