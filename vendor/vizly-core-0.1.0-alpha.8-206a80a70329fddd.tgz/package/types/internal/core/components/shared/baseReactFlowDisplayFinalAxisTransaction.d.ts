import type { Edge, Node } from '@xyflow/react';
import type { BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
import type { BaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
export type FinalAxisTransactionResult<T extends Edge[]> = {
    finalized: T | null;
    anchoredFallback: T | null;
};
export declare const runFinalAxisTransaction: <T extends Edge[]>({ orthogonalCandidate, attachedReport, evaluationSession, repairNodes, inputSignature, }: {
    attachedCandidate: T;
    orthogonalCandidate: T;
    attachedReport: BaseDisplayBoundedCandidateReport;
    evaluationSession: BaseReactFlowFinalEndpointEvaluation;
    repairNodes: Node[];
    inputSignature: string;
}) => FinalAxisTransactionResult<T>;
