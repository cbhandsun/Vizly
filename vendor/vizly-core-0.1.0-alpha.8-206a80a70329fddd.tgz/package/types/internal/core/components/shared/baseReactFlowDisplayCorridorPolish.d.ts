import type { Edge, Node } from '@xyflow/react';
/** Polish the actual locked geometry once, after all existing repairs finish. */
export declare function polishLockedDisplayCorridors(edges: Edge[], nodes: Node[], eligibleEdgeIds?: ReadonlySet<string>): Edge[];
