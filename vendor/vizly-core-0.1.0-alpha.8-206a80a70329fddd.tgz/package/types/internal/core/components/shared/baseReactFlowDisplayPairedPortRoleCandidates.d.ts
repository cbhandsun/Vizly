import type { Edge } from '@xyflow/react';
import type { DisplayPoint, DisplayRect } from './baseReactFlowDisplayGeometry.js';
/**
 * Builds an atomic two-terminal transaction for feedback edges whose current
 * source and target ports are both occupied by the forward-flow bundle. A
 * one-ended repair cannot be committed because the untouched end remains a
 * declared-axis defect; breadth-first variant ordering keeps every side pair
 * reachable before spending budget on secondary lane variants.
 */
export declare const buildPairedTerminalPortRoleCandidates: ({ edge, path, sourceRect, targetRect, }: {
    edge: Edge;
    path: DisplayPoint[];
    sourceRect: DisplayRect;
    targetRect: DisplayRect;
}) => Edge[];
