import type { Node } from '@xyflow/react';
import type { DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerProtocol.js';
export declare const isCommercialClearanceOnlyFailure: (response: DisplayEdgesWorkerResponse) => boolean;
/**
 * Repairs structural detours and the 48px commercial clearance contract only
 * after all geometry mutation has finished. The exact locked report is the
 * sole commit gate; any crossing, terminal, obstacle, minimum-clearance, or
 * commercial regression rolls the entire candidate back to the exact baseline.
 */
declare const finalizeExactCommercialClearanceCandidate: ({ exactBaseline, repairNodes, eligibleEdgeIds, exactReport, }: Readonly<{
    exactBaseline: DisplayEdgesWorkerResponse;
    repairNodes: Node[];
    eligibleEdgeIds?: ReadonlySet<string>;
    exactReport?: (candidate: DisplayEdgesWorkerResponse, repairNodes: Node[]) => DisplayEdgesWorkerResponse;
}>) => DisplayEdgesWorkerResponse;
export declare const finalizeBaseReactFlowExactCommercialClearance: (args: Parameters<typeof finalizeExactCommercialClearanceCandidate>[0]) => DisplayEdgesWorkerResponse;
export declare const finalizeBaseReactFlowExactCommercialClearanceForStabilization: ({ exactCandidate, repairNodes, eligibleEdgeIds, commercialStabilizationPass, exactReport, }: Readonly<{
    exactCandidate: DisplayEdgesWorkerResponse;
    repairNodes: Node[];
    eligibleEdgeIds?: ReadonlySet<string>;
    commercialStabilizationPass?: number;
    exactReport: (candidate: DisplayEdgesWorkerResponse) => DisplayEdgesWorkerResponse;
}>) => DisplayEdgesWorkerResponse;
export {};
