import { type DisplaySegment } from './baseReactFlowDisplayGeometry.js';
/**
 * Finds the edge component rooted at the first strict crossing, without
 * constructing a graph of every possible segment pair.
 */
export declare const selectDisplayCrossingClusterScope: (segments: readonly DisplaySegment[], maxEdges: number) => number[];
/** Keeps the local search budget separate from the full collision context. */
export declare const resolveDisplayCrossingClusterSearch: (segments: readonly DisplaySegment[], edgeCount: number) => {
    budget: Readonly<{
        maxLocalCandidates: number;
        maxSidePairCandidates: number;
    }>;
    hits: import("./baseReactFlowDisplayCrossingClusterGeometry.js").DisplayCrossingClusterStrictHit[];
} | null;
