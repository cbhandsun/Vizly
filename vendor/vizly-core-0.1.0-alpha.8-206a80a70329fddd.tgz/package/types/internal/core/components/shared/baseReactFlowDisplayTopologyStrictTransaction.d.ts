import type { Edge } from '@xyflow/react';
/**
 * Aligns only a promoted crossing edge with a trusted same-target/source trunk.
 * The changed edge and every terminal handle remain untouched. Callers retain
 * ownership of boundary, exact hard, commercial-clearance, and final gates.
 */
export declare const buildBaseReactFlowTopologyStrictTransactionCandidates: <T extends Edge[]>({ edges, changedEdgeIds, promotedEdgeIds, }: {
    edges: T;
    changedEdgeIds: ReadonlySet<string>;
    promotedEdgeIds: ReadonlySet<string>;
}) => T[];
