import type { Edge, Node } from '@xyflow/react';
export type DisplayEndpointPassageClearanceOptions = Readonly<{
    diagnostics?: DisplayEndpointPassageClearanceDiagnostics;
    eligibleEdgeIds?: ReadonlySet<string>;
}>;
export type DisplayEndpointPassageClearanceDiagnostics = {
    acceptedCandidateCount: number;
    commercialImprovementCount: number;
    generatedShiftCandidateCount: number;
    ladderCandidateCount: number;
    maximumShiftedCrossingCount: number;
    sharedEndpointCandidateCount: number;
    singlePeerCrossingCandidateCount: number;
};
/**
 * Builds bounded clearance transactions around node sides and corners. A safe
 * single-edge shift uses the same gate as a paired shift across a sibling
 * endpoint ladder; no intermediate geometry is observable by the renderer.
 */
export declare const buildBaseReactFlowDisplayEndpointPassageClearanceCandidates: <T extends Edge[]>(edges: T, nodes: Node[], options?: DisplayEndpointPassageClearanceOptions) => T[];
export declare const repairBaseReactFlowDisplayEndpointPassageClearance: <T extends Edge[]>(edges: T, nodes: Node[], options?: DisplayEndpointPassageClearanceOptions) => T;
