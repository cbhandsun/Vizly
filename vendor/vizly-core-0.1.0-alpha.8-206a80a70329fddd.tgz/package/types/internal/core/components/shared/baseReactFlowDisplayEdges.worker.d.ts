import type { BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
import { type DisplayEdgesWorkerRequest, type DisplayEdgesWorkerResponse } from './baseReactFlowDisplayWorkerProtocol.js';
export declare const computeBaseReactFlowDisplayEdgesWorkerResponse: (request: DisplayEdgesWorkerRequest, onBoundedCandidate?: (report: BaseDisplayBoundedCandidateReport) => void) => DisplayEdgesWorkerResponse;
export declare const handleBaseReactFlowDisplayWorkerMessage: (value: unknown, onBoundedCandidate?: (report: BaseDisplayBoundedCandidateReport) => void) => DisplayEdgesWorkerResponse;
