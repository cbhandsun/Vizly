import type { BaseReactFlowDisplayFailure } from './baseReactFlowDisplayFailure.js';
export declare const BaseReactFlowDisplayStatusOverlay: ({ isContainerReady, failure, }: Readonly<{
    isContainerReady: boolean;
    failure: BaseReactFlowDisplayFailure | null;
}>) => import("react").JSX.Element;
