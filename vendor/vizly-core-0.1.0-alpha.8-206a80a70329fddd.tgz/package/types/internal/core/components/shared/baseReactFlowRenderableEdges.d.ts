import type { Edge, Node } from '@xyflow/react';
/**
 * Keeps Worker input aligned with the visible node projection. Collapsed
 * containers retain their hidden business edges in application state, but
 * those edges cannot satisfy terminal gates while their endpoints are absent.
 */
export declare const filterBaseReactFlowRoutableEdges: (edges: Edge[], visibleNodes: readonly Node[]) => Edge[];
export declare const useBaseReactFlowRoutableEdges: (edges: Edge[], visibleNodes: readonly Node[]) => Edge[];
