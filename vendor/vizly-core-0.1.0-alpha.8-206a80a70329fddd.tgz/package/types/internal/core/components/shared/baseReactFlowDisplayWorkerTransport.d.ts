import type { BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
import { type DisplayEdgesWorkerRequest, type DisplayEdgesWorkerResponse, type DisplayEdgesWorkerValidatedRequest } from './baseReactFlowDisplayWorkerProtocol.js';
import { type DisplayEdgesWorkerScope } from './baseReactFlowDisplayWorkerScope.js';
type DisplayWorkerMessageHandler = (value: unknown, onBoundedCandidate?: (report: BaseDisplayBoundedCandidateReport) => void) => DisplayEdgesWorkerResponse;
type DisplayWorkerRequestHandler = (request: DisplayEdgesWorkerValidatedRequest, onBoundedCandidate?: (report: BaseDisplayBoundedCandidateReport) => void) => DisplayEdgesWorkerResponse;
export declare const displayWorkerOperationPublishesBoundedCandidates: (operation: DisplayEdgesWorkerRequest['operation'] | undefined) => boolean;
/** Keeps the untrusted Worker message boundary outside the routing composition root. */
export declare const createBaseReactFlowDisplayWorkerMessageHandler: (handleRequest: DisplayWorkerRequestHandler) => DisplayWorkerMessageHandler;
export declare const installBaseReactFlowDisplayWorkerTransportOnScope: (scope: DisplayEdgesWorkerScope, handleMessage: DisplayWorkerMessageHandler) => void;
export declare const installBaseReactFlowDisplayWorkerTransport: (handleMessage: DisplayWorkerMessageHandler) => void;
export {};
