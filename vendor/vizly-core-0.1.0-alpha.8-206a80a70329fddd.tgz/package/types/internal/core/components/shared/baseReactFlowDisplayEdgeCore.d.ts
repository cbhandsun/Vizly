import type { Edge, Node } from '@xyflow/react';
export { withDisplayAbsolutePositions } from './baseReactFlowAbsolutePositions.js';
export { BASE_DISPLAY_ROUTING_VERSION, baseReactFlowDisplayOutputRouteSignatureMatches, computeBaseDisplayInputSignature, computeBaseReactFlowDisplayCacheSignature, computeBaseReactFlowDisplayEdgeEpoch, computeBaseReactFlowEndpointGeometryKey, computeBaseReactFlowDisplayOutputRouteSignature, isBaseDisplayFinalized, isFinitePoint, markBaseDisplayFinalized, readBaseReactFlowDisplayEdgesCache, readBaseReactFlowDisplayEdgesCacheEntry, writeBaseReactFlowDisplayEdgesCache, } from './baseReactFlowDisplayCache.js';
export type { BaseReactFlowDisplayEdgesCacheEntry } from './baseReactFlowDisplayCache.js';
export { lockFinalDisplayComputedPaths, toBasicDisplayEdge, toCanvasRefEdge, toSmartDisplayEdge, } from './baseReactFlowDisplayEdgeConversions.js';
export { anchorComputedDisplayEdgeEndpoints } from './baseReactFlowDisplayEndpointAnchoring.js';
export { compactOrthogonalPath, synthesizeStableFallbackPath, } from './baseReactFlowDisplayEdgeGeometry.js';
export declare const normalizeBaseEdge: ({ edge, nodeById, displayEdgeEpoch, }: {
    edge: Edge;
    nodeById: Map<string, Node>;
    displayEdgeEpoch: number;
}) => Edge;
export declare const createBaseReactFlowFastDisplayEdges: ({ edges, nodes, enableSmartEdges, smartEdgePadding, isLargeGraph, displayEdgeEpoch, }: {
    edges: Edge[];
    nodes: Node[];
    enableSmartEdges: boolean;
    smartEdgePadding: number;
    isLargeGraph: boolean;
    displayEdgeEpoch: number;
}) => Edge[];
