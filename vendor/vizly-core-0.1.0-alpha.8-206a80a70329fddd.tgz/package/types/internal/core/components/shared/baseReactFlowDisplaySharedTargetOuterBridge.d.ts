import type { Edge, Node } from '@xyflow/react';
import { type DisplaySegment } from './baseReactFlowDisplayGeometry.js';
/**
 * Builds a planar escape for an incoming edge whose route crosses an outgoing
 * edge from the same node. The source-side prefix is retained (so a real source
 * trunk is not split), while the remote leg travels outside the graph and
 * merges into an existing sibling's target trunk.
 */
export declare const buildSharedTargetOuterBridgeCandidates: <T extends Edge[]>(edges: T, incomingSegment: DisplaySegment, outgoingSegment: DisplaySegment, nodes: Node[]) => T[];
