import type { Edge, Node } from '@xyflow/react';
import type { BaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
import { type BaseReactFlowFinalEndpointOrderOptions } from './baseReactFlowDisplayFinalEndpointGate.js';
import { getDisplayComputedPath } from './baseReactFlowDisplayGeometry.js';
type DisplayPath = ReturnType<typeof getDisplayComputedPath>;
export declare const rankCommercialInteriorShortcutCandidates: (edge: Edge, path: DisplayPath, nodes: Node[], includeCorners?: boolean) => DisplayPath[];
export declare const repairTerminalPreservingOuterStairs: <T extends Edge[]>(edges: T, nodes: Node[], options: BaseReactFlowFinalEndpointOrderOptions, evaluation: BaseReactFlowFinalEndpointEvaluation) => T;
export {};
