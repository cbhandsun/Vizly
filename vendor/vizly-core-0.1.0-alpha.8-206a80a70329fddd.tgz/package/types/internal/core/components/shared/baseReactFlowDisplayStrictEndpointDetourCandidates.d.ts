import { type DisplayPoint, type DisplaySegment } from './baseReactFlowDisplayGeometry.js';
/**
 * Builds a small rectangular escape at either end of a crossing segment.
 * The escape moves outside the competing segment only until it has passed
 * the crossing coordinate, then rejoins the original lane. Endpoints and
 * declared terminal stubs remain untouched.
 */
export declare const buildStrictEndpointDetourCandidates: (path: readonly DisplayPoint[], segment: DisplaySegment, other: DisplaySegment, gap?: number) => DisplayPoint[][];
