import type { SameSideEndpointTrunkIdentity } from '../../strategies/shared/edgeFinalSameSideEndpointOrderRepair.js';
import type { BaseReactFlowFinalEndpointOrderOptions } from './baseReactFlowDisplayFinalEndpointGate.js';
import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
export declare const exactTrueTrunkSignature: (trunks: readonly SameSideEndpointTrunkIdentity[]) => string;
export declare const traceSkippedFinalEndpointPhases: (candidateCount: number, onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void, includeSeed?: boolean, parentPhase?: BaseReactFlowFinalEndpointOrderOptions['traceParentPhase']) => void;
