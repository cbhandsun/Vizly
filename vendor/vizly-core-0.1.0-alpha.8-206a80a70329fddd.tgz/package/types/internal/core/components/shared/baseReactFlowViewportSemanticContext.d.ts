export type BaseReactFlowViewportSemanticSync = (viewport: {
    x: number;
    y: number;
    zoom: number;
}) => void;
export declare const BaseReactFlowViewportSemanticContext: import("react").Context<BaseReactFlowViewportSemanticSync | null>;
export declare const useBaseReactFlowViewportSemanticSync: () => BaseReactFlowViewportSemanticSync | null;
