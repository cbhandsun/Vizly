import type { Edge, Node } from '@xyflow/react';
import { type DisplaySegment } from './baseReactFlowDisplayGeometry.js';
export { collectExactThresholdResidualPairs, type DisplayExactThresholdResidualPair, } from './baseReactFlowDisplayParallelOverlapGeometry.js';
export declare const repairBoundedReverseParallelOverlapsWithCandidates: <T extends Edge[]>(edges: T, nodes: Node[], maxQualityEvaluations: number, buildOppositeRoleCandidates: (edges: T, nodes: Node[], first: DisplaySegment, second: DisplaySegment) => T[]) => T;
/**
 * Separates the final interior lane of two unrelated opposite-flow paths when
 * a terminal-aware repair cannot act on either endpoint. Only one internal
 * segment moves, and the whole-graph obstacle and hard-quality gates must stay
 * non-regressing.
 */
export declare const repairResidualOppositeInteriorLaneOverlaps: <T extends Edge[]>(edges: T, nodes: Node[], maxQualityEvaluations?: number) => T;
