import type { Edge, Node } from '@xyflow/react';
export type DisplayContainerBoundarySkimRepairOptions = Readonly<{
    eligibleEdgeIds?: ReadonlySet<string>;
    maxPasses?: number;
    validateCandidate?: (context: Readonly<{
        baselineEdges: readonly Edge[];
        candidateEdges: readonly Edge[];
        changedEdgeIndex: number;
        baselineSkimLength: number;
        candidateSkimLength: number;
    }>) => boolean;
}>;
export declare const repairDisplayContainerBoundarySkims: <T extends Edge[]>(edges: T, nodes: readonly Node[], options?: DisplayContainerBoundarySkimRepairOptions) => T;
