import type { Edge, Node } from '@xyflow/react';
import type { BaseReactFlowFinalEndpointEvaluation } from './baseReactFlowDisplayFinalEndpointEvaluation.js';
export declare const repairFinalSafetyRenderSafeEndpointStubs: <T extends Edge[]>(edges: T, nodes: Node[], evaluation: BaseReactFlowFinalEndpointEvaluation | undefined, allowStrictFallback: boolean) => T;
