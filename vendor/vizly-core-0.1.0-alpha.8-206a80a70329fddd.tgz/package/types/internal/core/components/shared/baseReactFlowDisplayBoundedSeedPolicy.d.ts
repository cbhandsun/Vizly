export type BoundedSeedPolicyInput = Readonly<{
    skipFullRouteFallback: boolean | undefined;
    edgeCount: number;
    nodeCount: number;
}>;
export declare const getInteractiveGlobalCandidateEdgeBudget: (edgeCount: number, deferOuterObstacleRepair: boolean) => number | undefined;
/**
 * Large graphs already receive a comprehensive FullRoute pass immediately
 * after this bounded seed. Avoid repeating the same global edge-pair search in
 * both phases when the bounded terminal-safe seed is not yet hard-clean.
 */
export declare const shouldStopAfterBoundedTerminalLaneSeed: ({ skipFullRouteFallback, edgeCount, nodeCount, }: BoundedSeedPolicyInput) => boolean;
