import type { Edge, Node } from '@xyflow/react';
import { DISPLAY_DETACHED_OVERLAP_REPAIR_OPTIONS } from './baseReactFlowDisplayOverlapRepair.js';
import type { DisplayQualityGlobalRefineSession } from './baseReactFlowDisplayQualityGlobalRefine.js';
import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
export declare const selectDisplayQualityInitialDetachedOverlapOptions: (useBoundedLargeRepair: boolean) => typeof DISPLAY_DETACHED_OVERLAP_REPAIR_OPTIONS;
export declare const selectDisplayQualityFinalOverlapOptions: (useBoundedLargeRepair: boolean, edgeCount: number) => typeof DISPLAY_DETACHED_OVERLAP_REPAIR_OPTIONS;
export declare const createDisplayQualityCrossingCandidates: ({ edges, nodes, repairDoglegs, globalRefineSession, useBoundedLargeRepair, onPhaseTrace, }: Readonly<{
    edges: Edge[];
    nodes: Node[];
    repairDoglegs: (edges: Edge[]) => Edge[];
    globalRefineSession: DisplayQualityGlobalRefineSession;
    useBoundedLargeRepair: boolean;
    onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void;
}>) => Edge[];
