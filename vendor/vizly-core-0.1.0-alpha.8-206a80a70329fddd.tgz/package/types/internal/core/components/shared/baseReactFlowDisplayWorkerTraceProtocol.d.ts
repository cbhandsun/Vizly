import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
export declare const isDisplayRoutingPhaseTrace: (value: unknown) => value is DisplayRoutingPhaseTrace;
export declare const parseDisplayRoutingPhaseTrace: (value: unknown) => DisplayRoutingPhaseTrace[] | null;
