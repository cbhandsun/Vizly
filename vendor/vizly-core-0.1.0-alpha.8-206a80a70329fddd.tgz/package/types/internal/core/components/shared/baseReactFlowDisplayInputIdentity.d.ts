import type { Edge, Node } from '@xyflow/react';
export type BaseReactFlowDisplayInputIdentity = {
    nodes: Node[];
    edges: Edge[];
    enableSmartEdges: boolean;
    smartEdgePadding: number;
    isLargeGraph: boolean;
};
type IdentityFeed = (value: unknown) => void;
/**
 * Visits the exact normalized fields used to identify a display-routing input.
 * Both the compact cache key and the independent collision guard consume this
 * visitor so they cannot silently drift to different input contracts.
 */
export declare const visitBaseReactFlowDisplayInputIdentity: ({ nodes, edges, enableSmartEdges, smartEdgePadding, isLargeGraph, }: BaseReactFlowDisplayInputIdentity, feed: IdentityFeed) => void;
export type BaseReactFlowDisplayInputIdentityBundle = {
    cacheSignature: string;
    geometryDigest: string;
};
/**
 * Computes the compact cache lookup key and its independent collision guard in
 * one traversal. Large diagrams update their geometry on every drag frame; a
 * shared visit avoids parsing every node, edge, and computed path twice.
 */
export declare const computeBaseReactFlowDisplayInputIdentityBundle: (input: BaseReactFlowDisplayInputIdentity) => BaseReactFlowDisplayInputIdentityBundle;
/** A fast independent 128-bit guard for the 32-bit cache lookup key. */
export declare const computeBaseReactFlowDisplayGeometryDigest: (input: BaseReactFlowDisplayInputIdentity) => string;
export declare const isBaseReactFlowDisplayGeometryDigest: (value: unknown) => value is string;
export {};
