import type { Edge, Node } from '@xyflow/react';
/**
 * Closes the bounded endpoint-only defects that can remain on the facade-
 * equivalent Worker candidate. The transaction is invisible unless the final
 * geometry satisfies hard, commercial-clearance, and render-stub gates.
 */
export declare const closeBaseReactFlowDisplayWorkerEndpointContract: (edges: Edge[], nodes: Node[]) => Edge[];
