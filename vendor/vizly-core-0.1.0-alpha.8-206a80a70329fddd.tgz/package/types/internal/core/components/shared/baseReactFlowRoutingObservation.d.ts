type JobStage = 'job-started' | 'job-cancelled' | 'job-finished' | 'failed' | 'commit-accepted' | 'render-committed' | 'render-frame-observed';
type RequestStage = 'worker-requested' | 'worker-available' | 'worker-post-requested' | 'worker-response-validated' | 'worker-request-settled';
type Entry = Readonly<{
    stage: JobStage | RequestStage;
    requestOrdinal: number | null;
    elapsedMs: number | null;
}>;
/** Keys are existing job signals/accepted objects, never document identifiers. */
export declare const startRoutingObservation: (signal: AbortSignal, owner: 'display' | 'layout', now?: () => number) => void;
export declare const recordRoutingObservation: (key: object, stage: JobStage) => void;
/** Each request closure keeps its ordinal even when responses interleave. */
export declare const beginRoutingRequestObservation: (signal?: AbortSignal) => ((stage: RequestStage) => void);
export declare const bindRoutingObservation: (source: object, target: object) => void;
export declare const observeRoutingRenderFrame: (key: object, request: (callback: () => void) => number, cancel: (id: number) => void) => (() => void);
/** Only generated fixed codes/numbers leave the weak, in-memory journal. */
export declare const readRoutingObservation: (key: object) => {
    schema: 'vizly-routing-observation-v1';
    owner: "display" | "layout";
    truncated: boolean;
    entries: {
        stage: JobStage | RequestStage;
        requestOrdinal: number | null;
        elapsedMs: number | null;
    }[];
} | null;
export type RoutingObservationCheckpoint = Readonly<{
    schema: 'vizly-routing-observation-checkpoint-v1';
    owner: 'display' | 'layout';
    lastStage: Entry['stage'];
    previousStage: Entry['stage'] | null;
    lastRequestOrdinal: number | null;
    elapsedMs: number | null;
    eventCount: number;
    truncated: boolean;
}>;
export declare const summarizeRoutingObservationCheckpoint: (key: object) => RoutingObservationCheckpoint | null;
export {};
