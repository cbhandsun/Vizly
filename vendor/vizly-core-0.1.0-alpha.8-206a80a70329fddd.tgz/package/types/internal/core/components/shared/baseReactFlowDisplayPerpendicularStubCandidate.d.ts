import type { Edge, Node } from '@xyflow/react';
/** A short arrival can require shortening the opposite shared stem when both
 * terminals are parallel. A free perpendicular port offers a one-bend candidate
 * that retains the remote anchor and extends, rather than shortens, that stem.
 * This only generates candidates; the caller must apply its exact graph gate.
 */
export declare const buildPerpendicularTerminalStubCandidates: (edge: Edge, nodes: Node[], minimumStub: number) => Edge[];
