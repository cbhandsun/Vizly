declare const workerCodes: {
    readonly 'display-edge-worker-unavailable': 'worker-creation';
    readonly 'display-edge-worker-post-failed': 'request-post';
    readonly 'display-edge-worker-message-error': 'response-decode';
    readonly 'display-edge-worker-invalid-response': 'response-validation';
    readonly 'display-edge-worker-commit-receipt-mismatch': 'response-validation';
    readonly 'display-edge-worker-resolution-mismatch': 'response-validation';
    readonly 'display-edge-worker-candidate-mismatch': 'response-validation';
    readonly 'display-edge-worker-empty-response': 'response-validation';
    readonly 'display-edge-worker-error': 'worker-runtime';
    readonly 'display-edge-worker-failed': 'worker-execution';
    readonly 'display-edge-worker-timeout': 'worker-wait';
};
export type DisplayWorkerFailureCode = keyof typeof workerCodes;
/** Only exact client/protocol codes are exportable; never parse arbitrary text. */
export declare const classifyDisplayWorkerFailureCode: (error: unknown) => DisplayWorkerFailureCode | undefined;
/** Content-free user export, independent of graph identity and debug globals. */
export declare const summarizeDisplayRoutingFailure: (value: unknown) => {
    schema: string;
    reason: string;
    stage: string;
    code: "display-edge-worker-candidate-mismatch" | "display-edge-worker-commit-receipt-mismatch" | "display-edge-worker-empty-response" | "display-edge-worker-error" | "display-edge-worker-failed" | "display-edge-worker-invalid-response" | "display-edge-worker-message-error" | "display-edge-worker-post-failed" | "display-edge-worker-resolution-mismatch" | "display-edge-worker-timeout" | "display-edge-worker-unavailable" | null;
    checkpoint?: Readonly<{
        schema: 'vizly-routing-observation-checkpoint-v1';
        owner: 'display' | 'layout';
        lastStage: ("commit-accepted" | "failed" | "job-cancelled" | "job-finished" | "job-started" | "render-committed" | "render-frame-observed") | ("worker-available" | "worker-post-requested" | "worker-request-settled" | "worker-requested" | "worker-response-validated");
        previousStage: (("commit-accepted" | "failed" | "job-cancelled" | "job-finished" | "job-started" | "render-committed" | "render-frame-observed") | ("worker-available" | "worker-post-requested" | "worker-request-settled" | "worker-requested" | "worker-response-validated")) | null;
        lastRequestOrdinal: number | null;
        elapsedMs: number | null;
        eventCount: number;
        truncated: boolean;
    }> | undefined;
    observation?: {
        schema: 'vizly-routing-observation-v1';
        owner: "display" | "layout";
        truncated: boolean;
        entries: {
            stage: ("commit-accepted" | "failed" | "job-cancelled" | "job-finished" | "job-started" | "render-committed" | "render-frame-observed") | ("worker-available" | "worker-post-requested" | "worker-request-settled" | "worker-requested" | "worker-response-validated");
            requestOrdinal: number | null;
            elapsedMs: number | null;
        }[];
    } | undefined;
} | null;
export {};
