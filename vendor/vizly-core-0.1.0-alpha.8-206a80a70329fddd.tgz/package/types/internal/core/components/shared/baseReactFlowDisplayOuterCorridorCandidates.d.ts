import type { Edge, Node } from '@xyflow/react';
import { type DisplayPoint, type DisplayRect } from './baseReactFlowDisplayGeometry.js';
import type { OuterPortTransactionCandidate } from './baseReactFlowDisplayOuterPortCandidates.js';
/** An exterior ring can still have its return ray blocked by a downstream
 * node. Derive two escape corridors from that ray's complete obstacle wall,
 * rather than requiring a clean local port path before considering the ring. */
export declare const buildOuterTerminalCorridorPaths: (source: DisplayPoint, sourceStub: DisplayPoint, target: DisplayPoint, targetStub: DisplayPoint, ring: DisplayPoint, obstacles: readonly DisplayRect[], clearance: number) => Array<{
    path: DisplayPoint[];
    ringAxis: 'x' | 'y';
    transitionLane: number;
}>;
/** Fallback only for the selected residual pair. At most two edges, sixteen
 * side pairs, four ring corners and four wall corridors are considered; the
 * caller's existing exact-evaluation cap is not increased. */
export declare const buildBoundedOuterCorridorCandidates: <T extends Edge[]>(edges: T, nodes: Node[], movingIndexes: readonly number[], minStub: number, limit: number) => Array<OuterPortTransactionCandidate<T>>;
