import type { Edge, Node } from '@xyflow/react';
export declare const buildTrueTrunkCrossingSkirtCandidates: (edges: Edge[], nodes: Node[], eligibleEdgeIds?: ReadonlySet<string>) => Edge[][];
