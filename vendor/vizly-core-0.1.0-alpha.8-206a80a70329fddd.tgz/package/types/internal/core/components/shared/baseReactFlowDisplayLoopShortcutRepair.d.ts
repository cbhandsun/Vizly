import type { Edge, Node } from '@xyflow/react';
import { type DisplayPoint } from './baseReactFlowDisplayGeometry.js';
import { type DisplayLoopShortcutRepairDiagnostics } from './baseReactFlowDisplayLoopShortcutQuality.js';
export { buildStrictBlockingTerminalLaneShiftVariants } from './baseReactFlowDisplayLoopShortcutCandidates.js';
export { buildTerminalPreservingInteriorShortcutCandidates } from './baseReactFlowDisplayInteriorShortcutCandidates.js';
export { createDisplayLoopShortcutRepairDiagnostics, } from './baseReactFlowDisplayLoopShortcutQuality.js';
export type { DisplayLoopShortcutRepairDiagnostics, } from './baseReactFlowDisplayLoopShortcutQuality.js';
export declare const buildTerminalPreservingDirectShortcutCandidates: (path: DisplayPoint[]) => DisplayPoint[][];
/**
 * Removes a bounded interior loop before the more expensive residual searches.
 * Endpoint stubs are structurally preserved by the candidate builder; the
 * transaction is still accepted only after exact whole-graph quality,
 * obstacle, and terminal validation.
 */
export declare const repairDisplayLoopShortcuts: <T extends Edge[]>(edges: T, nodes: Node[], maxQualityEvaluations?: number, closeStrictCandidate?: (candidate: T) => T, diagnostics?: DisplayLoopShortcutRepairDiagnostics) => T;
