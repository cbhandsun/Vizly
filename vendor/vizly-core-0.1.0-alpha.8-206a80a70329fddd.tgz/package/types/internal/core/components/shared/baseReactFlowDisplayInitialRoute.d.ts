import type { Edge, Node } from '@xyflow/react';
/** Ports and their outward corridors are one initial routing decision. */
export declare const seedObstacleAwareDisplayRoutes: (edges: Edge[], inputNodes: Node[]) => Edge[];
