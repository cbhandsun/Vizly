import type { Edge } from '@xyflow/react';
export declare const adjacentEndpointCrossingBaseline: (edges: Edge[]) => ReadonlySet<string>;
/** Requires the exact shared-trunk fragment that will appear in SVG to paint an arc. */
export declare const newAdjacentEndpointCrossingsArePainted: (edges: Edge[], baselineCrossings: ReadonlySet<string>) => boolean;
