import type { Edge, Node } from '@xyflow/react';
import { type BaseReactFlowDisplayInputIdentityBundle } from './baseReactFlowDisplayInputIdentity.js';
/**
 * Avoids rebuilding full-graph routing identities while a node is moving.
 * The drag fallback owns edge rendering until the gesture ends, so those
 * identities are intentionally recomputed only after drop.
 */
export declare const resolveBaseReactFlowRoutingComputation: <T>({ isNodeDragging, pausedValue, compute, }: {
    isNodeDragging: boolean;
    pausedValue: T;
    compute: () => T;
}) => T;
export declare const resolveBaseReactFlowDragAwareDisplayEpoch: ({ isNodeDragging, nodes, edges, }: {
    isNodeDragging: boolean;
    nodes: Node[];
    edges: Edge[];
}) => number;
export declare const resolveBaseReactFlowDragAwareInputIdentity: ({ isNodeDragging, nodes, edges, enableSmartEdges, smartEdgePadding, isLargeGraph, }: {
    isNodeDragging: boolean;
    nodes: Node[];
    edges: Edge[];
    enableSmartEdges: boolean;
    smartEdgePadding: number;
    isLargeGraph: boolean;
}) => BaseReactFlowDisplayInputIdentityBundle;
