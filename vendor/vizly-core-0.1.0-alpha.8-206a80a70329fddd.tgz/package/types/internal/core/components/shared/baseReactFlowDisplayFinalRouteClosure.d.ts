import type { Edge } from '@xyflow/react';
import { type BaseDisplayBoundedCandidateReport } from './baseReactFlowDisplayEvaluation.js';
import { type BaseReactFlowDisplayExactReport } from './baseReactFlowDisplayFinalizer.js';
import type { BaseReactFlowDisplayEdgesArgs } from './baseReactFlowDisplayFullRouteTypes.js';
/**
 * Closes the final display contract after the full-route seed has completed.
 * This is Worker-owned routing logic; renderers only consume its committed
 * geometry and never repeat these repairs on the main thread.
 */
export declare const closeBaseReactFlowFinalDisplayRoute: ({ args, routedEdges, repairNodes, inputSignature, exactReport, }: {
    args: BaseReactFlowDisplayEdgesArgs;
    routedEdges: Edge[];
    repairNodes: import('@xyflow/react').Node[];
    inputSignature: string;
    exactReport?: BaseReactFlowDisplayExactReport;
}) => Edge[];
export type { BaseDisplayBoundedCandidateReport };
