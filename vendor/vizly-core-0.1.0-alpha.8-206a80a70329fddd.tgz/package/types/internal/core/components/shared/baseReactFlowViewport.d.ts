type Viewport = {
    x: number;
    y: number;
    zoom: number;
};
import { resolveEdgeLabelScale } from '../../rendering/edgeLabelScale.js';
type ReactFlowViewportInstance = {
    setViewport: (viewport: Viewport) => void;
};
export type BaseReactFlowInitialFitMode = 'fitWidthTop' | 'fitAll' | 'none' | 'restoreOrFitAll';
export declare const isBaseReactFlowZoomedOut: (viewport: Viewport) => boolean;
export declare const isBaseReactFlowFarZoomedOut: (viewport: Viewport) => boolean;
export declare const resolveBaseReactFlowContainerClassName: ({ baseClassName, isLayoutStable, zoomedOut, farZoomedOut, }: {
    baseClassName: string;
    isLayoutStable: boolean;
    zoomedOut: boolean;
    farZoomedOut?: boolean;
}) => string;
export declare const resolveBaseReactFlowEdgeLabelScale: typeof resolveEdgeLabelScale;
export declare const syncBaseReactFlowZoomClass: ({ container, viewport, zoomedOutClassName, farZoomedOutClassName, }: {
    container: HTMLElement | null;
    viewport: Viewport;
    zoomedOutClassName?: string;
    farZoomedOutClassName?: string;
}) => void;
export declare const restoreBaseReactFlowViewportOnInit: ({ instance, fitMode, lastViewport, }: {
    instance: ReactFlowViewportInstance;
    fitMode: BaseReactFlowInitialFitMode;
    lastViewport: Viewport | null | undefined;
}) => boolean;
export declare const isUsableBaseReactFlowViewport: (viewport: Viewport | null | undefined) => viewport is Viewport;
/**
 * `restoreOrFitAll` is resolved once per mounted canvas. This prevents an
 * initial blank canvas without turning subsequent node/layout changes into a
 * permanently pinned fit operation that would overwrite the user's viewport.
 */
export declare const resolveBaseReactFlowInitialFitMode: ({ fitMode, lastViewport, }: {
    fitMode: BaseReactFlowInitialFitMode;
    lastViewport: Viewport | null | undefined;
}) => 'fitWidthTop' | 'fitAll' | 'none';
export declare const createBaseReactFlowExportStateHandlers: ({ setHidden, }: {
    setHidden: (hidden: boolean) => void;
}) => {
    onStart: () => void;
    onStop: () => void;
};
/** Own the complete export visibility subscription so canvas cleanup cannot
 * leave a stale listener writing React state after the canvas is unmounted. */
export declare const bindBaseReactFlowExportBackgroundVisibility: ({ target, setHidden, }: {
    target: Pick<EventTarget, 'addEventListener' | 'removeEventListener'>;
    setHidden: (hidden: boolean) => void;
}) => (() => void);
export {};
