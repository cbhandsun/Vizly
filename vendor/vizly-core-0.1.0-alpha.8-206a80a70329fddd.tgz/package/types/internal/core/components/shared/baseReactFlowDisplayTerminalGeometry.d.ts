import type { Edge, Node } from '@xyflow/react';
import { type DisplayPoint, type DisplayRect } from './baseReactFlowDisplayGeometry.js';
export { inferTerminalGeometrySide } from './baseReactFlowDisplayTerminalSide.js';
export declare const MIN_DISPLAY_ENDPOINT_STUB = 48;
export declare const buildShortTerminalStaircaseTranslationCandidate: (path: DisplayPoint[], role: 'source' | 'target', side: 'top' | 'bottom' | 'left' | 'right') => DisplayPoint[] | null;
export declare const adaptiveDetachedTerminalStub: (edges: Edge[], nodes: Node[], edgeIndex: number, path: DisplayPoint[], role: 'source' | 'target', rect: DisplayRect, side: 'top' | 'bottom' | 'left' | 'right') => number;
export declare const detachedTerminalConnectorLanes: (edge: Edge, nodes: Node[], path: DisplayPoint[], role: 'source' | 'target', rect: DisplayRect, side: 'top' | 'bottom' | 'left' | 'right', stubLength: number) => number[];
export declare const buildDeclaredTerminalInsetNudgeCandidates: (path: DisplayPoint[], role: 'source' | 'target', rect: DisplayRect, side: 'top' | 'bottom' | 'left' | 'right') => DisplayPoint[][];
