import type { Edge, Node } from '@xyflow/react';
export { getInteractiveGlobalCandidateEdgeBudget } from './baseReactFlowDisplayBoundedSeedPolicy.js';
import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
type QualitySeedCandidateChooser<T extends Edge[]> = (...candidates: T[]) => T;
export declare const chooseDistinctQualitySeedCandidate: <T extends Edge[]>(candidates: readonly T[], choose: QualitySeedCandidateChooser<T>) => T;
/** Avoiding a crossing cannot justify traversing a node, including the route's
 * own source or target. Reuse the routing collision model before soft ranking. */
export declare const chooseObstacleSafeQualitySeedCandidate: (nodes: Node[], candidates: Edge[][]) => Edge[];
export declare const createFastDisplayQualityEdges: (normalizedEdges: Edge[], repairNodes: Node[]) => Edge[];
export declare const createBaseReactFlowInteractiveDisplayEdges: ({ edges, nodes, enableSmartEdges, smartEdgePadding, isLargeGraph, displayEdgeEpoch, seedUnroutedFlowEdges, deferOuterObstacleRepair, onPhaseTrace, }: {
    edges: Edge[];
    nodes: Node[];
    enableSmartEdges: boolean;
    smartEdgePadding: number;
    isLargeGraph: boolean;
    displayEdgeEpoch: number;
    seedUnroutedFlowEdges?: boolean;
    deferOuterObstacleRepair?: boolean;
    onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void;
}) => Edge[];
