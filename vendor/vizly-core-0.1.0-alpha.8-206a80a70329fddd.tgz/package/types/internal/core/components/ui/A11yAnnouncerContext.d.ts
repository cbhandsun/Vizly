export interface A11yContextValue {
    announce: (message: string, priority?: 'polite' | 'assertive') => void;
}
export declare const A11yContext: import("react").Context<A11yContextValue>;
export declare function useA11yAnnounce(): A11yContextValue;
