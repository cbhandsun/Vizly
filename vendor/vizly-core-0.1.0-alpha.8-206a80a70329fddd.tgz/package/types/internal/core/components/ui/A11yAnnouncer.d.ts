import React from 'react';
/**
 * A11yAnnouncer — Screen Reader 公告组件
 *
 * 使用 ARIA live region 向 Screen Reader 推送操作反馈。
 * 替代 message.success/info 等视觉 toasts 为听觉反馈。
 *
 * 用法：
 * 1. 在 App 层包装 <A11yAnnouncerProvider>
 * 2. 在任意组件中 const { announce } = useA11yAnnounce();
 * 3. announce('已复制 3 个节点');
 */
export declare const A11yAnnouncerProvider: React.FC<{
    children: React.ReactNode;
}>;
