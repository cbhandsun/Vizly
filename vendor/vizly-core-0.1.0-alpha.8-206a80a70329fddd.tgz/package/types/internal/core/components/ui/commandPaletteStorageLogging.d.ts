export declare const logCommandPaletteStorageFailure: (action: string, error: unknown) => void;
