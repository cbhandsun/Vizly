import React from 'react';
import type { CommandItem } from '../../types/plugin.js';
interface CommandPaletteProps {
    open: boolean;
    onClose: () => void;
    onDismiss?: () => void;
    items: CommandItem[];
    getContainer?: () => HTMLElement;
}
export declare const CommandPalette: React.FC<CommandPaletteProps>;
export {};
