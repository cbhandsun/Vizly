import React from 'react';
/**
 * 协同用户头像列表 (Phase 9)
 */
export declare const CollaborationAvatars: React.FC;
