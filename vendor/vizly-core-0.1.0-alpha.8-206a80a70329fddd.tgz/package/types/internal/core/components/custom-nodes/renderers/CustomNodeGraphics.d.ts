import React from 'react';
export interface CustomNodeGraphicsProps {
    id: string;
    data: Record<string, unknown> & {
        icon?: unknown;
        domainClass?: string;
        baseZIndex?: number;
        description?: string;
        isLegend?: boolean;
    };
    selected: boolean;
    setHovered: (hovered: boolean) => void;
    isEditing: boolean;
    editText: string;
    setEditText: (text: string) => void;
    handleDoubleClick: (e: React.MouseEvent) => void;
    handleBlur: () => void;
    handleKeyDown: (e: React.KeyboardEvent<HTMLTextAreaElement>) => void;
    debugEnabled: boolean;
    domainKey: string;
    themeMain: string;
    themeBorder: string;
    containerStyle: React.CSSProperties;
    contentStyle: React.CSSProperties;
    textContainerStyle: React.CSSProperties;
    getLineStyle: (line: string) => React.CSSProperties;
    accentBarProps: React.CSSProperties | null;
    statusStripeProps: React.CSSProperties | null;
    /** 如果用户未设置图标，由 hook 追传过来的自动推断图标 */
    resolvedIcon?: string | null;
}
export declare const CustomNodeGraphics: React.NamedExoticComponent<CustomNodeGraphicsProps>;
