import React from 'react';
import { EdgeProps } from '@xyflow/react';
/**
 * 架构图语义化连线类型定义
 * - sync: 同步调用（实线 + 实心箭头）
 * - async: 异步消息（虚线 + 实心箭头）
 * - dataflow: 数据流（粗线 + 双向标记可选）
 * - dependency: 松耦合依赖（点线 + 空心箭头）
 */
export type ArchEdgeSemantic = 'sync' | 'async' | 'dataflow' | 'dependency';
declare const SEMANTIC_STYLES: Record<ArchEdgeSemantic, React.CSSProperties>;
declare const SEMANTIC_LABELS: Record<ArchEdgeSemantic, string>;
declare const _default: React.NamedExoticComponent<EdgeProps>;
export default _default;
export { SEMANTIC_STYLES, SEMANTIC_LABELS };
