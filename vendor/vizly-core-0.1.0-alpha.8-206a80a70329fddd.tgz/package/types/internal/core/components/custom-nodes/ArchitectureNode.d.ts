import React from 'react';
import { NodeProps, Node } from '@xyflow/react';
export type ArchitectureNodeType = 'system' | 'component' | 'database' | 'gateway' | 'microservice' | 'messageQueue' | 'cache' | 'storage' | 'frontend';
export interface MetricBadge {
    label: string;
    value: string | number;
    trend?: 'up' | 'down' | 'flat';
    status?: 'success' | 'warning' | 'danger' | 'normal';
}
export interface ArchitectureNodeData extends Record<string, unknown> {
    label: string;
    type: ArchitectureNodeType;
    icon?: string;
    description?: string;
    status?: 'normal' | 'warning' | 'error';
    themeColor?: string;
    metrics?: MetricBadge[];
    linterErrors?: string[];
}
declare const _default: React.NamedExoticComponent<NodeProps<Node<ArchitectureNodeData>>>;
export default _default;
