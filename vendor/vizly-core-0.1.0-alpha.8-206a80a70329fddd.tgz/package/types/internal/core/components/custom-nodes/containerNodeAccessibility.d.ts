export interface ContainerNodeAccessibilityInput {
    accessibleName: string;
    selected: boolean;
    collapsed: boolean;
    childCount: number;
}
export interface ContainerNodeAccessibilityProps {
    role: 'treeitem';
    tabIndex: 0;
    'aria-label': string;
    'aria-selected': boolean;
    'aria-expanded'?: boolean;
}
export declare const toContainerAccessibleText: (value: unknown, fallback: string) => string;
export declare const createContainerNodeAccessibilityProps: ({ accessibleName, selected, collapsed, childCount, }: ContainerNodeAccessibilityInput) => ContainerNodeAccessibilityProps;
