import React from 'react';
import { NodeProps } from '@xyflow/react';
import type { Node } from '@xyflow/react';
import { type CustomNodeStyleData } from './hooks/useCustomNodeStyleResolution.js';
import './PremiumNodeStyles.css';
export interface CustomNodeProps extends Partial<NodeProps<Node<CustomNodeStyleData>>> {
    data: CustomNodeStyleData;
    width?: number;
    height?: number;
}
declare const _default: React.NamedExoticComponent<CustomNodeProps>;
export default _default;
