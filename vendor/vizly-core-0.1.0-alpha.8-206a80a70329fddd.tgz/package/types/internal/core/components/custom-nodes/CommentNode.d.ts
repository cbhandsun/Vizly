import React from 'react';
import { NodeProps } from '@xyflow/react';
import './CommentNode.css';
/**
 * 评论 Pin 节点 (Phase 11)
 * 用于在画布上显示一个可交互的评论标记，点击后展示详情和回复界面
 *
 * [Perf] Uses a selector to subscribe only to the specific comment object,
 * avoiding re-renders when unrelated comments change.
 */
declare const CommentNode: ({ id, selected }: NodeProps) => React.JSX.Element | null;
declare const _default: React.MemoExoticComponent<typeof CommentNode>;
export default _default;
