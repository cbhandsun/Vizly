import { EdgeProps } from '@xyflow/react';
import React from 'react';
interface CustomEdgeData extends Record<string, unknown> {
    label?: string;
    pathType?: 'bezier' | 'straight' | 'step' | 'smooth-step' | 'smoothstep';
    pathOptions?: {
        borderRadius?: number;
        offset?: number;
        curvature?: number;
    };
    labelOffset?: {
        x?: number;
        y?: number;
    };
    /** 绝对锚定标签的 X 坐标（函数级注释：用于强制固定横坐标） */
    absoluteLabelX?: number;
    /** 绝对锚定标签的 Y 坐标（函数级注释：用于强制固定纵坐标） */
    absoluteLabelY?: number;
    onLabelChange?: (edgeId: string, label: string) => void;
}
interface CustomEdgeProps extends EdgeProps {
    data?: CustomEdgeData;
}
declare const _default: React.NamedExoticComponent<CustomEdgeProps>;
export default _default;
