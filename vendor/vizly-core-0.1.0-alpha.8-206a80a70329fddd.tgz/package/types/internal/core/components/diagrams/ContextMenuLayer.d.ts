import React from 'react';
import { DiagramTypePlugin, PluginContext } from '../../types/plugin.js';
interface ContextMenuLayerProps {
    onAction: (action: string, targetId?: string) => void;
    activePlugin?: DiagramTypePlugin | null;
    pluginCtx?: PluginContext;
    canUndo: boolean;
    canRedo: boolean;
}
export declare const ContextMenuLayer: React.FC<ContextMenuLayerProps>;
export {};
