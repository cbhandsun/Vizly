import React from 'react';
import type { CommentThread as Annotation } from '../../store/useDiagramStore.js';
interface AnnotationLayerProps {
    annotations: Annotation[];
    annotationMode: boolean;
    onAdd: (x: number, y: number, text: string) => boolean | void;
    onUpdate: (id: string, updates: Partial<Pick<Annotation, 'content' | 'color' | 'x' | 'y'>>) => boolean | void;
    onDelete: (id: string) => void;
    onToggleResolved: (id: string) => void;
    colors: string[];
    /** 当前页面 ID — 页面切换时重置编辑状态 */
    activePageId?: string;
}
/**
 * 画布批注渲染层 — 渲染在 ReactFlow children 中，跟随画布坐标系
 */
export declare const AnnotationLayer: React.FC<AnnotationLayerProps>;
export {};
