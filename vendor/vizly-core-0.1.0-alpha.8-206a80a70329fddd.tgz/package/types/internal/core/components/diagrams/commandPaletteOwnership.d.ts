interface SetDesignerCommandPaletteVisibilityOptions {
    visible: boolean;
    openHostCommandPalette?: () => void;
    setInternalVisibility: (visible: boolean) => void;
}
export declare const setDesignerCommandPaletteVisibility: ({ visible, openHostCommandPalette, setInternalVisibility, }: SetDesignerCommandPaletteVisibilityOptions) => void;
export {};
