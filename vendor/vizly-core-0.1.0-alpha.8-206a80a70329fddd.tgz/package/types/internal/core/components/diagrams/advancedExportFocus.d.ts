export declare const ADVANCED_EXPORT_FOCUS_RETURN_SELECTOR = "[data-advanced-export-focus-return=\"true\"]";
export declare const focusAdvancedExportTrigger: (root?: ParentNode) => boolean;
