import React from 'react';
import '../../ui/CommandPalette.css';
import { Node, Edge, ReactFlowInstance } from '@xyflow/react';
import { DiffResult } from '../../../utils/diagramDiff.js';
import type { CommandItem } from '../../../types/plugin.js';
import type { AutoSaveState } from '../hooks/useAutoSave.js';
import type { FlowchartSaveTarget } from '../hooks/useTrackedFlowchartSaves.js';
import type { PresentationSlide } from '../../../hooks/usePresentationSlides.js';
export interface DesignerOverlaysLayerProps {
    diagramId?: string;
    jsonEditor: {
        visible: boolean;
        setVisible: (v: boolean) => void;
        nodes: Node[];
        edges: Edge[];
        setNodes: React.Dispatch<React.SetStateAction<Node[]>>;
        setEdges: React.Dispatch<React.SetStateAction<Edge[]>>;
        reactFlowInstance: ReactFlowInstance | null;
        initialContent?: string;
        onBeforeCanvasReplace?: () => void;
    };
    commandPalette: {
        visible: boolean;
        setVisible: (v: boolean) => void;
        items: CommandItem[];
    };
    shortcuts: {
        panelVisible: boolean;
        setPanelVisible: (v: boolean) => void;
        modalVisible: boolean;
        setModalVisible: (v: boolean) => void;
    };
    status: {
        saveState: AutoSaveState;
        saveTarget: FlowchartSaveTarget;
        onRetrySave?: () => void | Promise<void>;
        showPerformanceDashboard: boolean;
        nodeCount: number;
        edgeCount: number;
    };
    presentation: {
        active: boolean;
        setActive: (v: boolean) => void;
        slides: PresentationSlide[];
        onFocusNodes: (ids: string[]) => void;
    };
    diff: {
        result: DiffResult | null;
        setResult: (v: DiffResult | null) => void;
    };
    renderAIConfigModal?: React.ReactNode;
    renderShareDialog?: React.ReactNode;
}
export declare const DesignerOverlaysLayer: React.FC<DesignerOverlaysLayerProps>;
