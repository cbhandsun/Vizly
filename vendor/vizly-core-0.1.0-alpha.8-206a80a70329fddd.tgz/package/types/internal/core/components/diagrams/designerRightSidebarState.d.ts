export declare const shouldExpandDesignerRightSidebar: ({ isCollapsed, hasSelection, previousHasSelection, isMobile, activeTab, aiChatVisible, previousAiChatVisible, }: {
    isCollapsed: boolean;
    hasSelection: boolean;
    previousHasSelection?: boolean;
    isMobile: boolean;
    activeTab: 'property' | 'ai';
    aiChatVisible: boolean;
    previousAiChatVisible: boolean;
}) => boolean;
export declare const shouldActivateDesignerPropertyTab: ({ activeTab, hasSelection, isMobile, previousHasSelection, }: {
    activeTab: 'property' | 'ai';
    hasSelection: boolean;
    isMobile: boolean;
    previousHasSelection: boolean;
}) => boolean;
export declare const shouldOpenDesignerAiSidebar: (activeTab: 'property' | 'ai', aiChatVisible: boolean) => boolean;
export declare const shouldFreezeDesignerRightSidebarDuringDrag: (previous: {
    isDraggingNode: boolean;
}, next: {
    isDraggingNode: boolean;
}) => boolean;
type DesignerRightSidebarMemoInput = Readonly<{
    isDraggingNode: boolean;
    selectedNodes: readonly unknown[];
    selectedEdges: readonly unknown[];
}> & Readonly<Record<string, unknown>>;
export declare const shouldReuseDesignerRightSidebar: <T extends DesignerRightSidebarMemoInput>(previous: T, next: T) => boolean;
export declare const MOBILE_DESIGNER_PANEL_DOCK_CLEARANCE = "calc(88px + env(safe-area-inset-bottom, 0px))";
export declare const MOBILE_DESIGNER_PANEL_WIDTH = "calc(100vw / var(--commercial-ui-scale, 1))";
export declare const createDesignerRightSidebarOffsetVariables: (visibleWidth: number | null) => Readonly<{
    rightSidebarOffset: string;
    maxSidebarOffset: string;
}>;
export declare const createDesignerRightSidebarLayout: ({ isCollapsed, isMobile, panelWidth, }: {
    isCollapsed: boolean;
    isMobile: boolean;
    panelWidth: number;
}) => {
    position: 'fixed';
    right: number;
    left: number;
    top: string;
    bottom: string;
    maxHeight: string;
    height: string | number;
    width: string;
} | {
    position: 'absolute';
    right: number;
    left: string;
    top: number;
    bottom: string;
    maxHeight: string;
    height: string;
    width: string | number;
};
export {};
