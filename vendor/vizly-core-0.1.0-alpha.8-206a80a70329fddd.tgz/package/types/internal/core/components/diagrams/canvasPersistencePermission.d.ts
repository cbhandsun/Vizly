/** Host checks are evaluated immediately before persistence, including delayed retries.
 * A broken host boundary denies persistence; its exception must not expose host data.
 */
export declare const isCanvasPersistenceAllowed: (check?: () => boolean) => boolean;
