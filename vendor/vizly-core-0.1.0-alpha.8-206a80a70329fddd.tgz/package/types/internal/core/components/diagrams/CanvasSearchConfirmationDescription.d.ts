import React from 'react';
interface CanvasSearchConfirmationDescriptionProps {
    description: string;
    mapping: string;
}
export declare const CanvasSearchConfirmationDescription: React.FC<CanvasSearchConfirmationDescriptionProps>;
export {};
