export interface BridgeConnectNodesPayload {
    source: string;
    target: string;
    label?: string;
    type: string;
}
export declare const parseBridgeConnectNodesPayload: (args: unknown) => BridgeConnectNodesPayload | null;
