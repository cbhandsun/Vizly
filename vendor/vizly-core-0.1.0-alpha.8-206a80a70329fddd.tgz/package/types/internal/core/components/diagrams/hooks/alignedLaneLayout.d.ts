import type { Edge, Node } from '@xyflow/react';
import type { LayoutOptions } from '../../../types/layout.js';
import type { LaneRankDecision } from '../../../types/domainLaneRank.js';
import type { LayoutCalculationContext } from '../../../types/layout-strategy.js';
import type { FlowchartLayoutDirection } from '../flowchartLayoutStrategyMode.js';
import type { LayoutCandidate, RoutedLayoutCandidate } from './layoutCandidateSelection.js';
export declare const preferAlignedLaneLayout: (baseline: RoutedLayoutCandidate, candidate: RoutedLayoutCandidate, direction: FlowchartLayoutDirection) => boolean;
/** One optional candidate for an already-selected global phase model. Failed
 * geometry/routing stays with the existing transaction's validated baseline. */
export declare function createAlignedLaneComparison({ nodes, edges, options, direction, context, decision, onSelectedDecision }: {
    nodes: Node[];
    edges: Edge[];
    options: LayoutOptions;
    direction: FlowchartLayoutDirection;
    context: LayoutCalculationContext;
    decision: LaneRankDecision;
    onSelectedDecision: (decision: LaneRankDecision) => void;
}): {
    create: () => Promise<LayoutCandidate | null>;
    prefer: (baseline: RoutedLayoutCandidate, alternative: RoutedLayoutCandidate) => boolean;
} | undefined;
