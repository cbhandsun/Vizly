import type { Edge, Node } from '@xyflow/react';
import { type FlowchartCanvasSearchMatch } from './flowchartSearchReplace.js';
interface CanvasSearchHighlightStyleInput {
    currentMatch: FlowchartCanvasSearchMatch | null;
    currentMatchKey: string | null;
    edges: readonly Edge[];
    matches: readonly FlowchartCanvasSearchMatch[];
    nodes: readonly Node[];
    query: string;
}
export declare const buildCanvasSearchHighlightStyle: ({ currentMatch, currentMatchKey, edges, matches, nodes, query, }: CanvasSearchHighlightStyleInput) => string;
export {};
