export declare const CONTAINER_COLLAPSE_REQUEST_EVENT = "vizly:container-collapse-request";
export declare const readContainerCollapseRequest: (event: Event) => string | null;
export declare const dispatchContainerCollapseRequest: (target: HTMLElement, nodeId: string) => void;
