import type { LaneRankDecision, LaneRankPreference } from '../../../types/domainLaneRank.js';
import type { LayoutSelection } from '../layoutSelectionPersistence.js';
export declare const layoutSelectionToolbarProps: (selection: LayoutSelection) => {
    lastDomainDirection: import("../flowchartLayoutStrategyMode.js").FlowchartLayoutDirection;
    lastDomainStrategy: string;
    lastNodeLayout: string;
    laneRankPreference: LaneRankPreference;
    laneRankDecision: Readonly<{
        version: 1;
        policyVersion: 1;
        requested: LaneRankPreference;
        applied: import("../../../types/domainLaneRank.js").LaneRankMode;
        reason: import("../../../types/domainLaneRank.js").LaneRankDecisionReason;
        direction: import("../../../types/domainLaneRank.js").LaneRankDirection;
        connectedInputFingerprint: string;
        metrics: Readonly<{
            global?: import("../../../types/domainLaneRank.js").LaneRankMetrics;
            compact?: import("../../../types/domainLaneRank.js").LaneRankMetrics;
        }>;
        additionalBacktrackTravel?: number;
        score?: number;
        margin?: number;
        previousApplied?: import("../../../types/domainLaneRank.js").LaneRankMode;
    }> | undefined;
};
export interface DesignerHeaderLayoutMemoState {
    lastDomainDirection?: string;
    lastDomainStrategy?: string;
    lastNodeLayout?: string;
    layoutBusy?: boolean;
    laneRankPreference?: LaneRankPreference;
    laneRankDecision?: LaneRankDecision;
}
export declare const haveSameDesignerHeaderLayoutState: (previous: DesignerHeaderLayoutMemoState, next: DesignerHeaderLayoutMemoState) => boolean;
