import React from 'react';
/**
 * 实时协作用户头像列表 (Phase 9)
 */
export declare const CollaborationAvatars: React.FC;
