import type { Edge } from '@xyflow/react';
/**
 * Automatic route geometry is an algorithm output, not durable user content.
 * Persisted edge objects never own automatic display geometry. Retain authored
 * edge data and waypoints, but force Canvas to validate a separate routing-only
 * candidate (when present) or recompute the route.
 */
export declare const invalidateStalePresetEdgeAutomaticRoute: (edge: Edge, presetEdge: unknown, _savedRoutingVersion: unknown) => Edge;
