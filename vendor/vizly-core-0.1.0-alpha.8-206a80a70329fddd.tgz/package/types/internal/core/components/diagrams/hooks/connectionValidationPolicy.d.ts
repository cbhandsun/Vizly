import type { Connection, Edge, Node } from '@xyflow/react';
import type { ConnectionValidationResult, DiagramConnectionPolicy } from '../../../types/connection.js';
export declare const connectionToken: (value: unknown) => string;
export declare const getConnectionRelationKey: (connection: Connection | Edge) => string;
export declare const connectionIdentityMatches: (edge: Edge, connection: Connection | Edge) => boolean;
export interface ValidateConnectionDetailedOptions {
    nodes: readonly Node[];
    edges: readonly Edge[];
    connection: Connection | Edge;
    connectionPolicy?: DiagramConnectionPolicy;
    maxSourceConnections?: number;
    maxTargetConnections?: number;
    pluginAccepted?: boolean;
    ignoredEdgeIds?: ReadonlySet<string>;
}
export declare const validateConnectionDetailed: ({ nodes, edges, connection, connectionPolicy, maxSourceConnections, maxTargetConnections, pluginAccepted, ignoredEdgeIds, }: ValidateConnectionDetailedOptions) => ConnectionValidationResult;
