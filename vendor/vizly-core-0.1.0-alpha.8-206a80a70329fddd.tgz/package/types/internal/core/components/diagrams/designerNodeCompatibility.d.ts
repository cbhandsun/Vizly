import type { StandardNodeData } from '../../models/DiagramModels.js';
export interface DesignerNodeCompatibility {
    metadata: Record<string, unknown>;
    persistedNodeData: Record<string, unknown>;
    parentId?: string;
    position?: Record<string, unknown>;
    semanticData: Record<string, unknown>;
    shape: string;
}
export declare const resolveDesignerNodeCompatibility: (node: StandardNodeData) => DesignerNodeCompatibility;
