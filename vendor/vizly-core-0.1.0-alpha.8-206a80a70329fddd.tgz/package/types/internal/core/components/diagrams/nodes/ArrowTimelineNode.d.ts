import React from 'react';
import type { Node } from '@xyflow/react';
import type { NodeDataUpdate } from '../../../types/diagram-updates.js';
export interface ArrowTimelineEvent {
    date: string;
    label?: string;
    color: string;
}
export interface ArrowTimelineNodeData extends Record<string, unknown> {
    events?: ArrowTimelineEvent[];
    variant?: 'arrow' | 'dot';
    spacing?: number;
}
declare function ArrowTimelineNode({ id, data, selected, isDragging }: {
    id: string;
    data: ArrowTimelineNodeData;
    selected?: boolean;
    isDragging?: boolean;
}): React.JSX.Element;
interface ArrowTimelineToolbarExtensionProps {
    node: Node<ArrowTimelineNodeData>;
    updateNodesBatch: (nodeIds: string[], updates: NodeDataUpdate, options?: {
        snapshot?: boolean;
    }) => void;
}
declare const ArrowTimelineToolbarExtension: React.FC<ArrowTimelineToolbarExtensionProps>;
declare const MemoizedArrowTimelineNode: React.MemoExoticComponent<typeof ArrowTimelineNode>;
type ArrowTimelineNodeWithToolbar = typeof MemoizedArrowTimelineNode & {
    ToolbarExtension: typeof ArrowTimelineToolbarExtension;
    OverrideDefaultToolbar: boolean;
};
declare const ArrowTimelineNodeComponent: ArrowTimelineNodeWithToolbar;
export default ArrowTimelineNodeComponent;
