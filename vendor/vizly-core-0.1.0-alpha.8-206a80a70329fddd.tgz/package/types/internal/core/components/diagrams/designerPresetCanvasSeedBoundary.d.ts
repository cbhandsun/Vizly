import type { StandardEdgeData, StandardNodeData } from '../../models/DiagramModels.js';
export type PresetCanvasSeedGroup = Readonly<{
    id: string;
    type?: 'subGroup';
    label: string;
    description: string;
    domain: string;
    domainClass: string;
    subDomain?: string;
    parentId?: string;
    position: {
        x: number;
        y: number;
    };
    measured: {
        width: number;
        height: number;
    };
    data: Record<string, unknown>;
}>;
export type PresetCanvasNodeLayout = Readonly<{
    position: {
        x: number;
        y: number;
    };
    width: number;
    height: number;
    parentId?: string;
}>;
export type PresetCanvasEdgeSeed = Readonly<{
    sourceHandle: string;
    targetHandle: string;
    presentation: {
        type: 'stablePath';
        data: Record<string, unknown>;
    };
}>;
export type ParsedPresetCanvasSeed = Readonly<{
    groups: PresetCanvasSeedGroup[];
    nodes: ReadonlyMap<string, PresetCanvasNodeLayout>;
    edges: ReadonlyMap<string, PresetCanvasEdgeSeed>;
}>;
export declare const parsePresetCanvasSeed: (value: unknown, sourceNodes: readonly StandardNodeData[], sourceEdges: readonly StandardEdgeData[]) => ParsedPresetCanvasSeed | null;
