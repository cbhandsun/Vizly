export interface PageTabsMemoState {
    items: unknown;
    activePageId: string;
    disabled?: boolean;
}
export declare const havePageTabsPropsChanged: (previous: PageTabsMemoState, next: PageTabsMemoState) => boolean;
