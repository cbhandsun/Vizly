import type { Edge } from '@xyflow/react';
export declare const hasTrustedLayoutPath: (edge: Edge) => boolean;
/**
 * Lightweight render preparation. Full display quality is intentionally owned
 * by BaseReactFlow's worker so the UI never performs the same route synchronously
 * before posting it to the worker again.
 */
export declare const prepareBaseDiagramDisplayEdges: (edges: Edge[]) => Edge[];
