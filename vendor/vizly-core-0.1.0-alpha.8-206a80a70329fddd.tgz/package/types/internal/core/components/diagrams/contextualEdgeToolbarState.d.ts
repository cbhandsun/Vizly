import type { Edge } from '@xyflow/react';
import type { EdgeDataUpdate } from '../../types/diagram-updates.js';
export interface ContextualEdgeRoutingState {
    isOrthogonal: boolean;
    nextType: 'smart-bezier' | 'smart-orthogonal';
}
export declare const resolveContextualEdgeRoutingState: (edge: Pick<Edge, 'type' | 'data'>) => ContextualEdgeRoutingState;
export declare const createContextualEdgeRoutingUpdate: (state: ContextualEdgeRoutingState) => EdgeDataUpdate;
