import React from 'react';
import { ExportOptions } from '../../../utils/imageExporter.js';
import type { DiagramExportFormat } from '@vizly/core/internal/types/diagram-components';
import { type ReactFlowRenderSnapshot } from '../../../rendering/reactFlowScene.js';
import './AdvancedExportModal.css';
interface AdvancedExportModalProps {
    visible: boolean;
    onClose: () => void;
    diagramId?: string;
    diagramTitle?: string;
    getReactFlowSnapshot?: () => ReactFlowRenderSnapshot | null | undefined;
    onExportPermissionCheck?: (format: DiagramExportFormat) => boolean;
}
export declare const AdvancedExportModeNotice: React.FC<{
    format: ExportOptions['format'];
    hasSnapshotProvider: boolean;
}>;
export declare const SvgExportPreview: React.FC<{
    visible: boolean;
    getReactFlowSnapshot?: () => ReactFlowRenderSnapshot | null | undefined;
}>;
/**
 * 高级导出模态框 (Phase 10)
 * 提供清晰度选择、背景控制、元数据注入及一键拷贝功能
 */
export declare const AdvancedExportModal: React.FC<AdvancedExportModalProps>;
export {};
