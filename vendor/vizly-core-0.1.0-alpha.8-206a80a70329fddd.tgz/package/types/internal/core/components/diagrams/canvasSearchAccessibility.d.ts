export declare const CANVAS_SEARCH_RESULT_LABEL_MAX_LENGTH = 160;
export declare const formatCanvasSearchResultLabel: (value: unknown, fallbackId: string) => string;
export declare const getCanvasSearchMatchAnnouncementLabel: (match: FlowchartCanvasSearchMatch, nodes: readonly Node[], edges: readonly Edge[]) => string;
import type { Edge, Node } from '@xyflow/react';
import { type FlowchartCanvasSearchMatch } from './flowchartSearchReplace.js';
