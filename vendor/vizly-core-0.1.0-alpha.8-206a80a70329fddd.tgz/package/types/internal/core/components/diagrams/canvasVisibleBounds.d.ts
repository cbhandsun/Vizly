export interface CanvasOverlayRect {
    top?: unknown;
    bottom?: unknown;
    left?: unknown;
    right?: unknown;
    width?: unknown;
    height?: unknown;
}
interface CanvasVisibleVerticalBoundsInput {
    containerTop: unknown;
    containerBottom: unknown;
    containerLeft: unknown;
    containerRight: unknown;
    containerHeight: unknown;
    topOverlays?: readonly CanvasOverlayRect[];
    bottomOverlays?: readonly CanvasOverlayRect[];
}
export interface CanvasVisibleVerticalBounds {
    visibleTop: number;
    visibleBottom: number;
}
export declare const calculateCanvasVisibleVerticalBounds: ({ containerTop, containerBottom, containerLeft, containerRight, containerHeight, topOverlays, bottomOverlays, }: CanvasVisibleVerticalBoundsInput) => CanvasVisibleVerticalBounds;
export {};
