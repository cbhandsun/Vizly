import type { Edge, Node } from '@xyflow/react';
import { type AnalysisResult } from '../../../utils/diagramAnalyzer.js';
export declare const projectDesignerStandardNodes: (nodes: Node[]) => {
    standardNodes: Array<Record<string, unknown>>;
    groups: Array<Record<string, unknown>>;
};
export declare const projectDesignerStandardEdges: (edges: Edge[]) => Array<Record<string, unknown>>;
export declare const analyzeDesignerCanvas: (nodes: Node[], edges: Edge[]) => AnalysisResult;
