import React from 'react';
export interface CommentPanelProps {
    activePageId?: string;
    activePageName?: string;
    onStartCommentMode?: () => void;
}
export declare const CommentPanel: React.FC<CommentPanelProps>;
