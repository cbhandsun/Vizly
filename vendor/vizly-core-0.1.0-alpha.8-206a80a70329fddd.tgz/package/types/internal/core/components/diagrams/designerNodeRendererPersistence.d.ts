export declare const parsePersistedNodeRenderer: (value: unknown) => string | undefined;
