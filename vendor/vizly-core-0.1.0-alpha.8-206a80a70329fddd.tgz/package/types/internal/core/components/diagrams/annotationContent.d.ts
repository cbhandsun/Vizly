export declare const MAX_ANNOTATION_CONTENT_LENGTH = 4000;
export type AnnotationContentError = 'required' | 'too_long' | 'save_failed';
export type AnnotationContentResult = {
    ok: true;
    value: string;
} | {
    ok: false;
    error: Exclude<AnnotationContentError, 'save_failed'>;
};
export declare const parseAnnotationContent: (value: unknown) => AnnotationContentResult;
