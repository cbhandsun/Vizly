import React from 'react';
import './CanvasRuler.css';
interface CanvasRulerProps {
    orientation: 'horizontal' | 'vertical';
    isDarkMode?: boolean;
}
/**
 * CanvasRuler - 画布标尺组件
 * 显示水平或垂直标尺，跟随viewport变化更新
 */
export declare const CanvasRuler: React.FC<CanvasRulerProps>;
/**
 * RulerCorner - 标尺角落填充块
 */
export declare const RulerCorner: React.FC<{
    isDarkMode?: boolean;
}>;
export {};
