import React from 'react';
import type { Color } from 'antd/es/color-picker';
export type NodeColorField = 'themeColor' | 'main' | 'background' | 'text';
export interface PropertyColorPickerPanelLabels {
    editor: string;
    hue: string;
    alpha: string;
    format: string;
    value: string;
}
interface AccessiblePropertyColorPickerProps {
    label: string;
    value: string | undefined;
    fallbackValue: string;
    fallbackLabel?: string;
    mixed: boolean;
    mixedLabel: string;
    panelLabels: PropertyColorPickerPanelLabels;
    field: NodeColorField;
    disabled: boolean;
    onColorChange: (color: Color, field: NodeColorField) => void;
}
export declare const AccessiblePropertyColorPicker: React.FC<AccessiblePropertyColorPickerProps>;
export {};
