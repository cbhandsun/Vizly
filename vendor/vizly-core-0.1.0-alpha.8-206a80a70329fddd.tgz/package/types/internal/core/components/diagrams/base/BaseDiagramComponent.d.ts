import React from 'react';
import type { Node, Edge, OnNodesChange, OnEdgesChange } from '@xyflow/react';
import type { DiagramComponentProps, ResolvedEdgeConfig } from '../../../types/diagram-components.js';
import { ILayoutStrategy } from '../../../strategies/LayoutStrategyManager.js';
export interface BaseDiagramConfig {
    NODE_WIDTH: number;
    NODE_HEIGHT: number;
    SPACING: {
        H: number;
        V: number;
    };
    GROUP_PADDING?: number;
    TITLE_BAR_HEIGHT?: number;
}
export interface BaseDiagramProps extends Omit<DiagramComponentProps, 'config'> {
    id?: string;
    title?: string;
    subtitle?: string;
    config?: Partial<BaseDiagramConfig>;
    nodes: Node[];
    edges: Edge[];
    className?: string;
    style?: React.CSSProperties;
    resolvedEdgeConfig?: ResolvedEdgeConfig;
    edgeMode?: 'advanced-smart' | 'native';
    enableSmartEdges?: boolean;
    fitMode?: 'fitWidthTop' | 'fitAll' | 'none';
    pinFit?: boolean;
    fitPadding?: number;
    minZoom?: number;
    maxZoom?: number;
    showMiniMap?: boolean;
    showControls?: boolean;
    backgroundGridColor?: string;
    miniMapStyle?: React.CSSProperties;
    miniMapZoomable?: boolean;
    fallbackComponent?: React.ReactNode;
    disableZoomCompensation?: boolean;
    layoutStrategy?: ILayoutStrategy | string;
    nodeLayoutStrategy?: string;
    fitTriggerKey?: string | number;
    interactionPreset?: 'default' | 'zoom' | 'zoomWithDoubleClick' | 'pan' | 'view';
    panOnDrag?: boolean;
    zoomOnScroll?: boolean;
    zoomOnPinch?: boolean;
    zoomOnDoubleClick?: boolean;
    panOnScroll?: boolean;
    preventScrolling?: boolean;
    nodesDraggable?: boolean;
    nodesConnectable?: boolean;
    elementsSelectable?: boolean;
    disablePostEdgeProcessing?: boolean;
    onNodesChange?: OnNodesChange;
    onEdgesChange?: OnEdgesChange;
    deleteKeyCode?: string | string[] | null;
}
export declare const BaseDiagramComponent: React.FC<BaseDiagramProps>;
export default BaseDiagramComponent;
