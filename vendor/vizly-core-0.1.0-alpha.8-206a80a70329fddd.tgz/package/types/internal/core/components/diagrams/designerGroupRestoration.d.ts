import type { Node } from '@xyflow/react';
import type { GroupNodeData } from '../../models/DiagramModels.js';
import type { PresetCanvasSeedGroup } from './designerPresetCanvasSeedBoundary.js';
type RestorableGroup = GroupNodeData | PresetCanvasSeedGroup;
export declare const restoreCanvasGroups: (groups: readonly RestorableGroup[] | undefined, hasCanvasPositions: boolean) => Node[];
export {};
