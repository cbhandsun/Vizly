import React from 'react';
import { Comment } from '../../store/useDiagramStore.js';
interface CommentEditorProps {
    comment: Comment;
    onClose?: () => void;
}
export declare const CommentEditor: React.FC<CommentEditorProps>;
export {};
