export declare const logClipboardWriteFailure: (error: unknown) => void;
export declare const logClipboardSystemWriteFailure: (error: unknown) => void;
export declare const logClipboardReadFailure: (error: unknown) => void;
export declare const logClipboardStorageReadFailure: (error: unknown) => void;
