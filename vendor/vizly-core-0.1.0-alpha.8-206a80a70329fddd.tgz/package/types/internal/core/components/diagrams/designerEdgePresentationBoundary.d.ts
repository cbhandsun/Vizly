export type RestoredCanvasEdgePresentation = Readonly<{
    type?: string;
    data: Record<string, unknown>;
}>;
type CanvasHandleSide = 'source' | 'target';
export declare const resolveCanvasEdgeHandleState: (metadata: Record<string, unknown>, explicitSourceHandle?: string, explicitTargetHandle?: string) => Readonly<{
    autoHandleSides: CanvasHandleSide[];
    manualHandleSides: CanvasHandleSide[];
}>;
export declare const restoreCanvasEdgeRoutingData: ({ metadata, restoredData, autoHandleSides, manualHandleSides, inferredSubDomainHandles, }: Readonly<{
    metadata: Record<string, unknown>;
    restoredData: unknown;
    autoHandleSides: CanvasHandleSide[];
    manualHandleSides: CanvasHandleSide[];
    inferredSubDomainHandles: boolean;
}>) => Record<string, unknown>;
export declare const parseCanvasEdgePresentation: (value: unknown) => RestoredCanvasEdgePresentation | null;
export {};
