import { type Node } from '@xyflow/react';
import type { CSSProperties } from 'react';
import type { StandardDiagramData, StandardEdgeData } from '../../models/DiagramModels.js';
import { LayoutType } from '../../types/layout.js';
export type StandardDataToCanvasOptions = {
    edgeRoutingQuality?: 'full' | 'interactive';
};
export declare const isRecord: (value: unknown) => value is Record<string, unknown>;
export declare const optionalString: (value: unknown) => string | undefined;
export declare const resolveCanvasPosition: (value: unknown, fallback: Node['position']) => Node['position'];
export declare const resolveCanvasStyle: (value: unknown) => CSSProperties;
export declare const optionalLayoutType: (value: unknown) => LayoutType | undefined;
export declare const resolveRestorableThemeId: (themeId?: string) => string | undefined;
export declare const coerceMindMapPersistenceNode: (value: unknown) => Node | null;
export declare const resolveGeneratedGroupLayoutOptions: (layout: StandardDiagramData['layout'] | undefined) => {
    generateDomainGroups: boolean;
    generateSubDomainGroups: boolean;
    domainWhitelist: string[] | undefined;
    subDomainWhitelist: string[] | undefined;
};
export declare const restoreCanvasEdgePresentation: (edge: StandardEdgeData, edgeId: string, presentationOverride?: unknown) => {
    id: string;
    source: string;
    target: string;
    type: string;
    className: string | undefined;
    label: string | undefined;
    markerEnd: import("@xyflow/system").EdgeMarkerType;
    style: CSSProperties | undefined;
    data: Record<string, unknown> | undefined;
};
export declare const stripHiddenCanvasNodes: (nodes: Node[]) => Node[];
