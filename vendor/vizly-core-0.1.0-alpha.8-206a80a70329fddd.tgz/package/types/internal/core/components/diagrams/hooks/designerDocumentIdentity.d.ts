import type { FlowDataBridgeMetadata } from '../../../utils/flowDataBridge.js';
export interface DesignerDocumentIdentity {
    scopeId: string;
    id: string;
    name: string;
    metadata: FlowDataBridgeMetadata;
}
/** Identity belongs to the loaded view, never to the latest background cloud read. */
export declare const parseDesignerDocumentIdentity: (value: unknown, scopeId: string) => DesignerDocumentIdentity | null;
export declare const readDesignerAutosaveIdentity: (metadata: unknown, scopeId: string) => DesignerDocumentIdentity | null;
export declare const readDesignerCanvasMetadata: (metadata: unknown) => unknown;
export declare const createDesignerAutosaveMetadata: (metadata: unknown, identity: DesignerDocumentIdentity | null) => unknown;
