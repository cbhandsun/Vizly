export interface CollaborationPresenceUser {
    clientId: string | number;
    user: {
        name: string;
        color: string;
    };
    cursor?: {
        x: number;
        y: number;
    };
    isLocal?: boolean;
    isIdle?: boolean;
}
export declare const coerceCollaborationPresenceUsers: (value: unknown) => CollaborationPresenceUser[];
