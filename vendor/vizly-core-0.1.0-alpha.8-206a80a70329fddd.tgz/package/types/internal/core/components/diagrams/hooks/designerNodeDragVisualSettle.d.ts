export type DesignerNodeDragVisualSettleRef = {
    current: {
        minimumHandle: number;
        watchdogHandle: number;
        nodeId: string;
        minimumElapsed: boolean;
        routingFinalApplied: boolean;
        onSettled: () => void;
    } | null;
};
export declare const cancelDesignerNodeDragVisualSettle: (timerRef: DesignerNodeDragVisualSettleRef) => void;
/**
 * Keeps expensive designer rendering frozen through the short routing commit
 * window. The visual drop class and UI thaw share one bounded lifecycle so a
 * new drag or unmount cannot leave a stale timer or class behind.
 */
export declare const scheduleDesignerNodeDragVisualSettle: ({ nodeId, timerRef, onSettled, }: Readonly<{
    nodeId: unknown;
    timerRef: DesignerNodeDragVisualSettleRef;
    onSettled: () => void;
}>) => void;
export declare const markDesignerNodeDragRoutingFinalApplied: (timerRef: DesignerNodeDragVisualSettleRef) => void;
