import { type Node } from '@xyflow/react';
interface NodeSizeOptimizer {
    calculateNodeWidth: (description: string) => number;
    calculateNodeHeight: (description: string) => number;
}
export declare const clearDesignerFreshSeedFlag: (storageKey: string, storage?: Pick<Storage, 'getItem' | 'setItem'>) => void;
/**
 * Reconciles external autosave edges with the active preset contract.
 * Presentation is sanitized for every saved edge; matching preset edges also
 * restore missing semantic styles, marker colors, and explicit handles.
 */
export declare const mergePresetExplicitEdgeHandles: <T>(saved: T, preset: unknown) => T;
export declare const recalculateAutosaveNodeSizes: (nodes: readonly Node[], loadOptimizer?: () => Promise<NodeSizeOptimizer>) => Promise<Node[]>;
/**
 * Global performance CSS changes invalidate the entire document. Keep them for
 * genuinely high-density canvases; node dragging is handled by the scoped
 * `.react-flow.performance-mode` class instead.
 */
export declare const shouldUseGlobalDesignerPerformanceMode: (nodeCount: number) => boolean;
/**
 * Small and medium canvases are cheaper to paint normally than to invalidate
 * every visible node and edge by toggling the scoped performance class.
 * High-density canvases already keep document performance styles active.
 */
export declare const shouldUseScopedDesignerDragPerformanceMode: (nodeCount: number, isDragging: boolean) => boolean;
export {};
