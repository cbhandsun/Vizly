import type { DiagramCollaborationStatus } from '../../../types/diagram-components.js';
type CollaborationSocketStatus = Extract<DiagramCollaborationStatus, 'connecting' | 'connected' | 'disconnected'>;
export declare const resolveDiagramCollaborationStatus: (collaborationRequested: boolean, serverUrl: string, socketStatus: CollaborationSocketStatus) => DiagramCollaborationStatus;
export {};
