export interface AnnotationEditorViewport {
    width: number;
    height: number;
}
export interface AnnotationEditorPoint {
    x: number;
    y: number;
}
export interface AnnotationEditorSize {
    maxWidth?: number;
    estimatedHeight?: number;
}
export declare const resolveAnnotationEditorPosition: (point: AnnotationEditorPoint, viewport: AnnotationEditorViewport, size?: AnnotationEditorSize) => AnnotationEditorPoint;
