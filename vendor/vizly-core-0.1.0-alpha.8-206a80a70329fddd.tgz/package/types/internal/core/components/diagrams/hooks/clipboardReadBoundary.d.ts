export declare const SYSTEM_CLIPBOARD_READ_TIMEOUT_MS = 1000;
export declare const readClipboardTextWithTimeout: (readText: () => Promise<string>, timeoutMs?: number) => Promise<string | null>;
