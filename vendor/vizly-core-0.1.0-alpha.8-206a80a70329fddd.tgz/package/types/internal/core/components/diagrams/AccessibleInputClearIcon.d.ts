import React from 'react';
interface AccessibleInputClearIconProps {
    label: string;
}
export declare const AccessibleInputClearIcon: React.FC<AccessibleInputClearIconProps>;
export {};
