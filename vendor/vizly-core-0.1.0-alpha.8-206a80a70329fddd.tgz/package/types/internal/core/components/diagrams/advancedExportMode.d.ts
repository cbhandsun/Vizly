import type { ExportOptions } from '../../utils/imageExporter.js';
export interface AdvancedExportCapabilities {
    pixelRatio: boolean;
    background: boolean;
    metadata: boolean;
    clipboard: boolean;
}
export declare const getAdvancedExportCapabilities: (format: ExportOptions['format']) => AdvancedExportCapabilities;
export declare const isSceneBasedAdvancedExportFormat: (format: ExportOptions['format']) => boolean;
