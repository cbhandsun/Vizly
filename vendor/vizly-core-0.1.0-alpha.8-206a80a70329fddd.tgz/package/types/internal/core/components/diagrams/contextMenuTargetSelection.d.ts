import type { Edge, Node } from '@xyflow/react';
export interface ContextMenuTargetSelection {
    nodeIds: string[];
    edgeIds: string[];
}
interface ResolveContextMenuTargetSelectionInput {
    targetId: string;
    targetType: 'node' | 'edge';
    selectedNodeIds: readonly string[];
}
export declare const resolveContextMenuTargetSelection: ({ targetId, targetType, selectedNodeIds, }: ResolveContextMenuTargetSelectionInput) => ContextMenuTargetSelection;
export declare const applyContextMenuVisualSelection: <T extends Node | Edge>(items: readonly T[], selectedIds: ReadonlySet<string>) => T[];
export {};
