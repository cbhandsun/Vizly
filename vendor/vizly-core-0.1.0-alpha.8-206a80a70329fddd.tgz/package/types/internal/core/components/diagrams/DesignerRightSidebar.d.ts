import React from 'react';
import { Node, Edge } from '@xyflow/react';
import type { DiagramPanelRenderControls } from '../../types/diagram-components.js';
import { DiagramTypePlugin, PluginContext } from '../../types/plugin.js';
export interface DesignerRightSidebarProps {
    activeTab: 'property' | 'ai';
    diagramId?: string;
    onTabChange: (tab: 'property' | 'ai') => void;
    aiChatVisible: boolean;
    setAiChatVisible: (v: boolean) => void;
    selectedNodes: Node[];
    selectedEdges: Edge[];
    updateNodesBatch: (ids: string[], data: Record<string, unknown>, options?: {
        snapshot?: boolean;
    }) => void;
    updateEdgesBatch: (ids: string[], data: Record<string, unknown>) => void;
    onBeforeUpdate: () => void;
    isDraggingNode: boolean;
    renderAIChatPanel?: (controls: DiagramPanelRenderControls) => React.ReactNode;
    /** 通知父组件当前面板实际宽度 (0=不可见, 42=收起, 320=展开) */
    onWidthChange?: (width: number) => void;
    showAiCrown?: boolean;
    onAiTabIntercept?: () => boolean;
    activePlugin?: DiagramTypePlugin;
    pluginCtx?: PluginContext;
    isMobile?: boolean;
    collapseForLeftDrawer?: boolean;
    mobileOpen?: boolean;
    onMobileOpenChange?: (open: boolean) => void;
}
/**
 * 右侧边栏：Figma 风格 Icon-tab + 可折叠面板
 * - 折叠态: 42px 宽的垂直 Icon Rail
 * - 展开态: 可拖拽调节宽度（默认 360px）的 Tabs 面板
 */
export declare const DesignerRightSidebar: React.FC<DesignerRightSidebarProps>;
