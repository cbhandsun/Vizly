import React from 'react';
import { Node } from '@xyflow/react';
import { NodeDataUpdate } from '../../types/diagram-updates.js';
interface ArchitectureNodeEditorProps {
    selectedNodes: Node[];
    updateNodes: (partialData: NodeDataUpdate) => void;
    armSnapshot: () => void;
    onShowIconExplorer?: (onSelect: (icon: string) => void) => void;
    disabled: boolean;
}
export declare const ArchitectureNodeEditor: React.FC<ArchitectureNodeEditorProps>;
export {};
