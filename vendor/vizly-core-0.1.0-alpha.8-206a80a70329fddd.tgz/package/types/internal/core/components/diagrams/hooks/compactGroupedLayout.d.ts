import type { Edge, Node } from '@xyflow/react';
import { type LayoutOptions } from '../../../types/layout.js';
import type { LayoutCalculationContext } from '../../../types/layout-strategy.js';
import type { RoutedLayoutCandidate } from './layoutCandidateSelection.js';
import type { FlowchartLayoutDirection } from '../flowchartLayoutStrategyMode.js';
export declare const compactGroupInnerDirection: (direction: FlowchartLayoutDirection) => FlowchartLayoutDirection;
/** One-level semantic groups only. Other compound topologies keep their native
 * baseline until a candidate supports their constraints, without flattening. */
export declare const canCompareCompactGroups: (nodes: Node[], edges: Edge[], options: LayoutOptions) => boolean;
export declare function createCompactGroupedLayout(nodes: Node[], edges: Edge[], options: LayoutOptions, direction: FlowchartLayoutDirection, context: LayoutCalculationContext): Promise<{
    nodes: Node[];
    edges: Edge[];
} | null>;
/** Compactness never buys extra crossings or longer routes. Bends are reported
 * separately: a shorter orthogonal connection may legitimately turn more often. */
export declare function preferCompactGroupedLayout(baseline: RoutedLayoutCandidate, candidate: RoutedLayoutCandidate, direction: FlowchartLayoutDirection): boolean;
