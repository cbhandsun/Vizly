import type { CommentThread } from '../../store/useDiagramStore.js';
export declare const DEFAULT_COMMENT_PAGE_ID = "page-1";
export declare const MAX_COMMENT_PAGE_ID_LENGTH = 200;
type CommentPageScopeInput = Pick<CommentThread, 'pageId'> | {
    pageId?: unknown;
};
export declare const normalizeCommentPageId: (value: unknown) => string;
export declare const isCommentOnPage: (comment: CommentPageScopeInput, activePageId: unknown) => boolean;
export declare const filterCommentsForPage: (comments: readonly CommentThread[], activePageId: unknown) => CommentThread[];
export declare const removeCommentsForPage: (comments: readonly CommentThread[], pageId: unknown) => CommentThread[];
export {};
