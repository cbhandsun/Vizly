export type CommonPropertyValue<T> = {
    kind: 'empty';
} | {
    kind: 'mixed';
} | {
    kind: 'common';
    value: T;
};
export declare const resolveCommonPropertyValue: <TItem, TValue>(items: TItem[], getter: (item: TItem) => TValue) => CommonPropertyValue<TValue>;
