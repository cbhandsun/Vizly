import React from 'react';
import { type Edge, type Node } from '@xyflow/react';
import { type FlowchartCanvasReplaceResult, type FlowchartCanvasSearchMatch } from './flowchartSearchReplace.js';
export interface CanvasSearchBarProps {
    visible: boolean;
    onClose: () => void;
    nodes: Node[];
    edges?: Edge[];
    /** 当前页面名称；用于明确搜索范围，避免把当前页无结果误解为全图无结果。 */
    pageName?: string;
    /** 外部控制高亮节点 */
    onHighlightNode?: (nodeId: string | null) => void;
    /** 替换功能：更新当前节点文本或连线标签 */
    onReplaceMatch?: (match: FlowchartCanvasSearchMatch, query: string, replacement: string) => FlowchartCanvasReplaceResult;
    /** 批量替换 */
    onReplaceAll?: (matches: FlowchartCanvasSearchMatch[], query: string, replacement: string) => FlowchartCanvasReplaceResult;
    /** 受控替换栏状态，用于可靠响应 Ctrl+H 等外部入口 */
    replaceVisible?: boolean;
    onReplaceVisibleChange?: (visible: boolean) => void;
}
export declare const CanvasSearchBar: React.FC<CanvasSearchBarProps>;
