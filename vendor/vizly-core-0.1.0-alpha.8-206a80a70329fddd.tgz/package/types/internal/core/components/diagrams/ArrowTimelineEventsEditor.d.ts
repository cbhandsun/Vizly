import React from 'react';
import { Node } from '@xyflow/react';
import { NodeDataUpdate } from '../../types/diagram-updates.js';
interface ArrowTimelineEventsEditorProps {
    selectedNodes: Node[];
    updateNodes: (partialData: NodeDataUpdate) => void;
    armSnapshot: () => void;
    disabled?: boolean;
}
export declare const ArrowTimelineEventsEditor: React.FC<ArrowTimelineEventsEditorProps>;
export {};
