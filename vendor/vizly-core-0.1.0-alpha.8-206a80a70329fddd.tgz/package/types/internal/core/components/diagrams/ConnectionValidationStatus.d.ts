import type { ConnectionValidationResult } from '../../types/connection.js';
export declare const ConnectionValidationStatus: ({ validation, }: {
    validation: ConnectionValidationResult | null;
}) => import("react").JSX.Element | null;
