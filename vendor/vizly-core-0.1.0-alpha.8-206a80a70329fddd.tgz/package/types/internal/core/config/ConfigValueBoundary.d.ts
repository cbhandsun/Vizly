/** 统一配置值的解析、清洗与存储边界。 */
export type ConfigValue = null | boolean | number | string | ConfigValue[] | {
    [key: string]: ConfigValue;
};
export declare const isPlainConfigObject: (value: unknown) => value is Record<string, unknown>;
export declare const MAX_STORED_CONFIG_CHARS: number;
export declare const MAX_IMPORT_CONFIG_CHARS: number;
export declare const getConfigLocalStorage: () => Storage | null;
export declare const parseBoundedConfigJson: (json: string, maxChars: number, label: string) => unknown;
export declare const sanitizeConfigValue: (value: unknown, depth?: number) => ConfigValue;
export declare const cloneConfigValue: <T>(value: T) => T;
export declare const createNestedConfigPatch: (pathSegments: readonly string[], value: unknown) => ConfigValue;
export declare const configValuesEqual: (left: unknown, right: unknown) => boolean;
