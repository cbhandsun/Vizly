/**
 * 配置集成模块
 * 将新的分层配置系统与现有组件集成，提供平滑的迁移和兼容性
 */
import { LayeredConfigManager } from './LayeredConfigManager.js';
import { validators } from './ConfigValidation.js';
import { DiagramConfigManager } from '../config/DiagramConfig.js';
import { EnhancedThemeManager } from '../themes/EnhancedThemeManager.js';
import { ThemePresetManager } from '../themes/ThemePresetManager.js';
import { ThemePerformanceOptimizer } from '../themes/ThemePerformanceOptimizer.js';
import type { Theme, ThemePreset } from '../themes/types/ThemeTypes.js';
export interface IntegrationOptions {
    enableMigration: boolean;
    preserveExistingConfig: boolean;
    enableValidation: boolean;
    enablePerformanceOptimization: boolean;
    migrationStrategy: 'immediate' | 'gradual' | 'manual';
}
export interface MigrationResult {
    success: boolean;
    migratedConfigs: string[];
    errors: Array<{
        config: string;
        error: string;
    }>;
    warnings: string[];
}
export interface IntegrationStatus {
    layeredConfigReady: boolean;
    themeSystemReady: boolean;
    validationReady: boolean;
    performanceOptimizerReady: boolean;
    migrationComplete: boolean;
    errors: string[];
}
export interface IntegratedConfigExport {
    layeredConfig: string;
    themeConfig: Theme | undefined;
    presets: ThemePreset[];
    metadata: {
        exportTime: string;
        version: string;
        status: IntegrationStatus;
    };
}
export declare class ConfigIntegration {
    private diagramConfig;
    private options;
    private layeredConfig;
    private validation;
    private themeManager;
    private presetManager;
    private performanceOptimizer;
    private migrator;
    private synchronizer?;
    private status;
    private initializationPromise;
    constructor(diagramConfig: DiagramConfigManager, options: IntegrationOptions);
    /**
     * 初始化组件
     */
    private initializeComponents;
    /**
     * 执行配置迁移
     */
    private performMigration;
    /**
     * 获取分层配置管理器
     */
    getLayeredConfigManager(): LayeredConfigManager;
    /**
     * 获取增强主题管理器
     */
    getThemeManager(): EnhancedThemeManager;
    /**
     * 获取主题预设管理器
     */
    getPresetManager(): ThemePresetManager;
    /**
     * 获取性能优化器
     */
    getPerformanceOptimizer(): ThemePerformanceOptimizer | undefined;
    /**
     * 获取验证器
     */
    getValidation(): typeof validators | undefined;
    /**
     * 获取集成状态
     */
    getStatus(): IntegrationStatus;
    /**
     * 检查是否准备就绪
     */
    isReady(): boolean;
    /**
     * 等待准备就绪
     */
    waitForReady(timeout?: number): Promise<boolean>;
    /**
     * 导出集成配置
     */
    exportIntegratedConfig(): Promise<IntegratedConfigExport>;
    /**
     * 导入集成配置
     */
    importIntegratedConfig(config: unknown): Promise<void>;
    /**
     * 重置到默认配置
     */
    resetToDefaults(): Promise<void>;
    /**
     * 清理资源
     */
    dispose(): void;
}
export declare function createConfigIntegration(diagramConfig: DiagramConfigManager, options?: Partial<IntegrationOptions>): Promise<ConfigIntegration>;
export declare function getConfigIntegration(): ConfigIntegration | null;
export declare function resetConfigIntegration(): void;
