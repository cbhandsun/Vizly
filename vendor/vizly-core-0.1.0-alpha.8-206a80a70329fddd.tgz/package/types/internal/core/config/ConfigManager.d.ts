/**
 * 统一配置管理系统
 */
import { DiagramConfig } from '../types/common.js';
import { ConfigSource, type ConfigDefinition, type ConfigListener } from './ConfigDefinitions.js';
export { CONFIG_DEFINITIONS, ConfigSource, type ConfigChangeEvent, type ConfigDefinition, type ConfigListener, type ConfigValidator } from './ConfigDefinitions.js';
export declare class ConfigManager {
    private static instance;
    private configs;
    private listeners;
    private definitions;
    private configLogger;
    private constructor();
    /**
     * 获取单例实例
     */
    static getInstance(): ConfigManager;
    /**
     * 初始化配置定义
     */
    private initializeDefinitions;
    /**
     * 加载持久化配置
     */
    private loadPersistedConfigs;
    /**
     * 验证配置值
     */
    private validateConfig;
    private normalizeKnownConfigRecord;
    /**
     * 持久化配置
     */
    private persistConfig;
    /**
     * 通知监听器
     */
    private notifyListeners;
    /**
     * 获取配置值
     */
    get<T = unknown>(key: string, fallback?: T): T;
    /**
     * 设置配置值
     */
    set<T = unknown>(key: string, value: T, source?: ConfigSource): void;
    /**
     * 批量设置配置
     */
    setMultiple(configs: Record<string, unknown>, source?: ConfigSource): void;
    /**
     * 重置配置到默认值
     */
    reset(key: string): void;
    /**
     * 重置所有配置
     */
    resetAll(): void;
    /**
     * 添加配置监听器
     */
    addListener<T = unknown>(key: string, listener: ConfigListener<T>): void;
    /**
     * 移除配置监听器
     */
    removeListener<T = unknown>(key: string, listener: ConfigListener<T>): void;
    /**
     * 注册配置定义
     */
    registerDefinition(definition: ConfigDefinition): void;
    /**
     * 获取配置分组
     */
    getGroup(group: string): Record<string, unknown>;
    /**
     * 获取所有配置
     */
    getAll(): Record<string, unknown>;
    /**
     * 导出配置
     */
    exportConfig(includeDefaults?: boolean): string;
    /**
     * 导入配置
     */
    importConfig(configJson: string): void;
    /**
     * 获取配置统计
     */
    getStats(): Record<string, unknown>;
    /**
     * 创建配置快照
     */
    createSnapshot(): string;
    /**
     * 恢复配置快照
     */
    restoreSnapshot(snapshotJson: string): void;
}
export declare const configManager: ConfigManager;
export declare const getConfig: <T = unknown>(key: string, fallback?: T) => T;
export declare const setConfig: <T = unknown>(key: string, value: T) => void;
export declare const onConfigChange: <T = unknown>(key: string, listener: ConfigListener<T>) => void;
export declare const getThemeConfig: () => Record<string, unknown>;
export declare const getLayoutConfig: () => Record<string, unknown>;
export declare const getPerformanceConfig: () => Record<string, unknown>;
export declare const getExportConfig: () => Record<string, unknown>;
export declare const createDiagramConfig: () => DiagramConfig;
