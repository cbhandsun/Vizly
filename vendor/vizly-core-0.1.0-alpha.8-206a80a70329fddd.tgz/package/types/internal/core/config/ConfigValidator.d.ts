/**
 * Configuration Validator
 *
 * Validates routing configuration to ensure correctness and provides warnings
 * for potentially problematic settings.
 */
import type { UnifiedRoutingConfig } from '../types/routing.js';
export interface ValidationResult {
    valid: boolean;
    errors: string[];
    warnings: string[];
}
export declare class ConfigValidator {
    /**
     * Validate configuration
     *
     * @param config Configuration to validate
     * @returns Validation result
     */
    static validate(config: UnifiedRoutingConfig): ValidationResult;
    private static validateAlgorithm;
    private static validateCosts;
    private static validateBus;
    private static validatePortSelection;
    private static validatePostProcessing;
    private static validateOffsets;
    /**
     * Quick validation (errors only, no warnings)
     *
     * @param config Configuration to validate
     * @returns True if valid (no errors)
     */
    static isValid(config: UnifiedRoutingConfig): boolean;
    /**
     * Assert configuration is valid (throws if invalid)
     *
     * @param config Configuration to validate
     * @throws Error if configuration is invalid
     */
    static assertValid(config: UnifiedRoutingConfig): void;
}
