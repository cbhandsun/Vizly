/**
 * 配置验证系统
 * 提供各种配置验证器和数据清理器
 */
export type ConfigValidationResult = true | string;
export interface ConfigValidator<T = unknown> {
    validate: (value: unknown) => ConfigValidationResult;
    sanitize?: (value: unknown) => T;
}
export interface ConfigSchema<T = unknown> {
    key: string;
    type: 'string' | 'number' | 'boolean' | 'object' | 'array';
    defaultValue: T;
    description?: string;
    validator?: ConfigValidator<T>;
    group?: string;
    tags?: string[];
}
type PlainObject = Record<string, unknown>;
export declare const validators: {
    /**
     * 字符串验证器
     */
    string: {
        required: () => ConfigValidator<string>;
        minLength: (min: number) => ConfigValidator<string>;
        maxLength: (max: number) => ConfigValidator<string>;
        pattern: (regex: RegExp, message?: string) => ConfigValidator<string>;
        oneOf: (options: string[]) => ConfigValidator<string>;
        color: () => ConfigValidator<string>;
        url: () => ConfigValidator<string>;
    };
    /**
     * 数字验证器
     */
    number: {
        required: () => ConfigValidator<number>;
        min: (min: number) => ConfigValidator<number>;
        max: (max: number) => ConfigValidator<number>;
        range: (min: number, max: number) => ConfigValidator<number>;
        integer: () => ConfigValidator<number>;
        positive: () => ConfigValidator<number>;
        percentage: () => ConfigValidator<number>;
    };
    /**
     * 布尔值验证器
     */
    boolean: {
        required: () => ConfigValidator<boolean>;
    };
    /**
     * 对象验证器
     */
    object: {
        required: () => ConfigValidator<object>;
        hasKeys: (keys: string[]) => ConfigValidator<PlainObject>;
        shape: (schema: Record<string, ConfigValidator<unknown>>) => ConfigValidator<PlainObject>;
    };
    /**
     * 数组验证器
     */
    array: {
        required: <T = unknown>() => ConfigValidator<T[]>;
        minLength: <T = unknown>(min: number) => ConfigValidator<T[]>;
        maxLength: <T = unknown>(max: number) => ConfigValidator<T[]>;
        items: <T = unknown>(itemValidator: ConfigValidator<T>) => ConfigValidator<T[]>;
    };
};
export declare const combineValidators: <T>(...validators: ConfigValidator<T>[]) => ConfigValidator<T>;
export declare const commonSchemas: ConfigSchema[];
export declare const validateConfigValue: (key: string, value: unknown, schemas?: ConfigSchema[]) => {
    isValid: boolean;
    error?: string;
    sanitizedValue?: unknown;
};
export declare const validateConfigBatch: (configs: unknown, schemas?: ConfigSchema[]) => {
    isValid: boolean;
    errors: Record<string, string>;
    sanitizedConfigs: Record<string, unknown>;
};
export {};
