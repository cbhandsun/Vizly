/** 统一配置项的数据模型与内置定义。 */
export declare enum ConfigSource {
    DEFAULT = "default",
    LOCAL_STORAGE = "localStorage",
    SESSION_STORAGE = "sessionStorage",
    REMOTE = "remote",
    ENVIRONMENT = "environment",
    USER_OVERRIDE = "userOverride"
}
export interface ConfigChangeEvent<T = unknown> {
    key: string;
    oldValue: T;
    newValue: T;
    source: ConfigSource;
    timestamp: number;
}
export type ConfigListener<T = unknown> = {
    bivarianceHack(event: ConfigChangeEvent<T>): void;
}['bivarianceHack'];
export type ConfigValidator<T = unknown> = {
    bivarianceHack(value: T): boolean | string;
}['bivarianceHack'];
export interface ConfigDefinition<T = unknown> {
    /** 配置键名 */
    key: string;
    /** 默认值 */
    defaultValue: T;
    /** 描述 */
    description?: string;
    /** 验证器 */
    validator?: ConfigValidator<T>;
    /** 是否持久化 */
    persistent?: boolean;
    /** 存储键名（用于持久化） */
    storageKey?: string;
    /** 是否敏感信息 */
    sensitive?: boolean;
    /** 配置分组 */
    group?: string;
}
export declare const CONFIG_DEFINITIONS: Record<string, ConfigDefinition>;
