/**
 * Ant Design 静态 API 桥接模块
 *
 * 解决 `message.success()`、`Modal.confirm()` 等静态调用丢失上下文的问题。
 *
 * 原理：
 * - Ant Design v5+ 的静态方法（如 `message.success`、`Modal.confirm`）无法消费 React 上下文，
 *   导致主题不生效、回调可能失效。
 * - 本模块通过 `AntdApiBridge` 组件在 `<AntdApp>` 内部调用 `App.useApp()`，
 *   捕获上下文感知的 API 实例，并导出为模块级的可直接调用对象。
 *
 * 使用方式：
 * ```ts
 * // 替换: import { message, Modal, notification } from 'antd';
 * import { appMessage, appModal, appNotification } from './antdStaticBridge';
 *
 * // 然后直接使用：
 * appMessage.success('操作成功');
 * appModal.confirm({ title: '确认', content: '...' });
 * ```
 */
import type { MessageInstance } from 'antd/es/message/interface';
import type { ModalStaticFunctions } from 'antd/es/modal/confirm';
import type { NotificationInstance } from 'antd/es/notification/interface';
/**
 * 注册上下文感知的 API 实例。
 * 由 AntdApiBridge 组件在首次渲染时调用。
 */
export declare function registerAntdApi(msg: MessageInstance, mdl: Omit<ModalStaticFunctions, 'warn'>, ntf: NotificationInstance): void;
/**
 * 上下文感知的 message API
 * 替代 `import { message } from 'antd'`
 */
export declare const appMessage: MessageInstance;
/**
 * 上下文感知的 modal API
 * 替代 `Modal.confirm()` / `Modal.info()` 等静态调用
 */
export declare const appModal: Omit<ModalStaticFunctions, "warn">;
/**
 * 上下文感知的 notification API
 * 替代 `import { notification } from 'antd'`
 */
export declare const appNotification: NotificationInstance;
