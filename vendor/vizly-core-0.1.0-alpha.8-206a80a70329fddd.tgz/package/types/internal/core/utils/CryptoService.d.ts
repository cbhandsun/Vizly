export declare class CryptoService {
    private static readonly LEGACY_SALT;
    private static readonly LOCAL_SECRET_SALT;
    private static keyCache;
    private static requireValidUserId;
    private static getSecretStorageKey;
    private static isValidLocalSecret;
    static clearKeyCache(): void;
    static clearUserSecret(userId: string): void;
    private static getOrCreateLocalSecret;
    /**
     * Derive an AES-GCM key from a per-user local secret.
     *
     * Threat boundary: the local secret prevents cloud ciphertext from being
     * decrypted with a public user id alone. It does not protect against
     * already-executing same-origin script, which can access browser storage.
     */
    static deriveKey(userId: string): Promise<CryptoKey>;
    private static deriveLegacyKey;
    /**
     * Encrypt text for a specific user.
     * Returns format: "ENC2:iv_b64:ciphertext_b64"
     */
    static encrypt(text: string, userId: string): Promise<string>;
    /**
     * Decrypt text deterministically for a specific user
     * Expects format: "ENC2:iv_b64:ciphertext_b64" or legacy "ENC:iv_b64:ciphertext_b64".
     */
    static decrypt(text: string, userId: string): Promise<string>;
    private static arrayBufferToBase64;
    private static base64ToArrayBuffer;
}
