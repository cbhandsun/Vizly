export declare const normalizeCollaborationRoomName: (roomName: unknown, fallback?: string) => string;
export declare const normalizeCollaborationDiagramId: (diagramId: unknown, fallback?: string) => string;
export declare const normalizeCollaborationToken: (token: unknown) => string | undefined;
export declare const normalizeCollaborationServerUrl: (serverUrl: unknown) => string | null;
