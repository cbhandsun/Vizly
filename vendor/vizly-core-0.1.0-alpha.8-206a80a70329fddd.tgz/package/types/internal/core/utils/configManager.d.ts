import { DiagramConfig } from '../types/common.js';
/**
 * 统一配置管理器
 * 整合所有图表的配置，避免重复定义
 */
export declare const BASE_CONFIG: {
    readonly CANVAS: {
        readonly WIDTH: number;
        readonly HEIGHT: 2400;
        readonly MIN_WIDTH: 1200;
        readonly MIN_HEIGHT: 800;
    };
    readonly NODE: {
        readonly WIDTH: 280;
        readonly HEIGHT: 120;
        readonly MIN_WIDTH: 200;
        readonly MIN_HEIGHT: 80;
        readonly TITLE_BAR_HEIGHT: 50;
    };
    readonly SPACING: {
        readonly HORIZONTAL: 100;
        readonly VERTICAL: 120;
        readonly GROUP_PADDING: {
            readonly H: 40;
            readonly V: 30;
        };
        readonly SUB_GROUP_PADDING: {
            readonly H: 20;
            readonly V_TOP: 60;
            readonly V_BOTTOM: 20;
        };
        readonly LANE_PADDING: {
            readonly X: 50;
            readonly Y: 70;
        };
        readonly MARGIN: 20;
    };
    readonly GAPS: {
        readonly MAIN_TO_SIDE: 60;
        readonly LAYER_VERTICAL: 60;
        readonly ROW_VERTICAL: 70;
        readonly FOUNDATION: 40;
        readonly COLUMN: 40;
    };
    readonly Z_INDEX: {
        readonly BACKGROUND: 0;
        readonly EDGE: 1;
        readonly NODE: 2;
        readonly GROUP: 3;
        readonly SUBGROUP: 4;
        readonly OVERLAY: 5;
    };
};
export declare const ARCHITECTURE_CONFIGS: {
    readonly LOGISTICS: {
        readonly SPACING: {
            readonly HORIZONTAL: 100;
            readonly VERTICAL: 120;
            readonly GROUP_PADDING: {
                readonly H: 40;
                readonly V: 30;
            };
            readonly SUB_GROUP_PADDING: {
                readonly H: 20;
                readonly V_TOP: 60;
                readonly V_BOTTOM: 20;
            };
            readonly LANE_PADDING: {
                readonly X: 50;
                readonly Y: 70;
            };
            readonly MARGIN: 20;
        };
        readonly Z_INDEX: {
            readonly BACKGROUND: 0;
            readonly EDGE: 1;
            readonly NODE: 2;
            readonly GROUP: 3;
            readonly SUBGROUP: 4;
            readonly OVERLAY: 5;
        };
        readonly CANVAS: {
            readonly MIN_WIDTH: 1200;
            readonly MIN_HEIGHT: 800;
            readonly WIDTH: number;
            readonly HEIGHT: 1800;
        };
        readonly NODE: {
            readonly WIDTH: 280;
            readonly MIN_WIDTH: 200;
            readonly MIN_HEIGHT: 80;
            readonly TITLE_BAR_HEIGHT: 50;
            readonly HEIGHT: 140;
        };
        readonly GAPS: {
            readonly MAIN_TO_SIDE: 60;
            readonly FOUNDATION: 40;
            readonly COLUMN: 40;
            readonly LAYER_VERTICAL: 80;
            readonly ROW_VERTICAL: 50;
        };
    };
    readonly WMS: {
        readonly SPACING: {
            readonly HORIZONTAL: 100;
            readonly VERTICAL: 120;
            readonly GROUP_PADDING: {
                readonly H: 40;
                readonly V: 30;
            };
            readonly SUB_GROUP_PADDING: {
                readonly H: 20;
                readonly V_TOP: 60;
                readonly V_BOTTOM: 20;
            };
            readonly LANE_PADDING: {
                readonly X: 50;
                readonly Y: 70;
            };
            readonly MARGIN: 20;
        };
        readonly Z_INDEX: {
            readonly BACKGROUND: 0;
            readonly EDGE: 1;
            readonly NODE: 2;
            readonly GROUP: 3;
            readonly SUBGROUP: 4;
            readonly OVERLAY: 5;
        };
        readonly CANVAS: {
            readonly WIDTH: number;
            readonly MIN_WIDTH: 1200;
            readonly MIN_HEIGHT: 800;
            readonly HEIGHT: 1600;
        };
        readonly NODE: {
            readonly WIDTH: 280;
            readonly MIN_WIDTH: 200;
            readonly MIN_HEIGHT: 80;
            readonly TITLE_BAR_HEIGHT: 50;
            readonly HEIGHT: 130;
        };
        readonly GAPS: {
            readonly MAIN_TO_SIDE: 60;
            readonly ROW_VERTICAL: 70;
            readonly FOUNDATION: 40;
            readonly COLUMN: 40;
            readonly LAYER_VERTICAL: 70;
        };
    };
    readonly TMS: {
        readonly SPACING: {
            readonly HORIZONTAL: 100;
            readonly VERTICAL: 120;
            readonly GROUP_PADDING: {
                readonly H: 40;
                readonly V: 30;
            };
            readonly SUB_GROUP_PADDING: {
                readonly H: 20;
                readonly V_TOP: 60;
                readonly V_BOTTOM: 20;
            };
            readonly LANE_PADDING: {
                readonly X: 50;
                readonly Y: 70;
            };
            readonly MARGIN: 20;
        };
        readonly Z_INDEX: {
            readonly BACKGROUND: 0;
            readonly EDGE: 1;
            readonly NODE: 2;
            readonly GROUP: 3;
            readonly SUBGROUP: 4;
            readonly OVERLAY: 5;
        };
        readonly CANVAS: {
            readonly WIDTH: number;
            readonly MIN_WIDTH: 1200;
            readonly MIN_HEIGHT: 800;
            readonly HEIGHT: 1600;
        };
        readonly NODE: {
            readonly WIDTH: 280;
            readonly MIN_WIDTH: 200;
            readonly MIN_HEIGHT: 80;
            readonly TITLE_BAR_HEIGHT: 50;
            readonly HEIGHT: 130;
        };
        readonly GAPS: {
            readonly MAIN_TO_SIDE: 60;
            readonly ROW_VERTICAL: 70;
            readonly FOUNDATION: 40;
            readonly COLUMN: 40;
            readonly LAYER_VERTICAL: 70;
        };
    };
    readonly SYSTEMS_INTERACTION: {
        readonly SPACING: {
            readonly HORIZONTAL: 100;
            readonly VERTICAL: 120;
            readonly GROUP_PADDING: {
                readonly H: 40;
                readonly V: 30;
            };
            readonly SUB_GROUP_PADDING: {
                readonly H: 20;
                readonly V_TOP: 60;
                readonly V_BOTTOM: 20;
            };
            readonly LANE_PADDING: {
                readonly X: 50;
                readonly Y: 70;
            };
            readonly MARGIN: 20;
        };
        readonly GAPS: {
            readonly MAIN_TO_SIDE: 60;
            readonly LAYER_VERTICAL: 60;
            readonly ROW_VERTICAL: 70;
            readonly FOUNDATION: 40;
            readonly COLUMN: 40;
        };
        readonly Z_INDEX: {
            readonly BACKGROUND: 0;
            readonly EDGE: 1;
            readonly NODE: 2;
            readonly GROUP: 3;
            readonly SUBGROUP: 4;
            readonly OVERLAY: 5;
        };
        readonly CANVAS: {
            readonly WIDTH: number;
            readonly MIN_WIDTH: 1200;
            readonly MIN_HEIGHT: 800;
            readonly HEIGHT: 2000;
        };
        readonly NODE: {
            readonly WIDTH: 280;
            readonly MIN_WIDTH: 200;
            readonly MIN_HEIGHT: 80;
            readonly TITLE_BAR_HEIGHT: 50;
            readonly HEIGHT: 110;
        };
    };
};
export declare class ConfigManager {
    private static instance;
    private configs;
    private constructor();
    static getInstance(): ConfigManager;
    private initializeDefaultConfigs;
    private createDiagramConfig;
    registerConfig(name: string, config: DiagramConfig): void;
    getConfig(name: string): DiagramConfig | undefined;
    getConfigOrDefault(name: string): DiagramConfig;
    getAllConfigs(): Map<string, DiagramConfig>;
    mergeConfig(baseName: string, overrides: Partial<DiagramConfig>): DiagramConfig;
    private deepMerge;
    createCustomConfig(baseConfigName: string, customizations: Partial<DiagramConfig>): DiagramConfig;
}
export declare const configManager: ConfigManager;
export declare const getConfig: (name: string) => DiagramConfig;
export declare const createConfig: (baseName: string, overrides: Partial<DiagramConfig>) => DiagramConfig;
