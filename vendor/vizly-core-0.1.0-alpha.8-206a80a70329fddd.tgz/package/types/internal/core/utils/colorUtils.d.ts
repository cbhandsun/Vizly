export type RGB = {
    r: number;
    g: number;
    b: number;
};
export type HSL = {
    h: number;
    s: number;
    l: number;
};
export declare function clamp(n: number, min?: number, max?: number): number;
export declare function parseColorToRgb(color: string): RGB;
export declare function rgbToHsl({ r, g, b }: RGB): HSL;
export declare function hslToRgb({ h, s, l }: HSL): RGB;
export declare function adjustSaturationAndLightness(rgb: RGB, saturateDelta?: number, lightnessDelta?: number): RGB;
export declare function toRgba({ r, g, b }: RGB, alpha?: number): string;
export declare function toAlphaColor(color: string, alpha?: number): string;
export declare function makeSoftTintGradient(baseColor: string, opts?: {
    topAlpha?: number;
    bottomAlpha?: number;
    saturateDelta?: number;
    lightnessDelta?: number;
}): string;
/**
 * 计算相对亮度（WCAG）
 * 输入：任意颜色字符串（#RGB/#RRGGBB/rgb/rgba）
 * 输出：0..1 的亮度值
 */
export declare function getRelativeLuminance(color: string): number;
/**
 * 判断颜色是否偏亮
  * 基于 WCAG 相对亮度，阈值默认 0.25
 */
export declare function isLightColor(color?: string, threshold?: number): boolean;
/**
 * 根据背景选择可读文本色
  * 动态计算浅色与深色对比度，始终返回对比度更高者
 */
export declare function pickReadableTextColor(bgColor: string, lightColor?: string, darkColor?: string): string;
/**
 * 计算前景与背景的对比度（WCAG 2.1）
 * 返回值：对比度比值（例如 4.5 表示达标的普通文本对比）
 */
export declare function getContrastRatio(fgColor: string, bgColor: string): number;
/**
 * 若对比度不足则替换为可读文本色
 */
export declare function ensureReadableText(fgColor: string | undefined, bgColor: string, minRatio?: number, lightColor?: string, darkColor?: string): string;
