/**
 * Console清理工具
 * 用于在生产环境中管理console输出
 */
export declare enum LogLevel {
    DEBUG = 0,
    INFO = 1,
    WARN = 2,
    ERROR = 3,
    NONE = 4
}
/**
 * 安全的console.log替代方案
 * 在生产环境中根据配置决定是否输出
 */
export declare const safeLog: {
    debug: (...args: unknown[]) => void;
    info: (...args: unknown[]) => void;
    warn: (...args: unknown[]) => void;
    error: (...args: unknown[]) => void;
    log: (...args: unknown[]) => void;
};
/**
 * 性能监控日志
 * 仅在开发环境中输出
 */
export declare const perfLog: {
    time: (label: string) => void;
    timeEnd: (label: string) => void;
    measure: (name: string, startMark?: string, endMark?: string) => void;
};
/**
 * 调试工具
 * 仅在开发环境中可用
 */
export declare const debugUtils: {
    /**
     * 条件日志输出
     */
    logIf: (condition: boolean, ...args: unknown[]) => void;
    /**
     * 对象深度检查
     */
    inspect: (obj: unknown, label?: string) => void;
    /**
     * 函数执行追踪
     */
    trace: <TArgs extends unknown[], TResult>(fn: (...args: TArgs) => TResult, context?: string) => ((...args: TArgs) => TResult);
};
/**
 * 清理现有的console语句
 * 在生产环境构建时使用
 */
export declare const cleanupConsole: () => void;
export declare const initDevConsoleFilters: () => void;
