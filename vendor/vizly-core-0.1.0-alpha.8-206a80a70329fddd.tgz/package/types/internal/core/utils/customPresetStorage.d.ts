import type { StandardDiagramData } from '../models/DiagramModels.js';
export declare const CUSTOM_PRESETS_STORAGE_KEY = "diagram-custom-presets";
export declare const CUSTOM_PRESETS_LIMIT = 100;
export declare const CUSTOM_PRESET_NAME_MAX_LENGTH = 120;
type CustomPresetChangeListener = () => void;
export declare const getCustomPresetRevision: () => number;
export declare const subscribeToCustomPresetChanges: (listener: CustomPresetChangeListener) => (() => void);
export declare const normalizeCustomPresetName: (value: unknown) => string | null;
export declare const normalizeCustomPresetLookupKey: (value: unknown) => string | null;
export declare const coerceCustomPreset: (value: unknown, fallback: {
    id: string;
    title: string;
}) => StandardDiagramData | null;
export declare const coerceCustomPresetMap: (value: unknown) => Record<string, StandardDiagramData>;
export declare const readCustomPresetMap: (storage?: Pick<Storage, 'getItem'>) => Record<string, StandardDiagramData>;
export declare const writeCustomPresetMap: (presets: Record<string, StandardDiagramData>, storage?: Pick<Storage, 'setItem'>) => Record<string, StandardDiagramData>;
export type CustomPresetSaveError = 'invalid' | 'capacity' | 'readFailed' | 'writeFailed';
export type CustomPresetDeleteError = 'invalid' | 'notFound' | 'readFailed' | 'writeFailed';
export type CustomPresetSaveResult = {
    ok: true;
    preset: StandardDiagramData;
} | {
    ok: false;
    error: CustomPresetSaveError;
};
type CustomPresetStorage = Pick<Storage, 'getItem' | 'setItem'>;
export declare const saveCustomPreset: (name: string, preset: unknown, storage?: CustomPresetStorage) => CustomPresetSaveResult;
export type CustomPresetDeleteResult = {
    ok: true;
    remainingCount: number;
} | {
    ok: false;
    error: CustomPresetDeleteError;
};
export declare const deleteCustomPreset: (name: string, storage?: CustomPresetStorage) => CustomPresetDeleteResult;
export declare const addCustomPreset: (name: string, preset: unknown, storage?: Pick<Storage, 'getItem' | 'setItem'>) => StandardDiagramData | null;
export declare const getCustomPreset: (leafKey: string, storage?: Pick<Storage, 'getItem'>) => StandardDiagramData | null;
export {};
