export interface FlowchartCacheClearFailure {
    storageType: 'localStorage' | 'sessionStorage';
    operation: 'enumerate' | 'remove';
    key?: string;
}
export interface FlowchartCacheClearResult {
    ok: boolean;
    removedCount: number;
    failures: FlowchartCacheClearFailure[];
}
export declare const getFlowchartRuntimeCacheKeysToClear: (storage: Pick<Storage, 'key' | 'length'>, diagramId?: string | null) => string[];
export declare const getViewportSessionCacheKeysToClear: (storage: Pick<Storage, 'key' | 'length'>, diagramId?: string | null) => string[];
export declare const getFlowchartCacheKeysToClear: (diagramId?: string | null) => {
    localStorageKeys: string[];
    sessionStorageKeys: string[];
};
export declare const clearFlowchartCache: (diagramId?: string | null) => FlowchartCacheClearResult;
