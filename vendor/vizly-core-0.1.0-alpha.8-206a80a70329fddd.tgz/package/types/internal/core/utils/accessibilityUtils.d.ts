/**
 * 可访问性工具集
 * 提供无障碍功能支持
 */
export declare const ARIA_ROLES: {
    readonly DIAGRAM: 'img';
    readonly NAVIGATION: 'navigation';
    readonly BUTTON: 'button';
    readonly MENU: 'menu';
    readonly MENUITEM: 'menuitem';
    readonly TOOLBAR: 'toolbar';
    readonly REGION: 'region';
    readonly COMPLEMENTARY: 'complementary';
    readonly MAIN: 'main';
};
export declare const KEYBOARD_KEYS: {
    readonly ENTER: 'Enter';
    readonly SPACE: ' ';
    readonly ESCAPE: 'Escape';
    readonly ARROW_UP: 'ArrowUp';
    readonly ARROW_DOWN: 'ArrowDown';
    readonly ARROW_LEFT: 'ArrowLeft';
    readonly ARROW_RIGHT: 'ArrowRight';
    readonly TAB: 'Tab';
    readonly HOME: 'Home';
    readonly END: 'End';
};
/**
 * 焦点管理Hook
 * 用于管理组件内的焦点状态
 */
export declare const useFocusManagement: () => {
    updateFocusableElements: (container: HTMLElement) => void;
    focusFirst: () => void;
    focusLast: () => void;
    focusNext: () => void;
    focusPrevious: () => void;
};
/**
 * 键盘导航Hook
 * 处理键盘事件和导航逻辑
 */
export declare const useKeyboardNavigation: (containerRef: React.RefObject<HTMLElement>, options?: {
    onEscape?: () => void;
    onEnter?: () => void;
    enableArrowKeys?: boolean;
    enableTabTrapping?: boolean;
}) => void;
/**
 * 屏幕阅读器公告Hook
 * 用于向屏幕阅读器用户提供实时反馈
 */
export declare const useScreenReaderAnnouncement: () => {
    announce: (message: string, priority?: 'polite' | 'assertive') => void;
};
/**
 * 高对比度检测Hook
 * 检测用户是否启用了高对比度模式
 */
export declare const useHighContrast: () => boolean;
/**
 * 减少动画检测Hook
 * 检测用户是否偏好减少动画
 */
export declare const useReducedMotion: () => boolean;
/**
 * 生成可访问的描述文本
 * 为图表元素生成屏幕阅读器友好的描述
 */
export declare const generateAccessibleDescription: (element: {
    type: 'node' | 'edge' | 'group';
    label: string;
    position?: {
        x: number;
        y: number;
    };
    connections?: string[];
    groupInfo?: {
        parent: string;
        children: string[];
    };
}) => string;
/**
 * 创建可访问的快捷键提示
 */
export declare const createKeyboardShortcutHint: (shortcuts: Record<string, string>) => string;
import React from 'react';
