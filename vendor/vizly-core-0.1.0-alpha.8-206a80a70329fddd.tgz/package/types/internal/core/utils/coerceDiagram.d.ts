import type { StandardDiagramData } from '../models/DiagramModels.js';
export type CoerceIssueLevel = 'warn' | 'error';
export interface CoerceIssue {
    level: CoerceIssueLevel;
    message: string;
}
export interface CoerceReport {
    diagram: StandardDiagramData;
    issues: CoerceIssue[];
}
export declare const MAX_STANDARD_DIAGRAM_GROUPS = 2000;
export declare const coerceToStandardDiagramDataWithReport: (input: unknown, fallback: {
    id: string;
    title?: string;
}) => CoerceReport;
export declare const coerceToStandardDiagramData: (input: unknown, fallback: {
    id: string;
    title?: string;
}) => StandardDiagramData;
