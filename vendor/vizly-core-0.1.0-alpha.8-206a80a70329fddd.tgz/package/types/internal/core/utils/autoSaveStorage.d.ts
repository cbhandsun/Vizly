import type { Edge, Node } from '@xyflow/react';
import type { RoutingOnlyDocumentSnapshot } from '../routing/persistedRoutingCandidate.js';
export declare const AUTOSAVE_PREFIX = "flowchart-autosave-v2-";
export declare const AUTOSAVE_GC_TTL_MS: number;
export declare const MAX_AUTOSAVE_JSON_CHARS: number;
export interface AutoSavePayload {
    diagramId?: string;
    routingVersion?: string;
    nodes: Node[];
    edges: Edge[];
    routingSnapshot?: RoutingOnlyDocumentSnapshot;
    timestamp?: number;
    lastAccessedAt?: number;
    version: '1.0';
    isFreshSeed?: boolean;
    requiresRecoveryReview?: boolean;
    layout?: unknown;
    metadata?: unknown;
}
export declare const coerceAutoSavePayload: (value: unknown) => AutoSavePayload | null;
export declare const createAutoSavePayload: (params: {
    diagramId?: string;
    routingVersion?: string;
    nodes: unknown[];
    edges: unknown[];
    routingSnapshot?: unknown;
    timestamp?: number;
    isFreshSeed?: boolean;
    requiresRecoveryReview?: boolean;
    layout?: unknown;
    metadata?: unknown;
}) => AutoSavePayload | null;
export declare const parseAutoSavePayload: (raw: string | null | undefined) => AutoSavePayload | null;
export declare const refreshAutoSaveAccess: (payload: AutoSavePayload, now?: number) => AutoSavePayload;
export declare const shouldCollectAutoSave: (payload: AutoSavePayload | null, now?: number) => boolean;
