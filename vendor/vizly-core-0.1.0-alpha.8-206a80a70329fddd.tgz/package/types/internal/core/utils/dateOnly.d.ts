export declare function formatDateOnly(date: Date): string;
export declare function todayDateOnly(): string;
export declare function parseDateOnlyTime(value: unknown): number | null;
export declare function addDaysToDateOnly(value: unknown, days: number, fallback?: string): string;
