export declare const sanitizeCssVariableDeclarations: (styles: Record<string, unknown>) => string[];
export declare const renderCssVariableBlock: (styles: Record<string, unknown>) => string;
