import { LayoutOptions } from '../../types/layout.js';
import { Position } from '../../types/common.js';
/**
 * 计算网格布局
 * @param items 要布局的元素数组
 * @param options 布局选项
 * @returns 每个元素的位置数组
 */
export declare function calculateGridLayout(items: unknown[], options: LayoutOptions): Position[];
export declare function calculateHorizontalLayout(items: unknown[], options: LayoutOptions): Position[];
export declare function calculateVerticalLayout(items: unknown[], options: LayoutOptions): Position[];
export declare function calculateCenteredLayout(items: unknown[], options: LayoutOptions): Position[];
/**
 * @param nodes 要布局的元素数组
 * @param edges 边数组
 * @param options 布局选项
 * @returns {{ positions: Position[], nodeRanks: Map<string, number> }} 返回一个包含节点位置数组和节点层级 Map 的对象
 */
export declare function calculateLayout(items: unknown[], options: LayoutOptions): Position[];
/**
 * 瀛愬煙瀹瑰櫒鍦ㄥ煙鍐呴儴姘村钩灞呬腑锛堝嚱鏁扮骇娉ㄩ噴锛?
 * 鐩爣锛氬湪鍩熷涓庡瓙鍩熸渶缁堝搴︾‘瀹氬悗锛屼娇姣忎釜鍙瀛愬煙瀹瑰櫒鍦ㄦ墍灞炲煙鍐呴儴鍙敤瀹藉害鍐呮按骞冲眳涓紝淇濊瘉宸﹀彸鐣欑櫧瀵圭О锛涘悓姝?children 鐨?x 骞崇Щ锛屼笉鏀瑰彉 y銆?
 */
