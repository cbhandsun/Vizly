import type { Edge, Node } from '@xyflow/react';
export declare const sanitizeCanvasEdgesForNodes: (nodes: readonly Node[], edges: readonly Edge[]) => Edge[];
