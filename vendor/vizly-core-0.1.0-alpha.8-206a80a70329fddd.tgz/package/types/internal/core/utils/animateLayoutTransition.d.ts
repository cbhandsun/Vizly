import { Node } from '@xyflow/react';
/**
 * Run layout reconciliation after two render frames, but preserve liveness when
 * an embedded preview or background tab suspends requestAnimationFrame.
 */
export declare function runAfterLayoutRenderFrames(callback: () => void): Promise<void>;
export declare function cancelLayoutTransition(setNodes: React.Dispatch<React.SetStateAction<Node[]>>): void;
export declare function suspendLayoutTransitions(setNodes: React.Dispatch<React.SetStateAction<Node[]>>, duration?: number): void;
/**
 * 布局过渡动画：从当前位置平滑插值到目标位置
 *
 * @param setNodes    - React Flow 的 setNodes（支持 updater 函数模式）
 * @param targetNodes - 布局计算后的目标节点（含最终 position）
 * @param options     - 可选配置
 * @returns Promise   - 动画结束后 resolve
 *
 * 核心机制：
 * 1. 从 setNodes 回调读取每个节点的当前位置（避免 stale state）
 * 2. 构建 id→{from, to} 映射
 * 3. RAF 循环中按 easing 插值更新 position
 * 4. 结束后精确设置目标位置
 *
 * 性能保障：
 * - 节点数 > ANIMATION_NODE_THRESHOLD 时直接跳变
 * - 动画帧只改 position，不触碰 data/style/className
 * - 不在 targetNodes 中的节点保持不动
 */
export declare function animateLayoutTransition(setNodes: React.Dispatch<React.SetStateAction<Node[]>>, targetNodes: Node[], options?: {
    duration?: number;
    easing?: (t: number) => number;
    onComplete?: () => void;
}): Promise<void>;
