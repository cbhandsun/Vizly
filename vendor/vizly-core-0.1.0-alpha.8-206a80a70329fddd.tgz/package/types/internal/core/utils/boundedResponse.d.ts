export declare class ResponseTooLargeError extends Error {
    readonly maxChars: number;
    constructor(maxChars: number);
}
export declare class RequestTimeoutError extends Error {
    readonly timeoutMs: number;
    constructor(timeoutMs: number);
}
export declare const readResponseTextWithLimit: (response: Response, maxChars: number) => Promise<string>;
export declare const readResponseJsonWithLimit: (response: Response, maxChars: number) => Promise<unknown>;
export interface FetchWithTimeoutOptions extends RequestInit {
    timeoutMs: number;
    fetchImplementation?: typeof fetch;
}
export declare const fetchWithTimeout: (input: RequestInfo | URL, { timeoutMs, fetchImplementation, signal, ...init }: FetchWithTimeoutOptions) => Promise<Response>;
