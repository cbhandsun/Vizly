export declare const logBasePluginStandardDataCoercionFailure: (pluginId: string, error: unknown) => void;
