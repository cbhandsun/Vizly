import React from 'react';
import type { Node, Edge, NodeTypes, EdgeTypes } from '@xyflow/react';
import { DiagramTypePlugin, PluginContext, SidebarPanel, KeyboardShortcut, CommandItem, PropertyEditorExtension } from '../types/plugin.js';
/**
 * BaseDiagramPlugin - Vizly 插件基类
 *
 * 提供了标准的插件接口实现与辅助工具，降低插件开发门槛。
 * 兼容 StandardDiagramData 标准化数据文件。
 */
export declare abstract class BaseDiagramPlugin implements DiagramTypePlugin {
    abstract id: string;
    abstract name: string;
    icon?: React.ReactNode;
    version: string;
    /**
     * 生命周期：图表初始化
     */
    onInit?(ctx: PluginContext): void | Promise<void>;
    /**
     * 生命周期：插件卸载
     */
    onDestroy?(ctx: PluginContext): void | Promise<void>;
    /**
     * 生命周期：捕获旧版本数据并洗牌升迁至当前最新结构
     */
    migrate<T>(data: T, _fromVersion: string | undefined): Promise<T>;
    /**
     * 将外部数据源解析为 ReactFlow nodes/edges
     * 自动支持 StandardDiagramData 格式的识别与转换
     */
    parseData(source: unknown): {
        nodes: Node[];
        edges: Edge[];
    };
    /**
     * 将 ReactFlow 状态序列化回领域数据
     */
    serializeData(nodes: Node[], edges: Edge[]): unknown;
    /**
     * 创建空白画布的初始数据
     */
    getEmptyState(): {
        nodes: Node[];
        edges: Edge[];
    };
    getSupportedLayouts(): string[];
    getDefaultLayout(): string;
    getNodeTypes(): NodeTypes;
    getEdgeTypes(): EdgeTypes;
    contributeToolbar?(_ctx: PluginContext): React.ReactNode;
    contributeSidebarPanels?(_ctx: PluginContext): SidebarPanel[];
    contributeShortcuts?(_ctx: PluginContext): KeyboardShortcut[];
    contributeCommands?(_ctx: PluginContext): CommandItem[];
    contributePropertyEditors?(_ctx: PluginContext): PropertyEditorExtension[];
    /** 分发全局事件 */
    protected emit(eventName: string, detail?: unknown): void;
    /** 显示通知 (通过 UI 系统监听的事件) */
    protected notify(message: string, type?: 'info' | 'success' | 'warning' | 'error'): void;
    /** 触发自动视图适配 */
    protected fitView(ctx: PluginContext, duration?: number): void;
}
