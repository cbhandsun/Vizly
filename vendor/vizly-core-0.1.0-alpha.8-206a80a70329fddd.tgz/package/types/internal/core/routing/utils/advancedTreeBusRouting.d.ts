export interface TreeBusRoutingOptions {
    enabled?: boolean;
    minBusSize?: number;
    trunkLength?: number;
    branchSpacing?: number;
    layoutDirection?: string;
}
export declare function optimizeTreeBusRouting<T extends {
    id: string;
    source: string;
    target: string;
    sourceHandle?: string | null;
    targetHandle?: string | null;
    data?: unknown;
}>(edges: T[], nodes: unknown, options?: TreeBusRoutingOptions): T[];
