interface TreeBusEdge {
    id: string;
    source: string;
    target: string;
    data?: unknown;
}
export declare const postProcessTreeBusRouting: <T extends TreeBusEdge>(edges: T[]) => T[];
export {};
