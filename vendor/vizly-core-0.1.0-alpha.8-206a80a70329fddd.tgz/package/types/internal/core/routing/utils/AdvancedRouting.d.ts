/**
 * Advanced Routing Features
 *
 * 包含 P2-P8 高级路由特性，从 HandlePicker 迁移而来。
 * 对应 Implementation Plan Phase 1.2
 */
import { Point } from '../types/routing.js';
export interface AdvancedRoutingNode {
    id: string;
    position?: Point;
    positionAbsolute?: Point;
    measured?: {
        width?: number;
        height?: number;
    };
}
interface AdvancedRoutingEdge {
    id: string;
    source: string;
    target: string;
    data?: Record<string, unknown>;
}
export declare function globalOptimizeEdgeRouting<T extends AdvancedRoutingEdge & {
    sourceHandle?: string | null;
    targetHandle?: string | null;
    type?: string;
}>(edges: T[], nodes: AdvancedRoutingNode[], cfg: {
    mode: 'advanced-smart' | 'native';
    globalPath?: string;
    layoutDirection?: string;
    directionalHandlePolicy?: 'prefer' | 'force' | 'off';
    angleToleranceDeg?: number;
    topK?: number;
    preAssignedPorts?: Record<string, {
        source?: string;
        target?: string;
    }>;
}, maxIterations?: number): T[];
export declare function bundleEdges<T extends AdvancedRoutingEdge>(edges: T[], nodes: AdvancedRoutingNode[], options?: {
    enabled?: boolean;
    regionSize?: number;
    minBundleSize?: number;
    bundleSpacing?: number;
    layoutDirection?: string;
}): T[];
export declare function layerBasedEdgeRouting<T extends AdvancedRoutingEdge>(edges: T[], nodes: AdvancedRoutingNode[], options?: {
    enabled?: boolean;
    layerThreshold?: number;
    maxControlPoints?: number;
    layoutDirection?: string;
}): T[];
export declare function optimizeEdgeLabelPositions<T extends AdvancedRoutingEdge & {
    sourceHandle?: string | null;
    targetHandle?: string | null;
    label?: unknown;
}>(edges: T[], nodes: AdvancedRoutingNode[], options?: {
    enabled?: boolean;
    labelPadding?: number;
    labelWidth?: number;
    labelHeight?: number;
}): T[];
export declare function beautifyOrthogonalEdges<T extends AdvancedRoutingEdge & {
    sourceHandle?: string | null;
    targetHandle?: string | null;
}>(edges: T[], nodes: AdvancedRoutingNode[], options?: {
    enabled?: boolean;
    minSegmentLength?: number;
    straightenThreshold?: number;
}): T[];
export { optimizeTreeBusRouting } from './advancedTreeBusRouting.js';
