/**
 * 成本评估器
 *
 * 职责:
 * - 计算路径成本
 * - 应用权重系统
 * - 支持插件扩展
 */
import type { CostContext, CostResult, RoutingPlugin } from '../types/routing.js';
export declare class CostEvaluator {
    private plugins;
    /**
     * 注册成本插件
     */
    registerPlugin(plugin: RoutingPlugin): void;
    /**
     * 评估总成本
     */
    evaluate(context: CostContext): CostResult;
    /**
     * 评估路径长度成本 (使用曼哈顿距离)
     */
    private evaluateLength;
    /**
     * 评估转弯成本
     *
     * [OPT-P1③] 由"方向不同 = 一次固定惩罚"升级为基于端口对的精确转弯次数估算：
     * - 0 次转弯：直通路径 (r→l, l→r, b→t, t→b，且沿正确轴方向)
     * - 1 次转弯：L 形路径 (水平端口 → 垂直端口，或反之)
     * - 2 次转弯：U 形/Z 形 (同侧端口 r→r，或反向端口 r→r 等)
     */
    private evaluateTurns;
    /**
     * 评估穿越障碍物成本
     */
    private evaluateCrossings;
    /**
     * 评估与已路由边的交叉成本。
     *
     * DomainDagre 会把前面已经确定的路径放进 config.routedPaths。这里仅用
     * 候选端口生成一条轻量的正交估算路径，作为端口选择阶段的软惩罚：
     * 不强制改道，但在成本接近时优先选择少交叉的端口。
     */
    private evaluateEdgeCrossings;
    private buildOrthogonalEstimate;
    private segmentsIntersect;
    private orientation;
    private onSegment;
    private pointsNear;
    /**
     * 评估方向成本 - 包含核心逻辑 (反向、L型、Z型、Flow等)
     */
    private evaluateDirection;
    /**
     * 评估端口使用成本 (智能端口分布优化)
     *
     * [ENHANCED] 使用更激进的惩罚策略：
     * - 0-2条边: 线性惩罚
     * - 3+条边: 指数惩罚 (幂次2.5)
     *
     * 这样可以强烈鼓励边使用不同的端口，避免重叠。
     */
    private evaluateUsage;
    /**
     * 辅助:检查线段是否与矩形相交
     */
    private lineIntersectsRect;
}
export declare const costEvaluator: CostEvaluator;
