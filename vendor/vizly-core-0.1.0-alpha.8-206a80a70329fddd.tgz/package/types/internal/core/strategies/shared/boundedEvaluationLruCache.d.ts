export type BoundedEvaluationCacheSlots = Readonly<{
    edges: number;
    segments: number;
    pairs: number;
}>;
export type BoundedEvaluationCacheLimits = Readonly<{
    entries: number;
    edgeSlots: number;
    segmentSlots: number;
    pairSlots: number;
}>;
/**
 * A small strong-reference LRU for derived graph snapshots. Entry and slot
 * budgets bound retained memory independently of the number of signatures
 * observed over the lifetime of the application.
 */
export declare class BoundedEvaluationLruCache<Value> {
    #private;
    constructor(limits: BoundedEvaluationCacheLimits);
    get size(): number;
    get(key: string): Value | undefined;
    set(key: string, value: Value, rawSlots: BoundedEvaluationCacheSlots): boolean;
}
