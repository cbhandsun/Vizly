export declare function rememberBoundedSignatureValue<T>(cache: Map<string, T>, signature: string, value: T, limit: number): void;
export declare function readSignatureValue<T>(cache: Map<string, T>, signature: string): T | undefined;
