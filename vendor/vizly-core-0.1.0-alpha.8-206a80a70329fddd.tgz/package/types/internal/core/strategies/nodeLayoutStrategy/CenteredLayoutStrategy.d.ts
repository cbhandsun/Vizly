import type { Node as ReactFlowNode, Edge } from '@xyflow/react';
import type { LayoutOptions } from '../../types/layout.js';
import { ILayoutStrategy } from '../LayoutStrategyManager.js';
type LayoutNode = ReactFlowNode<Record<string, unknown>>;
/**
 * 居中布局策略
 * 函数级注释：
 * - 单节点居中，多节点采用居中网格；
 * - 仅定位普通节点，更新子组容器以严格包含；
 * - 使用 DiagramConfig 的子组内边距与标题安全间隔。
 */
export declare class CenteredLayoutStrategy implements ILayoutStrategy {
    /** 获取策略名称 */
    getName(): string;
    /** 函数级注释：策略类别 */
    getCategory(): 'hierarchy' | 'node';
    /** 获取策略描述 */
    getDescription(): string;
    /** 适用性检查：只要有节点即可 */
    isApplicable(nodes: ReactFlowNode[], _edges: Edge[]): boolean;
    /**
     * 计算布局
     * 函数级注释：
     * - 调用通用居中布局函数获取坐标；
     * - 应用坐标到普通节点；
     * - 调整子组容器尺寸与位置以严格包含 children 并保留标题安全区。
     */
    /**
     * 函数级注释：支持 ELK 作为节点布局引擎
     * - 当 options.nodeLayout 映射为 'elk' 时，使用 elkjs layered 对普通节点进行分层排布
     * - 否则沿用通居中布局算法
     */
    calculateLayout(nodes: LayoutNode[], edges: Edge[], options: LayoutOptions): Promise<{
        nodes: LayoutNode[];
        edges: Edge[];
    }>;
}
export default CenteredLayoutStrategy;
