import type { Node as ReactFlowNode, Edge } from '@xyflow/react';
import type { LayoutOptions } from '../../types/layout.js';
import { ILayoutStrategy } from '../LayoutStrategyManager.js';
/**
 * Dagre 分层布局策略（节点布局）
 * 函数级注释：
 * - 使用 dagre 算法对子域内节点进行分层布局
 * - 支持语义顺序（sequence/order）和边关系驱动的分层
 * - 默认使用 TB（从上到下）布局方向
 */
export declare class DagreLayoutStrategy implements ILayoutStrategy {
    /** 获取策略名称 */
    getName(): string;
    /** 函数级注释：策略类别 - 节点布局 */
    getCategory(): 'hierarchy' | 'node';
    /** 获取策略描述 */
    getDescription(): string;
    /** 适用性检查：只要有节点即可 */
    isApplicable(nodes: ReactFlowNode[], _edges: Edge[]): boolean;
    /**
     * 计算布局
     * 函数级注释：
     * - 生成域/子域容器
     * - 使用 dagre 对每个子域内的节点进行分层布局
     * - 调整容器尺寸以包含子节点
     */
    calculateLayout(nodes: ReactFlowNode[], edges: Edge[], options: LayoutOptions): Promise<{
        nodes: ReactFlowNode[];
        edges: Edge[];
    }>;
}
export default DagreLayoutStrategy;
