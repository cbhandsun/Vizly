import type { Node as ReactFlowNode, Edge } from '@xyflow/react';
import type { ElkNode } from 'elkjs';
import type { LayoutOptions } from '../types/layout.js';
import type { LayoutCalculationContext } from '../types/layout-strategy.js';
import { ILayoutStrategy } from './LayoutStrategyManager.js';
export interface ElkLayoutResult {
    nodes: ReactFlowNode[];
    edges: Edge[];
}
declare const isGroupType: (type: unknown) => boolean;
/**
 * ELK child coordinates are relative to their compound parent. React Flow uses
 * the same contract. The returned ELK tree is authoritative: layout switches
 * deliberately clear the previous hierarchy, so it cannot determine whether
 * a new compound child uses relative coordinates. Only root children receive
 * the canvas padding/absolute offset.
 */
export declare const applyElkResultNodeGeometry: (children: ElkNode[] | undefined, nodeById: Map<string, ReactFlowNode>, padding: {
    x: number;
    y: number;
}) => ReactFlowNode[];
export declare abstract class AbstractElkLayoutStrategy implements ILayoutStrategy {
    abstract getName(): string;
    abstract getCategory(): 'hierarchy' | 'node';
    abstract getDescription(): string;
    isApplicable(nodes: ReactFlowNode[], _edges: Edge[]): boolean;
    /**
     * 通用数据准备流程
     * 包括：计算Padding、数据清洗、分组、显隐性处理
     */
    protected prepareData(nodes: ReactFlowNode[], options: LayoutOptions): {
        updatedNodes: ReactFlowNode[];
        padding: {
            x: number;
            y: number;
        };
    };
    /**
     * 执行 Worker 布局并回填结果
     */
    protected runWorkerLayout(elkGraph: ElkNode, updatedNodes: ReactFlowNode[], edges: Edge[], padding: {
        x: number;
        y: number;
    }, context?: LayoutCalculationContext): Promise<ElkLayoutResult>;
    /**
     * 子类需实现的构建图逻辑
     */
    protected abstract buildElkGraph(nodes: ReactFlowNode[], edges: Edge[], options: LayoutOptions): ElkNode;
    /**
     * 主入口
     */
    calculateLayout(nodes: ReactFlowNode[], edges: Edge[], options: LayoutOptions, context?: LayoutCalculationContext): Promise<ElkLayoutResult>;
    protected getConfig(): import("../config/DiagramConfigTypes.js").DiagramConfig;
    protected getHelpers(nodes: ReactFlowNode[]): {
        idMap: Map<string, ReactFlowNode>;
        isGroupType: typeof isGroupType;
        domainOf: (x: ReactFlowNode) => string;
        getW: (n: ReactFlowNode) => number;
        getH: (n: ReactFlowNode) => number;
        cfg: import("../config/DiagramConfigTypes.js").DiagramConfig;
    };
}
export {};
