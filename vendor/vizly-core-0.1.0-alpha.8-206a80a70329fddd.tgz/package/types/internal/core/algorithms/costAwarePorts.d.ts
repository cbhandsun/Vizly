import { Position, type EdgeConstraint, type PortSelectionConfig } from '../types/routing.js';
import type { LineObstacle, Rectangle } from './pathfinding.js';
import { SpatialIndex } from './SpatialIndex.js';
import type { NodeRect, PortCandidate } from './costAwarePortTypes.js';
export type { NodeRect, PortCandidate } from './costAwarePortTypes.js';
/**
 * Get the connection point on a node's edge based on position
 */
export declare function selectOptimalPorts(sourceNode: NodeRect, targetNode: NodeRect, obstacles: Rectangle[] | SpatialIndex, lineObstacles?: LineObstacle[], inputConfig?: Partial<PortSelectionConfig>, dynamicObstacles?: Rectangle[], // [NEW]
constraints?: EdgeConstraint): {
    sourcePos: Position;
    targetPos: Position;
    confidence: number;
    estimatedCost: number;
    allCandidates?: PortCandidate[];
    debugInfo?: unknown;
};
/**
 * Quick port selection using geometric heuristics only
 * (No obstacle checking - faster for initial layout)
 */
export declare function selectQuickPorts(sourceNode: NodeRect, targetNode: NodeRect): {
    sourcePos: Position;
    targetPos: Position;
};
export default selectOptimalPorts;
