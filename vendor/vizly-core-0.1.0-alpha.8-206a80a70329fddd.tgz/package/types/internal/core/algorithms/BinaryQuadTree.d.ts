/**
 * Binary QuadTree Implementation
 *
 * A SpatialIndex implementation that works directly with Float32Array data.
 * Reduces memory overhead by avoiding Rectangle object creation for static obstacles.
 *
 * Hybrid Architecture:
 * - Static Layer: Read-only views into the Float32Array
 * - Dynamic Layer: Standard array for runtime additions (Source/Target padding)
 */
import { Rectangle } from './pathfinding.js';
import { SpatialIndex } from './SpatialIndex.js';
export declare class BinaryQuadTree implements SpatialIndex {
    private buffer;
    private bufferCount;
    private dynamicItems;
    private bounds;
    private root;
    constructor(buffer: Float32Array, bounds?: Rectangle);
    private calculateBounds;
    private build;
    insert(item: Rectangle): void;
    remove(item: Rectangle): void;
    query(range: Rectangle): Rectangle[];
    queryLine(x1: number, y1: number, x2: number, y2: number): Rectangle[];
    getAll(): Rectangle[];
    clear(): void;
    private intersects;
}
