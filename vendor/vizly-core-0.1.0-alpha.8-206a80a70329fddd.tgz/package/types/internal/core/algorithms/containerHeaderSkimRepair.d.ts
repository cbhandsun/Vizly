import type { Point, Rectangle } from '../types/routing.js';
export interface RoutingNodeRect extends Rectangle {
    id: string;
    type?: string;
}
export interface ContainerHeaderSkimRepairOptions {
    edgeId: string;
    sourceId: string;
    targetId: string;
    nodes: RoutingNodeRect[];
    obstacles?: Rectangle[];
    otherPaths?: Map<string, Point[]>;
    clearance?: number;
}
export declare const recommendedEndpointEntryStub: (node: Pick<Rectangle, 'width' | 'height'>) => number;
export declare function repairEndpointPortConstraintPath(points: Point[], options: ContainerHeaderSkimRepairOptions): Point[] | null;
export declare function repairTangentialEndpointEntryPath(points: Point[], options: ContainerHeaderSkimRepairOptions): Point[] | null;
export declare function repairDirectionalSourceExitPath(points: Point[], options: ContainerHeaderSkimRepairOptions): Point[] | null;
export declare function repairContainerHeaderSkimPath(points: Point[], options: ContainerHeaderSkimRepairOptions): Point[] | null;
export declare function detectContainerHeaderSkimRisk(points: Point[], options: Pick<ContainerHeaderSkimRepairOptions, 'sourceId' | 'targetId' | 'nodes'>): boolean;
