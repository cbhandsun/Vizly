/**
 * 交叉优化器 (Crossing Minimizer)
 *
 * 通过分层和排序算法主动减少图中的边交叉，改善视觉质量。
 *
 * 核心算法：
 * 1. Layer Assignment: 基于拓扑排序分配层级
 * 2. Crossing Reduction: 使用Barycenter启发式减少交叉
 * 3. Order Optimization: 层内排序优化
 *
 * 适用场景：
 * - 层次化布局（Hierarchical Layout）
 * - 流程图（Flowchart）
 * - DAG（有向无环图）
 *
 * @module CrossingMinimizer
 */
import type { Edge } from '@xyflow/react';
/**
 * 边元数据
 */
export interface EdgeMetadata {
    id: string;
    sourceId: string;
    targetId: string;
    layer?: number;
    order?: number;
    crossingCount?: number;
}
/**
 * 层信息
 */
export interface LayerInfo {
    level: number;
    edges: EdgeMetadata[];
    crossingCount: number;
}
/**
 * 优化配置
 */
export interface CrossingOptimizerConfig {
    /** 是否启用分层优化（默认true） */
    enableLayering?: boolean;
    /** 是否启用Barycenter启发式（默认true） */
    enableBarycenter?: boolean;
    /** 最大迭代次数（默认10） */
    maxIterations?: number;
    /** 是否启用调试日志 */
    debug?: boolean;
}
/**
 * 优化结果
 */
export interface OptimizationResult {
    /** 优化后的边列表（按绘制顺序） */
    orderedEdges: EdgeMetadata[];
    /** 层信息 */
    layers: LayerInfo[];
    /** 总交叉数 */
    totalCrossings: number;
    /** 优化前交叉数 */
    initialCrossings: number;
    /** 减少的交叉数 */
    improvement: number;
}
/**
 * 交叉优化器
 */
export declare class CrossingMinimizer {
    private config;
    constructor(config?: CrossingOptimizerConfig);
    /**
     * 优化边的绘制顺序以减少交叉
     *
     * @param edges 边列表
     * @returns 优化结果
     */
    optimize(edges: Edge[]): OptimizationResult;
    /**
     * 转换为元数据
     */
    private toMetadata;
    /**
     * 分配层级
     *
     * 简化版：基于source/target位置的启发式分层
     * （完整版应使用拓扑排序和最长路径算法）
     */
    private assignLayers;
    /**
     * Hash函数：将节点ID映射到层级
     */
    private hashToLayer;
    /**
     * 使用Barycenter启发式减少交叉
     *
     * 算法：
     * 1. 计算每条边的barycenter（重心）
     * 2. 按barycenter排序
     * 3. 迭代优化直到收敛
     */
    private reduceCrossings;
    /**
     * 按Barycenter排序边
     *
     * Barycenter = 相邻边的平均位置
     */
    private sortByBarycenter;
    /**
     * 计算边的Barycenter
     *
     * 简化实现：使用source/target ID的数值化表示
     */
    private calculateBarycenter;
    /**
     * 字符串转数值
     */
    private stringToNumber;
    /**
     * 计算所有层的总交叉数
     */
    private countTotalLayerCrossings;
    /**
     * 计算单层内的交叉数
     */
    private countLayerCrossings;
    /**
     * 计算所有边的交叉数
     */
    private countCrossings;
    /**
     * 判断两条边是否交叉
     *
     * 简化实现：基于source/target ID的比较
     * 完整实现需要实际的几何计算
     */
    private edgesCross;
    /**
     * 调试日志
     */
    private log;
    /**
     * 更新配置
     */
    updateConfig(config: Partial<CrossingOptimizerConfig>): void;
    /**
     * 获取当前配置
     */
    getConfig(): Readonly<Required<CrossingOptimizerConfig>>;
}
/**
 * 便捷函数：快速优化边顺序
 */
export declare function minimizeCrossings(edges: Edge[], config?: CrossingOptimizerConfig): EdgeMetadata[];
