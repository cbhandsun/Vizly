import { Position } from '../types/flow.js';
import type { PortSelectionConfig } from '../types/routing.js';
import type { LineObstacle, Point } from './pathfinding.js';
import type { NodeRect } from './costAwarePortTypes.js';
export declare function getPortPoint(node: NodeRect, pos: Position, targetCenter?: Point, config?: Partial<PortSelectionConfig>): Point;
/**
 * Estimate the number of bends in a simple orthogonal path
 */
export declare function estimateBendCount(sourcePort: Point, targetPort: Point, sourcePos: Position, targetPos: Position): number;
/**
 * Check if the port direction is geometrically valid
 * Uses dynamic threshold based on distance rather than fixed 50px
 * (i.e., doesn't point away from target in a way that causes excessive detour)
 */
export declare function isPortDirectionValid(sourcePort: Point, targetPort: Point, sourcePos: Position, targetPos: Position): boolean;
/**
 * Generate a quick probe path for cost estimation
 */
export declare function generateProbePath(sourcePort: Point, targetPort: Point, sourcePos: Position, targetPos: Position, stubLength?: number): Point[];
/**
 * Calculate Manhattan distance of a path
 */
export declare function calculatePathLength(path: Point[]): number;
/**
 * Check if path crosses any existing line obstacles
 */
export declare function countLineCrossings(path: Point[], lineObstacles: LineObstacle[]): number;
/**
 * Evaluate a single port combination
 */
