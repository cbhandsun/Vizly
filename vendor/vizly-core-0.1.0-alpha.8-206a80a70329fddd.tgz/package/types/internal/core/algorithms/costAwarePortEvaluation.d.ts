import { Position } from '../types/flow.js';
import type { PortSelectionConfig } from '../types/routing.js';
import { type LineObstacle, type Rectangle } from './pathfinding.js';
import { SpatialIndex } from './SpatialIndex.js';
import type { NodeRect, PortCandidate } from './costAwarePortTypes.js';
export declare function evaluatePortCombination(sourceNode: NodeRect, targetNode: NodeRect, sourcePos: Position, targetPos: Position, obstacles: Rectangle[] | SpatialIndex, lineObstacles: LineObstacle[], config: PortSelectionConfig, dynamicObstacles?: Rectangle[]): PortCandidate;
/**
 * Select optimal port combination for an edge
 *
 * @param sourceNode - Source node rectangle
 * @param targetNode - Target node rectangle
 * @param obstacles - Obstacle rectangles to avoid
 * @param lineObstacles - Existing line segments to avoid
 * @param constraints - [Phase 5] Edge constraints for custom routing behavior
 * @returns Best port combination with confidence score
 */
