/** Selects a bounded routing grid size from route distance and configured precision. */
export declare const calculateAdaptiveGridSize: (sourceX: number, sourceY: number, targetX: number, targetY: number, configuredGridSize: number) => number;
