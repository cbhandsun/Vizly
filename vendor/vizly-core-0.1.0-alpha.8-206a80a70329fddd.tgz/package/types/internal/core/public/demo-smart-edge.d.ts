export { default } from '../components/diagrams/SmartEdgeDemoEnhanced.js';
