export { default } from '../components/diagrams/EdgeModeTest.js';
