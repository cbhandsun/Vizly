export { AUTOSAVE_PREFIX, createAutoSavePayload, parseAutoSavePayload, } from '../utils/autoSaveStorage.js';
export type { AutoSavePayload } from '../utils/autoSaveStorage.js';
export { getDiagramDocTypeFromStorage, readDiagramConfigIndex, upsertDiagramConfigIndex, } from '../utils/diagramTypeStorage.js';
export type { DiagramConfigIndexEntry } from '../utils/diagramTypeStorage.js';
