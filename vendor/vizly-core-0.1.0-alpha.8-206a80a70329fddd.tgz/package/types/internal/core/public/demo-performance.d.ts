export { PerformanceDemo } from '../components/diagrams/PerformanceDemo.js';
