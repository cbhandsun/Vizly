export { AntdApiBridge } from '../components/shared/AntdApiBridge.js';
export { appMessage, appModal, appNotification, registerAntdApi, } from '../utils/antdStaticBridge.js';
