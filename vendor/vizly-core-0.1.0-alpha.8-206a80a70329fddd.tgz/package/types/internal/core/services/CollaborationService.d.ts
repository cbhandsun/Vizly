import * as Y from 'yjs';
import { WebsocketProvider } from 'y-websocket';
export interface CollaborationUser {
    id: string;
    name: string;
    color: string;
    avatar?: string;
    cursor?: {
        x: number;
        y: number;
    };
}
declare class CollaborationService {
    private doc;
    private provider;
    private userId;
    private userName;
    private userColor;
    /**
     * 初始化协同会话。
     * 若未配置 VITE_YJS_WS_URL 环境变量，则以离线（local-only）模式运行：
     * 仍然创建 Y.Doc，但不建立 WebSocket 连接。
     */
    init(diagramId: string, user?: {
        id: string;
        name: string;
    }): void;
    getDoc(): Y.Doc;
    /**
     * Returns the WebsocketProvider, or throws if collaboration is offline.
     * Prefer `getProviderSafe()` when callers may run without a WS connection.
     */
    getProvider(): WebsocketProvider;
    /**
     * [Safe variant] Returns the WebsocketProvider, or null if not connected.
     * Use this in all UI components to avoid crashes in offline/local mode.
     */
    getProviderSafe(): WebsocketProvider | null;
    /**
     * Returns the Awareness instance, or null if not connected.
     * Use this in place of `getAwareness()` in components that render in offline mode.
     */
    getAwarenessSafe(): import("y-protocols/awareness.js").Awareness | null;
    /**
     * @deprecated Prefer getAwarenessSafe() — this throws when provider is null.
     */
    getAwareness(): import("y-protocols/awareness.js").Awareness;
    getLocalUser(): CollaborationUser;
    /**
     * True only when a live WebSocket connection has been established.
     * Returns false in local-only (offline) mode.
     */
    isConnected(): boolean;
    /**
     * True when init() has been called (regardless of WS connectivity).
     * Use this to determine whether Y.Doc is available.
     */
    isInitialized(): boolean;
    destroy(): void;
}
export declare const collaborationService: CollaborationService;
export {};
