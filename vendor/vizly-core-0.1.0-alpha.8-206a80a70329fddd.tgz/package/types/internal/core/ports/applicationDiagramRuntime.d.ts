import type { StandardDiagramData } from '../models/DiagramModels.js';
export interface DiagramRegistrationFallback {
    id: string;
    title: string;
}
export type DiagramRegistrationOverrides = Partial<Pick<StandardDiagramData, 'id' | 'name' | 'metadata' | 'isReadonly'>>;
export interface ApplicationDiagramRuntime {
    isStandardPresetId: (id: unknown) => boolean;
    loadStandardPreset: (id: unknown) => Promise<StandardDiagramData | null>;
    loadDiagram: (id: string, options?: {
        initialize?: boolean;
    }) => Promise<StandardDiagramData | null>;
    registerDiagram: (content: unknown, fallback: DiagramRegistrationFallback, persistToIndexedDB?: boolean, overrides?: DiagramRegistrationOverrides) => Promise<StandardDiagramData>;
    listDiagrams: () => Promise<StandardDiagramData[]>;
}
export declare const configureApplicationDiagramRuntime: (nextRuntime: ApplicationDiagramRuntime) => void;
export declare const getApplicationDiagramRuntime: () => ApplicationDiagramRuntime;
