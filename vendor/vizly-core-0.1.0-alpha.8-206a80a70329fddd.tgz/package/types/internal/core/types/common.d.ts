/**
 * 通用类型定义
 */
import { XYPosition } from '@xyflow/react';
export type Position = XYPosition;
export interface Size {
    width: number;
    height: number;
}
export interface Rectangle extends XYPosition, Size {
}
export interface ThemeColor {
    border: string;
    background?: string;
    color?: string;
    text?: string;
    accent?: string;
}
export interface DomainTheme extends ThemeColor {
    name?: string;
}
export interface SpacingConfig {
    H: number;
    V: number;
}
export interface DiagramConfig {
    NODE_WIDTH: number;
    NODE_HEIGHT: number;
    SPACING: SpacingConfig;
    GROUP_PADDING?: number;
    TITLE_BAR_HEIGHT?: number;
    containmentPolicy?: 'strict' | 'soft' | 'elastic';
    rankMode?: 'elk' | 'dagre_like';
}
export interface NodeData {
    id?: string;
    content?: string;
    title?: string;
    theme?: DomainTheme;
    width?: number;
    height?: number;
}
export interface EdgeData {
    id?: string;
    source?: string;
    target?: string;
    label?: string;
    type?: 'main' | 'support' | 'data' | 'feedback' | 'dependency';
    style?: React.CSSProperties;
}
export interface BaseComponentProps {
    className?: string;
    style?: React.CSSProperties;
    id?: string;
}
export interface InteractionConfig {
    showMiniMap?: boolean;
    showControls?: boolean;
    panOnDrag?: boolean;
    zoomOnScroll?: boolean;
    zoomOnPinch?: boolean;
    zoomOnDoubleClick?: boolean;
    panOnScroll?: boolean;
    preventScrolling?: boolean;
    nodesDraggable?: boolean;
    nodesConnectable?: boolean;
    elementsSelectable?: boolean;
}
export interface ExportConfig {
    format: 'png' | 'jpg' | 'svg' | 'pdf';
    quality?: number;
    scale?: number;
    backgroundColor?: string;
}
export interface DiagramError {
    code: string;
    message: string;
    details?: Record<string, unknown>;
}
export type DiagramEventType = 'node-click' | 'node-double-click' | 'edge-click' | 'canvas-click' | 'zoom-change' | 'viewport-change';
export interface NodeEventData {
    nodeId: string;
    position: Position;
    data: NodeData;
}
export interface EdgeEventData {
    edgeId: string;
    source: string;
    target: string;
    data: EdgeData;
}
export interface ViewportEventData {
    x: number;
    y: number;
    zoom: number;
}
export interface ZoomEventData {
    zoom: number;
    direction: 'in' | 'out';
}
export type DiagramEventData = NodeEventData | EdgeEventData | ViewportEventData | ZoomEventData | Record<string, unknown>;
export interface DiagramEvent<T extends DiagramEventData = DiagramEventData> {
    type: DiagramEventType;
    data: T;
    timestamp: number;
}
