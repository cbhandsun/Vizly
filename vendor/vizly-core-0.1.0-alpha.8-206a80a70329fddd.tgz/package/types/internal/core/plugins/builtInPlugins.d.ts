import type { PluginRegistry } from '../services/PluginRegistry.js';
export declare const ensureBuiltInPlugins: (pluginId?: string) => Promise<PluginRegistry>;
