import type { PluginContext } from '../types/plugin.js';
export declare const ArchitectureLinterPanel: ({ ctx }: {
    ctx: PluginContext;
}) => import("react").JSX.Element;
