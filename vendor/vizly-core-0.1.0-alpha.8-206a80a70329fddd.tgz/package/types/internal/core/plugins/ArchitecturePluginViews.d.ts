import React from 'react';
import { PluginContext } from '../types/plugin.js';
export declare const ArchitectureLinterPanel: React.LazyExoticComponent<typeof import("./ArchitectureLinterPanel.js").ArchitectureLinterPanel>;
export declare const ArchitecturePalette: React.FC<{
    ctx: PluginContext;
}>;
export declare const ArchitectureToolbar: React.FC<{
    ctx: PluginContext;
}>;
