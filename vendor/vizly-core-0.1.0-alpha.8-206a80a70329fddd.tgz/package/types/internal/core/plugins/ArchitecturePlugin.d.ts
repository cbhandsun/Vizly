import React from 'react';
import type { Node, Edge } from '@xyflow/react';
import { DiagramTypePlugin, PluginContext, SidebarPanel } from '../types/plugin.js';
export declare class ArchitecturePlugin implements DiagramTypePlugin {
    id: string;
    name: string;
    version: string;
    description: string;
    author: string;
    category: 'Productivity';
    tags: string[];
    brandColor: string;
    migrate(data: unknown, fromVersion: string | undefined): Promise<unknown>;
    parseData(_source: unknown): {
        nodes: never[];
        edges: never[];
    };
    serializeData(nodes: Node[], edges: Edge[]): {
        nodes: Node[];
        edges: Edge[];
    };
    getEmptyState(): {
        nodes: ({
            id: string;
            type: string;
            position: {
                x: number;
                y: number;
            };
            data: {
                themeColor?: undefined;
                label: string;
                type: string;
                description: string;
                metrics?: undefined;
            };
        } | {
            id: string;
            type: string;
            position: {
                x: number;
                y: number;
            };
            data: {
                description?: undefined;
                label: string;
                type: string;
                themeColor: string;
                metrics: {
                    label: string;
                    value: string;
                    status: 'success';
                }[];
            };
        } | {
            id: string;
            type: string;
            position: {
                x: number;
                y: number;
            };
            data: {
                themeColor?: undefined;
                description?: undefined;
                metrics?: undefined;
                label: string;
                type: string;
            };
        })[];
        edges: {
            id: string;
            source: string;
            target: string;
            type: string;
            data: {
                semantic: string;
                label: string;
            };
        }[];
    };
    getSupportedLayouts(): string[];
    getDefaultLayout(): string;
    getNodeTypes(): {
        architectureNode: React.NamedExoticComponent<import("@xyflow/react").NodeProps<Node<import("../components/custom-nodes/ArchitectureNode.js").ArchitectureNodeData>>>;
    };
    getEdgeTypes(): {
        archEdge: React.NamedExoticComponent<import("@xyflow/react").EdgeProps>;
    };
    contributeToolbar(ctx: PluginContext): React.JSX.Element;
    contributeSidebarPanels(ctx: PluginContext): SidebarPanel[];
}
