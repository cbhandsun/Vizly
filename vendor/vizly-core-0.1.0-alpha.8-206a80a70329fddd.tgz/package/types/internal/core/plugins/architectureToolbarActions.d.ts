import type { Edge, Node } from '@xyflow/react';
export type ArchitectureRelationshipPlan = {
    status: 'selection-required';
    selectedCount: number;
} | {
    status: 'duplicate';
    sourceId: string;
    targetId: string;
} | {
    status: 'ready';
    sourceId: string;
    targetId: string;
};
export interface ArchitectureRelationshipPlanOptions {
    nodes: Node[];
    edges: Edge[];
}
/** Resolves the toolbar action without mutating diagram state. */
export declare const buildArchitectureRelationshipPlan: ({ nodes, edges, }: ArchitectureRelationshipPlanOptions) => ArchitectureRelationshipPlan;
export declare const createArchitectureRelationshipEdge: ({ id, sourceId, targetId, label, }: {
    id: string;
    sourceId: string;
    targetId: string;
    label: string;
}) => Edge;
