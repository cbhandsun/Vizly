export * from './internal/core/public/demo-smart-edge.js';
export { default } from './internal/core/public/demo-smart-edge.js';
