import type { Edge, Node } from '@xyflow/react';
import type { RoutingPatch } from '../../routing/routingPatch.js';
export declare const BASE_DISPLAY_ROUTING_VERSION = "33";
export type BaseReactFlowDisplayEdgesCacheEntry = {
    edges: RoutingPatch[];
    hardClean: boolean;
    inputGeometryDigest?: string;
    /** Exact path/handle geometry to which hardClean applies. */
    outputRouteSignature: string;
};
export declare const isFinitePoint: (value: unknown) => value is {
    x: number;
    y: number;
};
export declare const isBaseReactFlowDisplayOutputRouteSignature: (value: unknown) => value is string;
/**
 * Computes the exact rendered-routing identity used to bind a cached hard report.
 * Business and visual metadata are deliberately excluded so routing patches can be
 * merged onto the newest source edge without invalidating an otherwise identical route.
 */
export declare const computeBaseReactFlowDisplayOutputRouteSignature: (edges: readonly Edge[]) => string | null;
export declare const baseReactFlowDisplayOutputRouteSignatureMatches: (edges: Edge[], expectedSignature: unknown) => boolean;
export declare const computeBaseReactFlowEndpointGeometryKey: (nodes: Node[]) => string;
export declare const computeBaseDisplayInputSignature: ({ nodes, edges, enableSmartEdges, smartEdgePadding, isLargeGraph, }: {
    nodes: Node[];
    edges: Edge[];
    enableSmartEdges: boolean;
    smartEdgePadding: number;
    isLargeGraph: boolean;
}) => string;
export declare const computeBaseReactFlowDisplayCacheSignature: (input: {
    nodes: Node[];
    edges: Edge[];
    enableSmartEdges: boolean;
    smartEdgePadding: number;
    isLargeGraph: boolean;
}) => string;
export declare const computeBaseReactFlowDisplayEdgeEpoch: ({ nodes, edges, }: {
    nodes: Node[];
    edges: Edge[];
}) => number;
export declare const readBaseReactFlowDisplayEdgesCacheEntry: (signature: string, inputGeometryDigest?: string) => BaseReactFlowDisplayEdgesCacheEntry | null;
export declare const readBaseReactFlowDisplayEdgesCache: (signature: string, inputGeometryDigest?: string) => Edge[] | null;
export declare const writeBaseReactFlowDisplayEdgesCache: (signature: string, edges: Edge[], options?: {
    hardClean?: boolean;
    inputGeometryDigest?: string;
    outputRouteSignature?: string;
}) => void;
export declare const isBaseDisplayFinalized: (edges: Edge[], signature: string) => boolean;
export declare const markBaseDisplayFinalized: <T extends Edge[]>(edges: T, signature: string) => T;
