import type { Edge, Node } from '@xyflow/react';
export declare const hasCounterFlowDisplaySeedTerminals: (edges: readonly Edge[], inputNodes: Node[]) => boolean;
/** Ports and their outward corridors are one initial routing decision. */
export declare const seedObstacleAwareDisplayRoutes: (edges: Edge[], inputNodes: Node[]) => Edge[];
