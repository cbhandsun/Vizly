import type { Edge, Node } from '@xyflow/react';
import { type LocalDoglegRepairDiagnostics, type LocalDoglegRepairOptions } from '../../strategies/shared/edgeLocalDoglegRepair.js';
export type DisplayQualityDoglegRepairSession = Readonly<{
    run: (edges: Edge[], diagnostics?: LocalDoglegRepairDiagnostics, options?: LocalDoglegRepairOptions) => Edge[];
}>;
/**
 * Retains only fixed-point proof inside one Worker job. A signature hit returns
 * the current edge array instead of an earlier candidate, so visual and business
 * metadata that is outside routing identity can never be restored from cache.
 */
export declare const createDisplayQualityDoglegRepairSession: (nodes: Node[]) => DisplayQualityDoglegRepairSession;
