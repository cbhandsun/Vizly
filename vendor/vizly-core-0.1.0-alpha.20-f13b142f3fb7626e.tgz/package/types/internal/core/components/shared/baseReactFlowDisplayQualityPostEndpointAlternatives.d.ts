import type { Edge, Node } from '@xyflow/react';
import { type LocalDoglegRepairDiagnostics, type LocalDoglegRepairOptions } from '../../strategies/shared/edgeLocalDoglegRepair.js';
import { type DisplayRoutingPhaseTrace } from './baseReactFlowDisplayRoutingTrace.js';
type QualityPostEndpointAlternatives = Readonly<{
    endpointAfterLocalCandidate: Edge[];
    localCandidate: Edge[];
    microPolishCandidate: Edge[];
}>;
/** Materializes only post-endpoint repair families justified by current defects. */
export declare const createDisplayQualityPostEndpointAlternatives: ({ endpointPolishCandidate, repairNodes, repairDoglegs, useBoundedLargeRepair, onPhaseTrace, }: Readonly<{
    endpointPolishCandidate: Edge[];
    repairNodes: Node[];
    repairDoglegs: (edges: Edge[], diagnostics?: LocalDoglegRepairDiagnostics, options?: LocalDoglegRepairOptions) => Edge[];
    useBoundedLargeRepair: boolean;
    onPhaseTrace?: (trace: DisplayRoutingPhaseTrace) => void;
}>) => QualityPostEndpointAlternatives;
export {};
