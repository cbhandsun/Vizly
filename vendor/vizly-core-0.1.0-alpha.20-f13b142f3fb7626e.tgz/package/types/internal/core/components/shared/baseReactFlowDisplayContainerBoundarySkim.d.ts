import type { Edge, Node } from '@xyflow/react';
export declare const DISPLAY_CONTAINER_BOUNDARY_SKIM_TOLERANCE = 14;
export declare const DISPLAY_CONTAINER_BOUNDARY_SKIM_MIN_LENGTH = 96;
export declare const DISPLAY_CONTAINER_BOUNDARY_SKIM_CLEARANCE = 20;
export declare const DISPLAY_CLOSE_SUBGROUP_GRAZE_TOLERANCE = 6;
export declare const DISPLAY_CLOSE_SUBGROUP_GRAZE_MIN_LENGTH = 56;
export type DisplayContainerBoundarySkimIssue = Readonly<{
    edgeId: string;
    edgeIndex: number;
    segmentIndex: number;
    axis: 'h' | 'v';
    length: number;
    coordinate: number;
    safeCoordinate: number;
    containerId: string;
    boundary: 'left' | 'right' | 'top' | 'bottom';
}>;
export type DisplayContainerBoundarySkimAudit = Readonly<{
    issues: readonly DisplayContainerBoundarySkimIssue[];
    totalLength: number;
    edgeIds: readonly string[];
}>;
export declare const auditDisplayContainerBoundarySkims: (edges: readonly Edge[], nodes: readonly Node[]) => DisplayContainerBoundarySkimAudit;
export declare const auditCloseSubGroupBoundaryGrazes: (edges: readonly Edge[], nodes: readonly Node[]) => DisplayContainerBoundarySkimAudit;
export declare const countDisplayContainerBoundarySkimLength: (edges: readonly Edge[], nodes: readonly Node[]) => number;
export declare const hasRepairableDisplayContainerBoundarySkim: (issue: DisplayContainerBoundarySkimIssue, edge: Edge, minSegmentLength?: number) => boolean;
